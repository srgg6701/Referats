<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
</head>

<body>
<a href='3.php'>dhddhsdghsdghdghsdg</a><br>
<a href='autors.php'>autors</a>

</body>
</html>
