<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<title>������</title>
<link href="admin.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" cellpadding="2"  cellspacing="1" bgcolor="#CCCCCC">
  <tr>
    <td colspan="13"><b>������ </b>(����� - 10) </td>
  </tr>
  <tr bgcolor="#CCFFCC">
    <td align="center"><a href="#">ID</a></td>
    <td align="center" nowrap><a href="#">�����.</a></td>
    <td nowrap><a href="#">����</a></td>
    <td align="center" nowrap>�����.</td>
    <td nowrap><a href="#">��������</a></td>
    <td nowrap><a href="#">���.</a></td>
    <td width="100%" nowrap><a href="#">����</a></td>
    <td align="center" nowrap><a href="#">���� ����. </a></td>
    <td align="center" nowrap><a href="#">���� ���.</a></td>
    <td align="center" nowrap><a href="#">����. (�.)</a></td>
    <td align="center" nowrap><a href="#">����. (%)</a></td>
    <td align="center" nowrap><a href="#">������</a></td>
    <td nowrap><a href="#">�����</a></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td align="right">1024</td>
    <td align="right">12.10.04</td>
    <td><a href="#">18.12.04</a></td>
    <td align="center"><a href="#">0(3)/3</a> </td>
    <td><a href="mailto:petjunja@yahoo.com">������</a></td>
    <td><a href="#" title="������� � ��������� ���������� ������">��������</a></td>
    <td><a href="#" title="���������� �������������� � �������� ��������">���������� �������������� � �������� ��������</a> </td>
    <td align="right"><a href="#">1000</a></td>
    <td align="right"><a href="#">750</a></td>
    <td align="right">250</td>
    <td align="right">25</td>
    <td align="center"><a href="#">50%</a></td>
    <td><a href="mailto:verdana@mail.ru">Verdana</a></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td>&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
