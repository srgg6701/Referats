<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<title>�����</title>
</head>
<body>
<form action="http://www.google.ru/cse" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-5247843693787522:5246682893" />
    <input type="hidden" name="ie" value="Windows-1251" />
    <input type="text" name="q" size="55" />
    <input type="submit" name="sa" value="&#x041f;&#x043e;&#x0438;&#x0441;&#x043a;" />
  </div>
</form>
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
<script type="text/javascript">google.load("elements", "1", {packages: "transliteration"});</script>
<script type="text/javascript" src="http://www.google.com/cse/t13n?form=cse-search-box&t13n_langs=en"></script>

<script type="text/javascript" src="http://www.google.ru/coop/cse/brand?form=cse-search-box&amp;lang=ru"></script>
</body>
</html>