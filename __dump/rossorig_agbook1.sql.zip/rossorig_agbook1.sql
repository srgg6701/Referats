-- phpMyAdmin SQL Dump
-- version 2.6.2-pl1
-- http://www.phpmyadmin.net
-- 
-- Хост: localhost
-- Время создания: Янв 09 2012 г., 20:31
-- Версия сервера: 4.1.12
-- Версия PHP: 5.0.4
-- 
-- БД: `rossorig_agbook1`
-- 

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_basket`
-- 

CREATE TABLE `ri_basket` (
  `number` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `work_table` char(15) NOT NULL default '',
  `work_id` int(11) NOT NULL default '0',
  `datatime` datetime NOT NULL default '0000-00-00 00:00:00',
  `state` char(4) default '0',
  `status` char(6) NOT NULL default '',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Корзина заказов' AUTO_INCREMENT=74 ;

-- 
-- Дамп данных таблицы `ri_basket`
-- 

INSERT INTO `ri_basket` VALUES (1, 2, 'diplom_zakaz', 9387, '2011-06-02 21:40:50', '', '');
INSERT INTO `ri_basket` VALUES (11, 2, 'diplom_zakaz', 9433, '2011-06-10 18:27:11', '', '');
INSERT INTO `ri_basket` VALUES (12, 2, 'diplom_zakaz', 7375, '2011-06-10 21:22:25', 'sent', 'reborn');
INSERT INTO `ri_basket` VALUES (4, 2, 'diplom_zakaz', 9441, '2011-06-07 12:17:44', '', '');
INSERT INTO `ri_basket` VALUES (13, 2, 'diplom_zakaz', 9407, '2011-06-10 18:27:11', 'sent', '');
INSERT INTO `ri_basket` VALUES (17, 1, 'diplom_zakaz', 7375, '2011-06-11 10:39:27', '', '');
INSERT INTO `ri_basket` VALUES (10, 2, 'diplom_zakaz', 9360, '2011-06-08 10:11:30', '', 'del');
INSERT INTO `ri_basket` VALUES (14, 2, 'diplom_zakaz', 7407, '2011-06-10 18:27:11', '', '');
INSERT INTO `ri_basket` VALUES (15, 2, 'ri_worx', 4, '2011-06-10 18:27:11', '', '');
INSERT INTO `ri_basket` VALUES (19, 1, 'diplom_zakaz', 8577, '2011-06-11 10:53:27', '', 'reborn');
INSERT INTO `ri_basket` VALUES (20, 1, 'diplom_zakaz', 9360, '2011-06-11 10:39:27', 'sent', '');
INSERT INTO `ri_basket` VALUES (21, 2, 'diplom_zakaz', 9374, '2011-07-29 14:38:10', 'sent', '');
INSERT INTO `ri_basket` VALUES (23, 4, 'diplom_zakaz', 9374, '2011-07-31 17:25:32', '0', '');
INSERT INTO `ri_basket` VALUES (24, 4, 'diplom_zakaz', 9365, '2011-07-31 17:27:57', '0', '');
INSERT INTO `ri_basket` VALUES (25, 4, 'diplom_zakaz', 9407, '2011-07-31 17:30:43', '0', '');
INSERT INTO `ri_basket` VALUES (26, 4, 'ri_worx', 3, '2011-07-31 17:35:07', '0', '');
INSERT INTO `ri_basket` VALUES (27, 5, 'diplom_zakaz', 9374, '2011-07-31 17:40:03', '0', '');
INSERT INTO `ri_basket` VALUES (28, 5, 'diplom_zakaz', 9433, '2011-08-01 08:31:09', '0', '');
INSERT INTO `ri_basket` VALUES (29, 5, 'diplom_zakaz', 9379, '2011-08-01 08:31:25', '0', '');
INSERT INTO `ri_basket` VALUES (30, 6, 'ri_worx', 4, '2011-08-01 11:36:21', '0', '');
INSERT INTO `ri_basket` VALUES (31, 7, 'diplom_zakaz', 9433, '2011-08-01 12:09:05', '0', '');
INSERT INTO `ri_basket` VALUES (32, 8, 'diplom_zakaz', 9433, '2011-08-01 12:30:36', '0', '');
INSERT INTO `ri_basket` VALUES (33, 8, 'diplom_zakaz', 9374, '2011-08-01 12:31:14', '0', '');
INSERT INTO `ri_basket` VALUES (34, 8, 'diplom_zakaz', 7407, '2011-08-01 12:37:03', '0', '');
INSERT INTO `ri_basket` VALUES (35, 9, 'diplom_zakaz', 9374, '2011-08-02 08:01:59', '0', '');
INSERT INTO `ri_basket` VALUES (36, 2, 'diplom_zakaz', 5251, '2011-10-20 19:00:00', '0', '');
INSERT INTO `ri_basket` VALUES (37, 2, 'diplom_zakaz', 9326, '2011-10-23 12:57:35', '0', '');
INSERT INTO `ri_basket` VALUES (38, 2, 'diplom_zakaz', 7004, '2011-10-23 12:57:35', 'sent', '');
INSERT INTO `ri_basket` VALUES (39, 12, 'diplom_zakaz', 7004, '2011-11-18 12:00:57', '0', '');
INSERT INTO `ri_basket` VALUES (40, 13, 'ri_worx', 3, '2011-11-18 12:08:46', '0', '');
INSERT INTO `ri_basket` VALUES (41, 13, 'diplom_zakaz', 9558, '2011-11-18 12:16:58', '0', '');
INSERT INTO `ri_basket` VALUES (42, 13, 'diplom_zakaz', 9326, '2011-11-18 12:16:58', '0', '');
INSERT INTO `ri_basket` VALUES (43, 13, 'diplom_zakaz', 7004, '2011-11-18 12:16:58', '0', '');
INSERT INTO `ri_basket` VALUES (44, 13, 'ri_worx', 4, '2011-11-18 13:20:21', '0', '');
INSERT INTO `ri_basket` VALUES (63, 33, 'diplom_zakaz', 7403, '2011-11-18 22:56:21', '0', '');
INSERT INTO `ri_basket` VALUES (46, 24, 'diplom_zakaz', 5659, '2011-11-18 21:48:42', '0', '');
INSERT INTO `ri_basket` VALUES (47, 24, 'diplom_zakaz', 6994, '2011-11-18 21:48:42', '0', '');
INSERT INTO `ri_basket` VALUES (59, 25, 'diplom_zakaz', 5248, '2011-11-18 22:02:12', '0', '');
INSERT INTO `ri_basket` VALUES (49, 24, 'ri_worx', 21, '2011-11-18 21:48:42', '0', '');
INSERT INTO `ri_basket` VALUES (52, 24, 'diplom_zakaz', 9550, '2011-11-18 21:49:54', '0', '');
INSERT INTO `ri_basket` VALUES (53, 24, 'diplom_zakaz', 7134, '2011-11-18 21:50:27', '0', '');
INSERT INTO `ri_basket` VALUES (60, 33, 'diplom_zakaz', 9558, '2011-11-18 22:56:01', '0', '');
INSERT INTO `ri_basket` VALUES (62, 33, 'diplom_zakaz', 7004, '2011-11-18 22:56:01', '0', '');
INSERT INTO `ri_basket` VALUES (56, 24, 'diplom_zakaz', 7403, '2011-11-18 21:58:04', '0', '');
INSERT INTO `ri_basket` VALUES (61, 33, 'diplom_zakaz', 9326, '2011-11-18 22:56:01', '0', '');
INSERT INTO `ri_basket` VALUES (58, 24, 'diplom_zakaz', 9367, '2011-11-18 21:58:04', '0', '');
INSERT INTO `ri_basket` VALUES (64, 33, 'diplom_zakaz', 7134, '2011-11-18 22:57:21', '0', '');
INSERT INTO `ri_basket` VALUES (65, 23, 'diplom_zakaz', 7004, '2011-11-18 23:16:17', '0', '');
INSERT INTO `ri_basket` VALUES (67, 23, 'ri_worx', 20, '2011-11-18 23:16:41', '0', '');
INSERT INTO `ri_basket` VALUES (68, 23, 'diplom_zakaz', 9550, '2011-11-18 23:17:20', '0', '');
INSERT INTO `ri_basket` VALUES (69, 23, 'diplom_zakaz', 5052, '2011-11-18 23:17:34', '0', '');
INSERT INTO `ri_basket` VALUES (71, 23, 'diplom_zakaz', 5390, '2011-11-18 23:18:34', '0', '');
INSERT INTO `ri_basket` VALUES (72, 23, 'ri_worx', 4, '2011-11-18 23:18:56', '0', '');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_customer`
-- 

CREATE TABLE `ri_customer` (
  `number` int(11) NOT NULL auto_increment,
  `name` char(40) NOT NULL default '',
  `email` char(50) NOT NULL default '',
  `email2` char(50) NOT NULL default '',
  `password` char(20) NOT NULL default '',
  `mobila` char(40) NOT NULL default '',
  `icq` int(11) NOT NULL default '0',
  `skype` char(40) NOT NULL default '',
  `datatime` datetime NOT NULL default '0000-00-00 00:00:00',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Заказчики' AUTO_INCREMENT=34 ;

-- 
-- Дамп данных таблицы `ri_customer`
-- 

INSERT INTO `ri_customer` VALUES (1, 'Серёшка', 'serjo@mail.ru', 'wxas@yandex.ru', 'history', '+7 904 442 84 47', 0, '', '0000-00-00 00:00:00');
INSERT INTO `ri_customer` VALUES (2, 'Дмитрий', 'dinato@mail.ru', '', 'history', '+79166779066', 0, '', '2011-06-02 00:00:00');
INSERT INTO `ri_customer` VALUES (3, 'Олежка', 'olla@ya.ru', '', 'history', '', 0, '', '2011-07-31 00:00:00');
INSERT INTO `ri_customer` VALUES (4, '', 'onelka@mail.ru', '', 'history', '', 0, '', '2011-07-31 00:00:00');
INSERT INTO `ri_customer` VALUES (5, '', 'oll@mail.ru', '', 'history', '', 0, '', '2011-07-31 00:00:00');
INSERT INTO `ri_customer` VALUES (6, 'Фиделио', 'fidelio@mai.ru', '', 'history', '', 0, '', '2011-08-01 00:00:00');
INSERT INTO `ri_customer` VALUES (7, '', 'hex@gmail.com', '', 'history', '', 0, '', '2011-08-01 00:00:00');
INSERT INTO `ri_customer` VALUES (8, '', 'tog@rambler.ru', '', 'history', '', 0, '', '2011-08-01 00:00:00');
INSERT INTO `ri_customer` VALUES (9, '', 'pop@mail.ru', '', 'history', '', 0, '', '2011-08-02 00:00:00');
INSERT INTO `ri_customer` VALUES (10, '', 'donald@duk.com', '', 'history', '', 0, '', '2011-11-08 00:00:00');
INSERT INTO `ri_customer` VALUES (11, '', 'amic@gmail.com', '', 'history', '', 0, '', '2011-11-08 00:00:00');
INSERT INTO `ri_customer` VALUES (12, 'Анфиз', 'anfisa@mail.com', 'anaphema@toyou.com', 'history', '89905552031', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (13, '', 'antocha@anto.com', '', 'history', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (14, '', 'endes@mail.ru', '', 'history', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (15, '', 'juliany@hmal.com', '', 'history', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (22, '', 'ole@lokoje.ru', '', 'history', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (23, '', 'olbano@mauro.com', '', 'fAAguJnzbm', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (24, '', 'iui@gmail.com', '', 'GourlX1Vrf', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (25, '', 'uzz@yahoo.com', '', 'kGgJEGFeep', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (26, '', 'eretique@ya.ru', '', 'Gr8DoJFAip', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (21, '', 'movier@gmail.com', '', 'history', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (27, '', 'potz@david.com', '', 'dPkRtdlvGY', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (28, '', 'nuendo@mail.ru', '', 'pH9ysxUFAM', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (29, '', 'yoki@ya.ru', '', 'nKuGAnYMnV', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (30, '', 'quizz@ya.ru', '', 'NjmkGS4Sbl', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (31, '', 'gone@mail.ru', '', 'tC4GS4tuAD', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (32, '', 'rhonny@test.com', '', 'dN3DFLMDes', '', 0, '', '2011-11-18 00:00:00');
INSERT INTO `ri_customer` VALUES (33, '', 'klide@yahoo.com', '', 'iKxvYc1kyC', '', 0, '', '2011-11-18 00:00:00');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_messages`
-- 

CREATE TABLE `ri_messages` (
  `number` int(11) NOT NULL auto_increment,
  `ri_basket_id` int(11) NOT NULL default '0',
  `name` varchar(50) default NULL,
  `from_email` varchar(50) default NULL,
  `sender_user_id` int(11) default NULL,
  `sender_user_type` varchar(10) default NULL,
  `to_email` varchar(50) NOT NULL default '',
  `receiver_user_id` text,
  `receiver_user_type` varchar(10) NOT NULL default '',
  `datatime` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` varchar(255) default NULL,
  `subject` varchar(255) NOT NULL default '',
  `text` longtext,
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Комментарии к разделам' AUTO_INCREMENT=47 ;

-- 
-- Дамп данных таблицы `ri_messages`
-- 

INSERT INTO `ri_messages` VALUES (1, 0, 'Сергей', 'srgg140201@yandex.ru', 0, '', 'sale@referats.info', '0', 'admin', '2011-05-20 17:47:52', '/referats/zip/index.php?sort=predmet&test_mode=off', '', 'Ну теперь в рабочем!');
INSERT INTO `ri_messages` VALUES (2, 0, 'Андрюха', 'andreas@papas.com', 0, '', 'sale@referats.info', '0', 'admin', '2011-05-20 17:50:57', '/referats/zip/index.php?sort=predmet&test_mode=off', '', 'Алерт будет-нет?');
INSERT INTO `ri_messages` VALUES (3, 0, 'Сергейка', 'srgg140201@yandex.ru', 33, 'author', 'sale@referats.info', '0', 'admin', '2011-05-25 11:51:12', '/referats/author/index.php?menu=default', 'Сообщение от автора id 33 (srgg140201@yandex.ru)', 'Понятно вроде, где ошибка была...<hr>Автор: srgg140201@yandex.ru (Сергейка).');
INSERT INTO `ri_messages` VALUES (4, 0, 'Сергейка', 'srgg140201@yandex.ru', 33, 'author', 'sale@referats.info', '0', 'admin', '2011-05-25 12:28:11', '/referats/author/index.php?menu=messages', 'Сообщение от автора id 33 (srgg140201@yandex.ru)', 'Прикольно! Вроде как усё работает с сообщениям пока!<hr>Автор: srgg140201@yandex.ru (Сергейка).');
INSERT INTO `ri_messages` VALUES (6, 0, 'Сергей', '', 0, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-02 09:30:02', '/referats/zip/register.php?send_password=serjo@mail.ru&actor_type=customer', 'Восстановление пароля, Referats.info', '<h4>Здравствуйте, Сергей!</h4>\r\n						  Ваш пароль доступа в аккаунт на торговой площадке <a href="http://www.referats.info">Referats.info</a>: history.<p>В качестве логина используйте, пожалуйста, свой емэйл.</p>Администрация <a href="http://www.referats.info">Referats.info</a>.');
INSERT INTO `ri_messages` VALUES (46, 38, 'Дмитрий', '', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-10-23 13:05:57', '/referats/manager/?menu=money&action=apply&payment_id=25&summ=275&order_id=38', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 38 подтверждена.\r\n								   <p>Сумма проводки: 275 р.</p>');
INSERT INTO `ri_messages` VALUES (42, 0, '', 'sale@referats.info', 1, 'worker', 'andreas@papas.com', '0', '', '2011-08-05 09:28:56', 'answer', 'Ответ на сообщение # 2', 'Будет те и белка, буде и свисток!\r\n\r\n***	Исходное сообщение:\r\n\r\nАлерт будет-нет?');
INSERT INTO `ri_messages` VALUES (43, 0, 'Серя', 'srgg67@gmail.com', 0, '', '', '', 'admin', '2011-08-08 13:59:46', '/referats/', 'Комментарий к разделу /referats/.', 'А тута как оно?\r\n<hr>Отправитель: Серя.');
INSERT INTO `ri_messages` VALUES (11, 0, 'Сергей', '', 0, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-02 18:40:31', '/referats/zip/register.php?send_password=serjo@mail.ru&actor_type=customer', 'Восстановление пароля, Referats.info', '<h4>Здравствуйте, Сергей!</h4>\r\n							  Ваш пароль доступа в аккаунт на торговой площадке <a href="http://www.referats.info">Referats.info</a>: history.<p>В качестве логина используйте, пожалуйста, свой емэйл.</p>Администрация <a href="http://www.referats.info">Referats.info</a>.');
INSERT INTO `ri_messages` VALUES (12, 0, 'Сергей', '', 0, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-02 18:41:01', '/referats/zip/register.php?send_password=serjo@mail.ru&actor_type=customer', 'Восстановление пароля, Referats.info', '<h4>Здравствуйте, Сергей!</h4>\r\n							  Ваш пароль доступа в аккаунт на торговой площадке <a href="http://www.referats.info">Referats.info</a>: history.<p>В качестве логина используйте, пожалуйста, свой емэйл.</p>Администрация <a href="http://www.referats.info">Referats.info</a>.');
INSERT INTO `ri_messages` VALUES (13, 0, 'Сергей', '', 0, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-02 18:41:31', '/referats/zip/register.php?send_password=serjo@mail.ru&actor_type=customer', 'Восстановление пароля, Referats.info', '<h4>Здравствуйте, Сергей!</h4>\r\n							  Ваш пароль доступа в аккаунт на торговой площадке <a href="http://www.referats.info">Referats.info</a>: history.<p>В качестве логина используйте, пожалуйста, свой емэйл.</p>Администрация <a href="http://www.referats.info">Referats.info</a>.');
INSERT INTO `ri_messages` VALUES (14, 0, 'Сергей', '', 0, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-03 19:00:24', '/referats/zip/register.php?send_password=serjo@mail.ru&actor_type=customer', 'Восстановление пароля, Referats.info', '<h4>Здравствуйте, Сергей!</h4>\r\n							  Ваш пароль доступа в аккаунт на торговой площадке <a href="http://www.referats.info">Referats.info</a>: history.<p>В качестве логина используйте, пожалуйста, свой емэйл.</p>Администрация <a href="http://www.referats.info">Referats.info</a>.');
INSERT INTO `ri_messages` VALUES (15, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 11:04:58', 'section=customer', 'Комментарий к разделу section=customer', 'А ЧО, прям отсюдова слать?<hr>Отправитель: Сергей.');
INSERT INTO `ri_messages` VALUES (16, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 11:05:13', 'section=customer', 'Комментарий к разделу section=customer', 'А ЧО, прям отсюдова слать?<hr>Отправитель: Сергей.');
INSERT INTO `ri_messages` VALUES (44, 12, 'Дмитрий', '', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-10-20 13:43:02', '/referats/manager/?menu=money&action=apply&payment_id=23&summ=300', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 12 подтверждена.\r\n								   <p>Сумма проводки: 300 р.</p>');
INSERT INTO `ri_messages` VALUES (18, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 11:16:13', 'section=customer', 'Комментарий к разделу section=customer', 'и ишо одно, админу!<hr>Отправитель: Сергей.');
INSERT INTO `ri_messages` VALUES (19, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 12:09:56', 'section=customer', 'Комментарий к разделу section=customer', 'Сообщение по заказу id 19:\r\n----------------------------------------\r\nА что? Работает или как?<hr>Отправитель: Сергей.');
INSERT INTO `ri_messages` VALUES (20, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 12:15:39', 'section=customer', 'Комментарий к разделу section=customer', 'Сообщение по заказу id 17:\r\n----------------------------------------\r\nКой чего подправили однака....<hr>Отправитель: Сергей.');
INSERT INTO `ri_messages` VALUES (22, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 15:57:51', 'section=customer', 'Комментарий к разделу section=customer', 'Ага, ага. А теперь отправляем мессагу непосредственно из раздела сообщений, как новую!<hr>Отправитель: Сергей.');
INSERT INTO `ri_messages` VALUES (23, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 16:07:18', 'section=customer', 'Комментарий к разделу section=customer', 'А я вот не решил чо писать пока...<hr>Отправитель: Сергей.');
INSERT INTO `ri_messages` VALUES (24, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 16:11:26', 'section=customer', 'Новое сообщение администрации Referats.info.', 'Новое сообщение администрации Referats.info.:\r\n----------------------------------------\r\nНу как вы там, жлобы?');
INSERT INTO `ri_messages` VALUES (25, 0, 'Сергей', 'serjo@mail.ru', 1, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 16:12:57', 'section=customer', 'Новое сообщение администрации Referats.info.', 'Новое сообщение администрации Referats.info.:\r\n----------------------------------------\r\nТокмо на "жлобов" не обижайтесь, пацоны!!');
INSERT INTO `ri_messages` VALUES (26, 0, '', 'dinato@mail.ru', 2, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 16:40:26', 'section=customer', 'Новое сообщение администрации Referats.info.', 'Новое сообщение администрации Referats.info.:\r\n----------------------------------------\r\nДа, из этого раздела отправляю впервые!');
INSERT INTO `ri_messages` VALUES (27, 0, '', 'dinato@mail.ru', 2, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 17:25:22', 'section=customer', 'Новое сообщение администрации Referats.info.', 'Новое сообщение администрации Referats.info.:\r\n----------------------------------------\r\nНу и что, что только одно? Будут и другие вскорости!');
INSERT INTO `ri_messages` VALUES (28, 0, '', 'dinato@mail.ru', 2, 'customer', 'sale@referats.info', '0', 'admin', '2011-06-11 17:25:41', 'section=customer', 'Новое сообщение администрации Referats.info.', 'Новое сообщение администрации Referats.info.:\r\n----------------------------------------\r\n<p>Ну и что, что только одно?</p>\r\n<br>\r\n<br>\r\nБудут и другие вскорости!');
INSERT INTO `ri_messages` VALUES (29, 0, 'массив имён', 'sale@referats.info', 1, 'worker', 'mass@mail', '125,271,33,360,445,401,229,186,61,154,50,54,99,165,345,267,72,204', 'author', '2011-06-18 12:35:42', 'new', 'Новое сообщение от Referats.info', 'Мультисообщение. Первое в таблице!!!');
INSERT INTO `ri_messages` VALUES (45, 12, 'Дмитрий', 'sale@referats.info', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-10-20 13:43:08', '/referats/manager/?menu=money&action=apply&payment_id=22&summ=1000', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 12 подтверждена.\r\n								   <p>Сумма проводки: 1000 р.</p>');
INSERT INTO `ri_messages` VALUES (32, 0, 'массив имён', 'sale@referats.info', 1, 'worker', 'mass@mail', '2,1', 'customer', '2011-06-18 13:05:06', 'new', 'Новое сообщение от Referats.info', 'Привет , клиенты!\r\nВот и до вас добрались ужо почти!');
INSERT INTO `ri_messages` VALUES (33, 19, 'Серёшка', 'sale@referats.info', 1, 'worker', 'serjo@mail.ru', '1', 'customer', '2011-06-19 13:51:22', '/referats/manager/index.php?menu=money&action=apply&payment_id=14', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 19 подтверждена.');
INSERT INTO `ri_messages` VALUES (34, 19, 'Серёшка', 'sale@referats.info', 1, 'worker', 'serjo@mail.ru', '1', 'customer', '2011-06-19 13:53:36', '/referats/manager/index.php?menu=money&action=apply&payment_id=14', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 19 подтверждена.');
INSERT INTO `ri_messages` VALUES (35, 14, '', 'sale@referats.info', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-06-19 16:05:41', '/referats/manager/index.php?menu=money&action=apply&payment_id=10&summ=4199', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 14 подтверждена.\r\n								   <p>Сумма проводки: 4199 р.</p>');
INSERT INTO `ri_messages` VALUES (36, 15, 'Дмитрий', '', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-06-24 18:09:59', '/referats/manager/?menu=money&action=apply&payment_id=8&summ=3100', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 15 подтверждена.\r\n								   <p>Сумма проводки: 3100 р.</p>');
INSERT INTO `ri_messages` VALUES (37, 15, 'Дмитрий', 'sale@referats.info', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-06-24 18:13:25', '/referats/manager/?menu=money&action=apply&payment_id=19&summ=1200', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 15 подтверждена.\r\n								   <p>Сумма проводки: 1200 р.</p>');
INSERT INTO `ri_messages` VALUES (38, 20, 'Серёшка', '', 1, 'worker', 'serjo@mail.ru', '1', 'customer', '2011-07-29 14:21:15', '/referats/manager/?menu=money&action=apply&payment_id=13&summ=3000', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 20 подтверждена.\r\n								   <p>Сумма проводки: 3000 р.</p>');
INSERT INTO `ri_messages` VALUES (39, 20, 'Серёшка', '', 1, 'worker', 'serjo@mail.ru', '1', 'customer', '2011-07-29 14:34:05', '/referats/manager/?menu=money&action=apply&payment_id=13&summ=3000', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 20 подтверждена.\r\n								   <p>Сумма проводки: 3000 р.</p>');
INSERT INTO `ri_messages` VALUES (40, 13, 'Дмитрий', 'sale@referats.info', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-07-29 14:36:17', '/referats/manager/?menu=money&action=apply&payment_id=11&summ=1', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 13 подтверждена.\r\n								   <p>Сумма проводки: 1 р.</p>');
INSERT INTO `ri_messages` VALUES (41, 21, 'Дмитрий', 'sale@referats.info', 1, 'worker', 'dinato@mail.ru', '2', 'customer', '2011-07-29 14:43:02', '/referats/manager/?menu=money&action=apply&payment_id=20&summ=450', 'Изменение статуса проводки', 'Проводка денежных средств по заказу id 21 подтверждена.\r\n								   <p>Сумма проводки: 450 р.</p>');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_messages_status`
-- 

CREATE TABLE `ri_messages_status` (
  `number` int(11) NOT NULL auto_increment,
  `user_type` char(10) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `mess_status` char(10) NOT NULL default '',
  `ri_messages_id` int(11) NOT NULL default '0',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Статус сообщения: прочтено, отве�' AUTO_INCREMENT=59 ;

-- 
-- Дамп данных таблицы `ri_messages_status`
-- 

INSERT INTO `ri_messages_status` VALUES (41, 'worker', 3, 'read', 61);
INSERT INTO `ri_messages_status` VALUES (42, 'author', 33, 'read', 63);
INSERT INTO `ri_messages_status` VALUES (43, 'author', 33, 'read', 64);
INSERT INTO `ri_messages_status` VALUES (44, 'author', 33, 'read', 65);
INSERT INTO `ri_messages_status` VALUES (45, 'author', 33, 'read', 66);
INSERT INTO `ri_messages_status` VALUES (46, 'customer', 6, 'read', 67);
INSERT INTO `ri_messages_status` VALUES (47, 'worker', 3, 'read', 68);
INSERT INTO `ri_messages_status` VALUES (48, 'worker', 3, 'read', 69);
INSERT INTO `ri_messages_status` VALUES (49, 'worker', 1, 'read', 39);
INSERT INTO `ri_messages_status` VALUES (50, 'worker', 1, 'read', 40);
INSERT INTO `ri_messages_status` VALUES (51, 'worker', 1, 'read', 41);
INSERT INTO `ri_messages_status` VALUES (52, 'worker', 1, 'read', 31);
INSERT INTO `ri_messages_status` VALUES (53, 'worker', 1, 'read', 5);
INSERT INTO `ri_messages_status` VALUES (54, 'worker', 1, 'answer', 2);
INSERT INTO `ri_messages_status` VALUES (55, 'worker', 1, 'read', 42);
INSERT INTO `ri_messages_status` VALUES (56, 'worker', 1, 'read', 44);
INSERT INTO `ri_messages_status` VALUES (57, 'worker', 1, 'read', 45);
INSERT INTO `ri_messages_status` VALUES (58, 'worker', 1, 'read', 46);

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_objects_stat`
-- 

CREATE TABLE `ri_objects_stat` (
  `number` int(11) NOT NULL auto_increment,
  `table` char(24) NOT NULL default '',
  `last_id` int(11) NOT NULL default '0',
  `last_datetime` datetime NOT NULL default '0000-00-00 00:00:00',
  `actor_type` char(10) NOT NULL default '',
  `actor_id` int(11) NOT NULL default '0',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Статистика последних посещений �' AUTO_INCREMENT=36 ;

-- 
-- Дамп данных таблицы `ri_objects_stat`
-- 

INSERT INTO `ri_objects_stat` VALUES (16, 'ri_payments', 38, '2011-07-20 16:52:20', 'worker', 3);
INSERT INTO `ri_objects_stat` VALUES (17, 'ri_basket', 47, '2011-07-20 16:52:42', 'worker', 3);
INSERT INTO `ri_objects_stat` VALUES (18, 'ri_basket', 20, '2011-07-29 14:02:08', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (19, 'ri_payments', 19, '2011-07-29 14:06:23', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (20, 'ri_payments', 20, '2011-07-29 14:42:51', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (21, 'ri_basket', 21, '2011-07-29 14:43:10', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (22, 'ri_messages', 41, '2011-08-05 07:47:50', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (23, 'ri_basket', 35, '2011-08-05 07:48:13', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (24, 'ri_messages', 29, '2011-08-09 11:01:12', 'author', 33);
INSERT INTO `ri_objects_stat` VALUES (25, 'ri_basket', 30, '2011-09-13 16:40:43', 'author', 33);
INSERT INTO `ri_objects_stat` VALUES (26, 'ri_worx', 23, '2011-10-20 13:33:42', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (27, 'ri_payments', 24, '2011-10-20 13:42:49', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (28, 'ri_messages', 45, '2011-10-23 13:01:59', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (29, 'ri_basket', 38, '2011-10-23 13:02:23', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (30, 'ri_payments', 25, '2011-10-23 13:05:39', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (31, 'ri_worx', 40, '2011-11-29 18:41:51', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (32, 'ri_basket', 72, '2011-11-29 18:42:56', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (33, 'ri_payments', 28, '2011-11-29 18:43:00', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (34, 'ri_messages', 46, '2011-11-29 18:43:07', 'worker', 1);
INSERT INTO `ri_objects_stat` VALUES (35, 'ri_basket', 72, '2011-11-29 18:43:53', 'author', 33);

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_payments`
-- 

CREATE TABLE `ri_payments` (
  `number` int(11) NOT NULL auto_increment,
  `ri_basket_id` int(11) NOT NULL default '0',
  `datatime` datetime NOT NULL default '0000-00-00 00:00:00',
  `summ` int(11) NOT NULL default '0',
  `payment_date` date NOT NULL default '0000-00-00',
  `payment_method` varchar(40) NOT NULL default '',
  `payment_note` longtext NOT NULL,
  `recorder_type` varchar(10) NOT NULL default '',
  `payment_status` varchar(10) NOT NULL default '',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Платежи за работы' AUTO_INCREMENT=29 ;

-- 
-- Дамп данных таблицы `ri_payments`
-- 

INSERT INTO `ri_payments` VALUES (2, 10, '2010-04-07 15:43:26', 3000, '2011-06-09', 'Терминал «Элекснет»', 'Вечером платил. Дошло ужо?', 'customer', '');
INSERT INTO `ri_payments` VALUES (7, 1, '2011-06-09 17:11:16', 4725, '2011-06-09', 'Счёт webmoney', '', 'customer', '');
INSERT INTO `ri_payments` VALUES (13, 20, '2011-06-11 10:47:14', 3000, '2011-06-11', 'Яндекс.деньги', '', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (8, 15, '2011-06-20 10:07:46', 3100, '2010-05-20', 'Перевод по системе «Контакт»', 'законтачили-таки....						', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (10, 14, '2011-06-10 21:14:01', 4199, '2010-03-08', 'Терминал «Элекснет»', 'а, вона как!', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (11, 13, '2011-06-10 21:16:55', 1, '2010-08-08', 'Курьерский', 'в белы рученьки прям передал!', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (14, 19, '2011-06-11 10:49:09', 8750, '2011-06-11', 'Наличные (для москвичей)', 'Пушкинская полщадь. Как обычно!', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (17, 12, '2011-06-20 11:59:46', 500, '2011-06-20', 'Терминал «Элекснет»', 'Ну, не прикольна ли?...	', 'worker', 'OK');
INSERT INTO `ri_payments` VALUES (18, 15, '2011-06-21 18:25:16', 400, '0000-00-00', 'Терминал «Элекснет»', 'вававфы', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (19, 15, '2011-06-21 19:05:20', 1200, '0000-00-00', 'Терминал «Элекснет»', 'Долго, зараза, купюры не принимал...', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (20, 21, '2011-07-29 14:42:33', 450, '2011-07-29', 'Терминал «Элекснет»', 'yes!', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (21, 14, '2011-10-20 13:37:34', 30, '2011-10-20', 'Терминал «Элекснет»', 'ну вы жлобы... не могли ужо простить 30 руб...', 'customer', '');
INSERT INTO `ri_payments` VALUES (22, 12, '2011-10-20 13:38:13', 1000, '2011-10-20', 'Яндекс.деньги', 'на-те, на-те', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (23, 12, '2011-10-20 13:41:19', 300, '2011-10-20', 'Карточки предоплаты Яндекс.деньги', 'а нету примечания!', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (24, 15, '2011-10-20 13:42:35', 1, '2011-10-20', 'Наличные (для москвичей)', 'ну вот пришол в офис и забрал', 'customer', '');
INSERT INTO `ri_payments` VALUES (25, 38, '2011-10-23 13:03:48', 275, '2011-10-23', 'Терминал «Элекснет»', '%% -то сколько жрёт, зараза...', 'customer', 'OK');
INSERT INTO `ri_payments` VALUES (26, 39, '2011-11-18 12:07:24', 2500, '2011-11-18', 'Яндекс.деньги', 'Шибко переплатила однака...', 'customer', '');
INSERT INTO `ri_payments` VALUES (27, 40, '2011-11-18 12:12:29', 125, '2011-11-18', 'Счёт webmoney', 'Ну скока надо, стока и заплатил....', 'customer', '');
INSERT INTO `ri_payments` VALUES (28, 56, '2011-11-18 21:59:03', 1300, '2011-11-18', 'Терминал «Элекснет»', 'пришло ль?', 'customer', '');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_payouts`
-- 

CREATE TABLE `ri_payouts` (
  `number` int(11) NOT NULL auto_increment,
  `datatime` datetime NOT NULL default '0000-00-00 00:00:00',
  `payout_date` date NOT NULL default '0000-00-00',
  `summ` int(11) NOT NULL default '0',
  `payout_mode` varchar(40) NOT NULL default '',
  `payout_author` varchar(20) NOT NULL default '',
  `payout_note` text NOT NULL,
  `ri_basket_id` int(11) NOT NULL default '0',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=3 ;

-- 
-- Дамп данных таблицы `ri_payouts`
-- 


-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_sessions`
-- 

CREATE TABLE `ri_sessions` (
  `number` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `user_type` char(10) NOT NULL default '',
  `session_started` datetime default NULL,
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Сессии пользователей' AUTO_INCREMENT=115 ;

-- 
-- Дамп данных таблицы `ri_sessions`
-- 

INSERT INTO `ri_sessions` VALUES (1, 33, 'author', '2011-05-25 10:45:48');
INSERT INTO `ri_sessions` VALUES (2, 33, 'author', '2011-05-25 10:49:42');
INSERT INTO `ri_sessions` VALUES (3, 33, 'author', '2011-05-25 11:05:50');
INSERT INTO `ri_sessions` VALUES (4, 33, 'author', '2011-05-25 11:06:20');
INSERT INTO `ri_sessions` VALUES (5, 33, 'author', '2011-05-25 11:06:24');
INSERT INTO `ri_sessions` VALUES (6, 33, 'author', '2011-05-25 11:06:43');
INSERT INTO `ri_sessions` VALUES (7, 33, 'author', '2011-05-25 11:07:34');
INSERT INTO `ri_sessions` VALUES (8, 33, 'author', '2011-05-25 11:07:37');
INSERT INTO `ri_sessions` VALUES (9, 33, 'author', '2011-05-25 11:07:57');
INSERT INTO `ri_sessions` VALUES (10, 33, 'author', '2011-05-25 11:11:32');
INSERT INTO `ri_sessions` VALUES (11, 33, 'author', '2011-05-25 11:11:33');
INSERT INTO `ri_sessions` VALUES (12, 33, 'author', '2011-05-25 11:36:02');
INSERT INTO `ri_sessions` VALUES (13, 33, 'author', '2011-05-25 11:36:25');
INSERT INTO `ri_sessions` VALUES (14, 33, 'author', '2011-05-25 11:44:14');
INSERT INTO `ri_sessions` VALUES (15, 33, 'author', '2011-05-25 11:44:22');
INSERT INTO `ri_sessions` VALUES (16, 33, 'author', '2011-05-25 11:44:43');
INSERT INTO `ri_sessions` VALUES (17, 33, 'author', '2011-05-25 11:46:54');
INSERT INTO `ri_sessions` VALUES (18, 33, 'author', '2011-05-25 11:47:05');
INSERT INTO `ri_sessions` VALUES (19, 33, 'author', '2011-05-25 11:57:46');
INSERT INTO `ri_sessions` VALUES (20, 33, 'author', '2011-05-25 19:08:33');
INSERT INTO `ri_sessions` VALUES (21, 33, 'author', '2011-05-26 14:11:32');
INSERT INTO `ri_sessions` VALUES (22, 33, 'author', '2011-05-26 14:38:20');
INSERT INTO `ri_sessions` VALUES (23, 33, 'author', '2011-05-26 14:58:43');
INSERT INTO `ri_sessions` VALUES (24, 33, 'author', '2011-05-26 15:06:38');
INSERT INTO `ri_sessions` VALUES (25, 33, 'author', '2011-05-26 15:07:25');
INSERT INTO `ri_sessions` VALUES (26, 33, 'author', '2011-05-28 09:12:01');
INSERT INTO `ri_sessions` VALUES (27, 33, 'author', '2011-05-28 09:35:01');
INSERT INTO `ri_sessions` VALUES (28, 33, 'author', '2011-06-02 11:54:04');
INSERT INTO `ri_sessions` VALUES (29, 677, 'author', '2011-06-02 12:44:22');
INSERT INTO `ri_sessions` VALUES (30, 677, 'author', '2011-06-02 12:45:12');
INSERT INTO `ri_sessions` VALUES (31, 678, 'author', '2011-06-02 12:46:00');
INSERT INTO `ri_sessions` VALUES (32, 680, 'author', '2011-06-02 12:52:28');
INSERT INTO `ri_sessions` VALUES (33, 681, 'author', '2011-06-02 13:12:43');
INSERT INTO `ri_sessions` VALUES (34, 681, 'author', '2011-06-02 14:06:51');
INSERT INTO `ri_sessions` VALUES (35, 685, 'author', '2011-06-02 18:12:24');
INSERT INTO `ri_sessions` VALUES (36, 1, 'author', '2011-06-11 18:30:04');
INSERT INTO `ri_sessions` VALUES (37, 1, 'worker', '2011-06-11 18:45:59');
INSERT INTO `ri_sessions` VALUES (38, 33, 'author', '2011-06-11 19:00:54');
INSERT INTO `ri_sessions` VALUES (39, 1, 'worker', '2011-06-11 19:01:21');
INSERT INTO `ri_sessions` VALUES (40, 1, 'worker', '2011-06-11 21:02:32');
INSERT INTO `ri_sessions` VALUES (41, 1, 'worker', '2011-06-11 22:15:02');
INSERT INTO `ri_sessions` VALUES (42, 1, 'worker', '2011-06-11 22:16:57');
INSERT INTO `ri_sessions` VALUES (43, 1, 'worker', '2011-06-11 22:21:23');
INSERT INTO `ri_sessions` VALUES (44, 1, 'worker', '2011-06-12 07:51:48');
INSERT INTO `ri_sessions` VALUES (45, 33, 'author', '2011-06-12 08:20:08');
INSERT INTO `ri_sessions` VALUES (46, 1, 'worker', '2011-06-13 09:08:30');
INSERT INTO `ri_sessions` VALUES (47, 33, 'author', '2011-06-13 11:07:51');
INSERT INTO `ri_sessions` VALUES (48, 1, 'worker', '2011-06-13 11:51:45');
INSERT INTO `ri_sessions` VALUES (49, 1, 'worker', '2011-06-13 11:52:32');
INSERT INTO `ri_sessions` VALUES (50, 33, 'author', '2011-06-13 11:53:10');
INSERT INTO `ri_sessions` VALUES (51, 1, 'worker', '2011-06-13 15:16:43');
INSERT INTO `ri_sessions` VALUES (52, 33, 'author', '2011-06-13 15:19:49');
INSERT INTO `ri_sessions` VALUES (53, 33, 'author', '2011-06-13 16:39:02');
INSERT INTO `ri_sessions` VALUES (54, 1, 'worker', '2011-06-13 16:39:19');
INSERT INTO `ri_sessions` VALUES (55, 1, 'worker', '2011-06-13 16:43:15');
INSERT INTO `ri_sessions` VALUES (56, 33, 'author', '2011-06-13 19:05:49');
INSERT INTO `ri_sessions` VALUES (57, 1, 'worker', '2011-06-14 08:44:29');
INSERT INTO `ri_sessions` VALUES (58, 1, 'worker', '2011-06-14 09:32:23');
INSERT INTO `ri_sessions` VALUES (59, 33, 'author', '2011-06-14 12:14:47');
INSERT INTO `ri_sessions` VALUES (60, 1, 'worker', '2011-06-14 17:04:38');
INSERT INTO `ri_sessions` VALUES (61, 33, 'author', '2011-06-16 07:57:31');
INSERT INTO `ri_sessions` VALUES (62, 1, 'worker', '2011-06-16 18:30:56');
INSERT INTO `ri_sessions` VALUES (63, 1, 'worker', '2011-06-16 19:02:23');
INSERT INTO `ri_sessions` VALUES (64, 33, 'author', '2011-06-16 19:16:44');
INSERT INTO `ri_sessions` VALUES (65, 1, 'worker', '2011-06-16 19:17:45');
INSERT INTO `ri_sessions` VALUES (66, 1, 'worker', '2011-06-16 19:23:51');
INSERT INTO `ri_sessions` VALUES (67, 1, 'worker', '2011-06-16 19:46:07');
INSERT INTO `ri_sessions` VALUES (68, 1, 'worker', '2011-06-17 17:08:04');
INSERT INTO `ri_sessions` VALUES (69, 33, 'author', '2011-06-17 17:17:27');
INSERT INTO `ri_sessions` VALUES (70, 1, 'worker', '2011-06-17 17:24:56');
INSERT INTO `ri_sessions` VALUES (71, 1, 'worker', '2011-06-18 09:35:37');
INSERT INTO `ri_sessions` VALUES (72, 125, 'author', '2011-06-18 13:00:17');
INSERT INTO `ri_sessions` VALUES (73, 1, 'worker', '2011-06-18 13:04:06');
INSERT INTO `ri_sessions` VALUES (74, 1, 'worker', '2011-06-21 11:44:29');
INSERT INTO `ri_sessions` VALUES (75, 1, 'worker', '2011-06-21 16:12:24');
INSERT INTO `ri_sessions` VALUES (76, 1, 'worker', '2011-06-22 13:07:05');
INSERT INTO `ri_sessions` VALUES (77, 1, 'worker', '2011-06-24 13:07:34');
INSERT INTO `ri_sessions` VALUES (78, 33, 'author', '2011-06-24 13:12:17');
INSERT INTO `ri_sessions` VALUES (79, 1, 'worker', '2011-06-24 13:36:31');
INSERT INTO `ri_sessions` VALUES (80, 33, 'author', '2011-06-24 14:36:58');
INSERT INTO `ri_sessions` VALUES (81, 1, 'worker', '2011-07-29 13:50:29');
INSERT INTO `ri_sessions` VALUES (82, 1, 'worker', '2011-07-30 10:16:14');
INSERT INTO `ri_sessions` VALUES (83, 33, 'author', '2011-08-02 08:10:18');
INSERT INTO `ri_sessions` VALUES (84, 33, 'author', '2011-08-02 12:16:28');
INSERT INTO `ri_sessions` VALUES (85, 1, 'worker', '2011-08-05 07:47:46');
INSERT INTO `ri_sessions` VALUES (86, 1, 'worker', '2011-08-05 09:03:08');
INSERT INTO `ri_sessions` VALUES (87, 33, 'author', '2011-08-09 11:01:09');
INSERT INTO `ri_sessions` VALUES (88, 33, 'author', '2011-08-16 09:58:04');
INSERT INTO `ri_sessions` VALUES (89, 33, 'author', '2011-09-13 16:08:12');
INSERT INTO `ri_sessions` VALUES (90, 33, 'author', '2011-10-14 14:02:59');
INSERT INTO `ri_sessions` VALUES (91, 33, 'author', '2011-10-19 10:51:14');
INSERT INTO `ri_sessions` VALUES (92, 1, 'worker', '2011-10-20 13:33:33');
INSERT INTO `ri_sessions` VALUES (93, 1, 'worker', '2011-10-20 13:53:03');
INSERT INTO `ri_sessions` VALUES (94, 1, 'worker', '2011-10-23 13:01:56');
INSERT INTO `ri_sessions` VALUES (95, 1, 'worker', '2011-11-02 11:44:00');
INSERT INTO `ri_sessions` VALUES (96, 33, 'author', '2011-11-05 17:31:06');
INSERT INTO `ri_sessions` VALUES (97, 33, 'author', '2011-11-05 17:43:47');
INSERT INTO `ri_sessions` VALUES (98, 33, 'author', '2011-11-07 06:50:31');
INSERT INTO `ri_sessions` VALUES (99, 33, 'author', '2011-11-07 09:50:39');
INSERT INTO `ri_sessions` VALUES (100, 33, 'author', '2011-11-07 09:52:54');
INSERT INTO `ri_sessions` VALUES (101, 1, 'worker', '2011-11-07 10:53:36');
INSERT INTO `ri_sessions` VALUES (102, 33, 'author', '2011-11-08 08:15:36');
INSERT INTO `ri_sessions` VALUES (103, 33, 'author', '2011-11-08 08:21:46');
INSERT INTO `ri_sessions` VALUES (104, 33, 'author', '2011-11-08 09:31:31');
INSERT INTO `ri_sessions` VALUES (105, 33, 'author', '2011-11-18 23:21:48');
INSERT INTO `ri_sessions` VALUES (106, 33, 'author', '2011-11-20 18:43:22');
INSERT INTO `ri_sessions` VALUES (107, 33, 'author', '2011-11-21 15:01:21');
INSERT INTO `ri_sessions` VALUES (108, 33, 'author', '2011-11-21 15:51:38');
INSERT INTO `ri_sessions` VALUES (109, 1, 'worker', '2011-11-29 18:41:40');
INSERT INTO `ri_sessions` VALUES (110, 33, 'author', '2011-11-29 18:43:31');
INSERT INTO `ri_sessions` VALUES (111, 1, 'worker', '2011-11-29 18:50:51');
INSERT INTO `ri_sessions` VALUES (112, 1, 'worker', '2011-12-01 16:39:55');
INSERT INTO `ri_sessions` VALUES (113, 33, 'author', '2011-12-10 13:29:00');
INSERT INTO `ri_sessions` VALUES (114, 33, 'author', '2011-12-21 21:18:53');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_statistics`
-- 

CREATE TABLE `ri_statistics` (
  `number` int(11) NOT NULL auto_increment,
  `datatime` datetime NOT NULL default '0000-00-00 00:00:00',
  `table` varchar(40) NOT NULL default '',
  `record_id` int(11) NOT NULL default '0',
  `query_type` varchar(8) NOT NULL default '',
  `mode` varchar(10) NOT NULL default '',
  `initiator` varchar(10) NOT NULL default '',
  `initiator_id` int(11) NOT NULL default '0',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='События таблиц' AUTO_INCREMENT=33 ;

-- 
-- Дамп данных таблицы `ri_statistics`
-- 

INSERT INTO `ri_statistics` VALUES (1, '2011-06-19 13:53:36', 'ri_basket', 19, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (2, '2011-06-19 16:05:41', 'ri_payments', 10, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (3, '2011-06-19 16:05:41', 'ri_basket', 14, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (4, '2011-06-21 18:25:16', 'ri_payments', 18, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (5, '2011-06-21 19:05:20', 'ri_payments', 19, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (6, '2011-06-24 18:09:59', 'ri_basket', 15, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (7, '2011-06-24 18:13:25', 'ri_basket', 15, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (8, '2011-07-29 14:34:05', 'ri_basket', 20, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (9, '2011-07-29 14:36:17', 'ri_basket', 13, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (10, '2011-07-29 14:42:33', 'ri_payments', 20, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (11, '2011-07-29 14:43:02', 'ri_basket', 21, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (12, '2011-10-20 13:37:34', 'ri_payments', 21, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (13, '2011-10-20 13:38:13', 'ri_payments', 22, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (14, '2011-10-20 13:41:19', 'ri_payments', 23, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (15, '2011-10-20 13:42:35', 'ri_payments', 24, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (16, '2011-10-20 13:43:02', 'ri_basket', 12, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (17, '2011-10-20 13:43:08', 'ri_basket', 12, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (18, '2011-10-23 13:03:48', 'ri_payments', 25, 'insert', 'manually', 'customer', 2);
INSERT INTO `ri_statistics` VALUES (19, '2011-10-23 13:05:57', 'ri_basket', 38, 'update', 'manually', 'worker', 1);
INSERT INTO `ri_statistics` VALUES (20, '2011-11-18 12:07:24', 'ri_payments', 26, 'insert', 'manually', 'customer', 12);
INSERT INTO `ri_statistics` VALUES (21, '2011-11-18 12:12:29', 'ri_payments', 27, 'insert', 'manually', 'customer', 13);
INSERT INTO `ri_statistics` VALUES (22, '2011-11-18 21:49:08', 'ri_basket', 50, 'delete', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (23, '2011-11-18 21:49:12', 'ri_basket', 48, 'delete', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (24, '2011-11-18 21:58:13', 'ri_basket', 45, 'delete', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (25, '2011-11-18 21:58:16', 'ri_basket', 55, 'delete', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (26, '2011-11-18 21:58:19', 'ri_basket', 57, 'delete', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (27, '2011-11-18 21:58:23', 'ri_basket', 54, 'delete', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (28, '2011-11-18 21:58:39', 'ri_basket', 51, 'delete', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (29, '2011-11-18 21:59:03', 'ri_payments', 28, 'insert', 'manually', 'customer', 24);
INSERT INTO `ri_statistics` VALUES (30, '2011-11-18 23:19:26', 'ri_basket', 73, 'delete', 'manually', 'customer', 23);
INSERT INTO `ri_statistics` VALUES (31, '2011-11-18 23:19:30', 'ri_basket', 70, 'delete', 'manually', 'customer', 23);
INSERT INTO `ri_statistics` VALUES (32, '2011-11-18 23:19:33', 'ri_basket', 66, 'delete', 'manually', 'customer', 23);

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_user`
-- 

CREATE TABLE `ri_user` (
  `number` int(11) NOT NULL auto_increment,
  `data` date NOT NULL default '0000-00-00',
  `login` varchar(60) NOT NULL default '',
  `pass` varchar(30) NOT NULL default '',
  `name` varchar(30) NOT NULL default '',
  `family` varchar(50) NOT NULL default '',
  `otch` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `phone` varchar(20) NOT NULL default '',
  `mobila` varchar(20) NOT NULL default '',
  `workphone` varchar(15) NOT NULL default '',
  `dopphone` varchar(15) NOT NULL default '',
  `city` varchar(50) NOT NULL default '',
  `uchzav` int(11) NOT NULL default '0',
  `account` int(11) NOT NULL default '0',
  `icq` varchar(20) NOT NULL default '',
  `last_zakaz` int(11) NOT NULL default '0',
  `WMR` varchar(50) NOT NULL default '',
  `WMZ` varchar(50) NOT NULL default '',
  `WME` varchar(50) NOT NULL default '',
  `YmoneY` varchar(50) NOT NULL default '',
  `BankAcc` longtext NOT NULL,
  `howmach` int(11) NOT NULL default '0',
  `myurl` varchar(255) NOT NULL default '',
  `myurltime` varchar(255) NOT NULL default '',
  `authors_free` varchar(255) NOT NULL default '',
  `customer_free` varchar(255) NOT NULL default '',
  `worx_free` varchar(255) NOT NULL default '',
  `cron_time` varchar(255) NOT NULL default '',
  `user_id` varchar(255) NOT NULL default '',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=691 ;

-- 
-- Дамп данных таблицы `ri_user`
-- 

INSERT INTO `ri_user` VALUES (1, '2004-04-23', 'admin@referats.info', 'historically', 'Реальное имя', 'Клевцов', '', '', '', '', '', '', '', 1, 0, '', 4383, '', '', '', '', '', 0, '', '', '', '', '', '', 'admin@referats.info');
INSERT INTO `ri_user` VALUES (47, '2005-01-06', 'club_ii@mail.ru', 'club', '', 'club', '', '', '(81651)42-388', 'нет', '', '', ' Демянск', 0, 0, 'нет', 36, '', '', '', '', '', 0, '', '', '', '', '', '', 'club_ii@mail.ru');
INSERT INTO `ri_user` VALUES (48, '2005-01-11', 'udovenko@tagmet.ru', '221179', '', 'Cigar', '', '', '((86344))4-61-58', '', '', '', 'Таганрог', 0, 0, '230144508', 24, '', '', '', '', 'Банк - ОАО РАКБ "Донхлеббанк" г. Таганрог, ИНН банка', 0, '', '', '', '', '', '', 'udovenko@tagmet.ru');
INSERT INTO `ri_user` VALUES (67, '2005-02-27', 'activesite@mail.ru', 'activesite', '', 'Алексей', '', '', '', '8-050-351-22-34', '', '', 'Kiev', 0, 0, '', 43, '', '', '', '', '', 2000, 'refsbank.info', '', 'refsbank.info;', 'infoworks.com.ua;', 'info.activesite.com.ua;', '', 'activesite@mail.ru');
INSERT INTO `ri_user` VALUES (45, '2005-01-05', 'mmt22@mail.ru', 'ccccccc', '', 'light', '', '', '()', '', '', '', 'Иркутск', 0, 0, '68265538', 26, '', '', '', '', '', 0, '', '', '', '', '', '', 'mmt22@mail.ru');
INSERT INTO `ri_user` VALUES (31, '2004-12-16', 'nbiryukova@yandex.ru', 'lexicology', '', 'nbiryukova', '', '', '', '', '', '', 'Taganrog', 26, 0, '', 1733, '', '', '', '', '', 0, '', '', '', '', '', '', 'nbiryukova@yandex.ru');
INSERT INTO `ri_user` VALUES (49, '2005-01-11', 'jannettenova@yandex.ru', 'nova', '', 'jannette', '', '', '', '', '', '', 'Kherson', 0, 0, '', 24, 'R', 'Z', 'E', '', '', 0, '', '', '', '', '', '', 'jannettenova@yandex.ru');
INSERT INTO `ri_user` VALUES (33, '2004-12-27', 'srgg140201@yandex.ru', 'history', 'Сергейюшко', 'Клевченковский', 'Вольдемарович', '', '(8634)383528, 451245', '89044428447', '48503503', '98575785', 'Таганрог', 0, 0, '29894257', 2335, 'R190496965648', 'Z975922213018', 'E833960008390', '4100113867457', 'тутта!', 1000, 'blog.2-all.com', '', '', '', '', '', 'srgg140201@yandex.ru');
INSERT INTO `ri_user` VALUES (34, '2004-12-29', 'lexiusik@mail.ru', 'lexmein', '', 'lex', '', '', '()', '89185175630', '', '', 'Таганрог', 0, 0, '', 108, '', '', '', '', '', 0, '', '', '', '', '', '', 'lexiusik@mail.ru');
INSERT INTO `ri_user` VALUES (35, '2004-12-29', 'ivan_1979@ukrtop.com', 'vano5806', '', 'Ivan79', '', '', '()', '', '', '', 'Брянск', 0, 0, '264110493', 24, 'R616650695864', 'Z591252702087', 'E151809205454', '', '', 0, '', '', '', '', '', '', 'ivan_1979@ukrtop.com');
INSERT INTO `ri_user` VALUES (36, '2004-12-30', 'smirnova1978@yahoo.com', '111111', '', 'LOLO', '', '', '()', '89161240906', '', '', 'Москва', 0, 0, '', 379, '', '', '', '4100121621092', '?', 0, '', '', '', '', '', '', 'smirnova1978@yahoo.com');
INSERT INTO `ri_user` VALUES (37, '2005-01-02', 'morisvilhall@mail.ru', 'yanina', '', 'MORIS', '', '', '( 38048)256468', ' 380397387591', '', '', 'Одесса', 0, 0, '258044031', 26, '', '', '', '', '', 0, '', '', '', '', '', '', 'morisvilhall@mail.ru');
INSERT INTO `ri_user` VALUES (38, '2005-01-02', 'getman_elena@mail.ru', '281256', '', 'getman', '', '', '', '', '', '', 'Новосибирск', 0, 0, '', 755, 'R687328288445', 'Z050269815923', 'E797779999128', '4100122940123', '', 0, '', '', '', '', '', '', 'getman_elena@mail.ru');
INSERT INTO `ri_user` VALUES (39, '2005-01-02', 'valkiria2@mail.ru', '3814', '', 'helena', '', '', '(8464)961417', '8*9272914719', '', '', 'Сызрань', 0, 0, '71021758', 26, '', '', '', '4100113680810', 'Вот реквизиты отделения банка.', 0, '', '', '', '', '', '', 'valkiria2@mail.ru');
INSERT INTO `ri_user` VALUES (40, '2005-01-02', 'zvezdylka@yandex.ru', 'ktyecbr', '', 'Алена', '', '', '()', '', '', '', 'Москва', 0, 0, '145246770', 138, '', '', '', '4100123115266', '', 0, '', '', '', '', '', '', 'zvezdylka@yandex.ru');
INSERT INTO `ri_user` VALUES (41, '2005-01-02', 'r101@hotbox.ru', 'r555r555', '', 'r101', '', '', '(8442)32-01-39', '89033742750', '', '', 'Волгоград', 0, 0, '', 175, '', '', '', '4100113217378', '', 0, '', '', '', '', '', '', 'r101@hotbox.ru');
INSERT INTO `ri_user` VALUES (42, '2005-01-02', 'nad@nm.ru', 'nadaspirant', '', 'aspirant', '', '', '()', '', '', '', 'Казань', 0, 0, '310369179', 38, '', '', '', '4100114761392', '', 0, '', '', '', '', '', '', 'nad@nm.ru');
INSERT INTO `ri_user` VALUES (43, '2005-01-02', 'by4kova@mail.ru', 'l2e5n0a4', '', 'Helen', '', '', '(863)276 34 91', '89289131200', '', '', 'Ростов-на-Дону', 0, 0, '', 52, '', '', '', '', '', 0, '', '', '', '', '', '', 'by4kova@mail.ru');
INSERT INTO `ri_user` VALUES (44, '2005-01-04', 'ingwar@inbox.ru', '1968', '', 'Кучеренко Игорь Александрович', '', '', '39-31-42', '', '', '', 'Таганрог', 0, 0, '', 26, 'R', 'Z', 'E', '', '', 0, '', '', '', '', '', '', 'ingwar@inbox.ru');
INSERT INTO `ri_user` VALUES (50, '2005-01-11', 'egrozeba@yandex.ru', 'qwerty', 'Zeliboba', '', '', '', '()', '8(928)9106624', '111111111111', '', 'Taganrog', 0, 0, '', 4471, '', '', '', '', '', 0, '', '', '', '', '', '', 'egrozeba@yandex.ru');
INSERT INTO `ri_user` VALUES (51, '2005-01-18', 'katya@referats.info', 'history', '', 'Diplom.Katya', '', '', '', '', '', '', 'Taganrog', 0, 0, '', 75, 'R', 'Z', 'E', '', '', 0, '', '', '', '', '', '', 'katya@referats.info');
INSERT INTO `ri_user` VALUES (52, '2005-01-22', 'marina100979@yandex.ru', '100979', 'Реальное имя', 'marina100979', '', '', '()', '89185052578', '36-25-82 + 114', '', 'Таганрог', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'marina100979@yandex.ru');
INSERT INTO `ri_user` VALUES (53, '2005-01-23', 'elena1983_05@mail.ru', '8401641', 'Реальное имя', 'Diplom.Elena', '', '', '600029', '89054569101', '383528', '', 'Таганрог', 0, 0, '', 40, 'R', 'Z', 'E', '', '', 1000, '', '', '', '', '', '', 'elena1983_05@mail.ru');
INSERT INTO `ri_user` VALUES (54, '2005-01-24', 'varya_kv@mail.ru', '4100', 'varya_kv@mail.ru', '', '', '', '(81366)469-14', '921-302-09-96', '', '', 'Ленинградская область, город Пикалево', 0, 0, '', 2666, '', '', '', '4100168280932', '', 0, '', '', '', '', '', '', 'varya_kv@mail.ru');
INSERT INTO `ri_user` VALUES (55, '2005-01-26', 'okssell@mail.ru', 'kiska2002', '', 'okssell', '', '', '', '8916-640-09-97', '', '', 'Москва', 0, 0, '', 27, '', '', '', '', '', 10, '', '', '', '', '', '', 'okssell@mail.ru');
INSERT INTO `ri_user` VALUES (64, '2005-02-12', 'payment@diplom.com.ru', 'life', '', 'srgg.payment', '', '', '', '', '', '', 'tag-22', 0, 0, '', 0, '', '', '', '', '', 150, 'srgg.by.ru', '', 'colock.ru;', 'fgthyuu.com;', 'monax.ru;', '', 'payment@diplom.com.ru');
INSERT INTO `ri_user` VALUES (57, '2005-02-08', 'verbena72@mail.ru', 'ROMANOVKA', '', '', '', '', '(0652)44-29-43', '', '', '', 'Симферополь', 0, 0, '', 2083, '', '', '', '', '', 0, '', '', '', '', '', '', 'verbena72@mail.ru');
INSERT INTO `ri_user` VALUES (58, '2005-02-09', 'julikcalujny@mail.ru', 'vjhjp777', '', 'JULIK', '', '', '(3142)392099', '', '', '', 'Костанай Казахстан', 0, 0, '', 40, '', '', '', '', '', 0, '', '', '', '', '', '', 'julikcalujny@mail.ru');
INSERT INTO `ri_user` VALUES (59, '2005-02-09', 'refer2004@mail.ru', 'jnkbxyj', '', 'Юрий', '', '', '', '', '8142517952', '', 'Петрозаводск', 0, 0, '', 1525, '', '', '', '', '', 1100, '', '', '', '', '', '', 'refer2004@mail.ru');
INSERT INTO `ri_user` VALUES (60, '2005-02-11', 'ershova-elena@mail.ru', 'rfkjif', '', 'ershova-elena@mail.r', '', '', '(835)663630', '89022885054', '', '', 'Чебоксары', 0, 0, '', 421, '', '', '', '', '', 0, '', '', '', '', '', '', 'ershova-elena@mail.ru');
INSERT INTO `ri_user` VALUES (61, '2005-02-11', 'megastar8@yandex.ru', '9087039zx', 'Елена', '', '', '', '8 (495) 242-34-65', '8 (926) 228-02-87', '', '', 'Нижний Новгород', 0, 0, '289018500', 784, 'R225859365361', 'Z431259164199', 'E287490222363', '4100131633184', '', 0, '', '', '', '', '', '', 'megastar8@yandex.ru');
INSERT INTO `ri_user` VALUES (71, '2005-03-21', 'baleksandra@mail.ru', '4682', '', 'sansan', '', '', '()', '8 903 820 88 53', '', '', 'Ярославль', 0, 0, '256722670', 2275, '', '', '', '', '', 0, '', '', '', '', '', '', 'baleksandra@mail.ru');
INSERT INTO `ri_user` VALUES (65, '2005-02-16', 'gizmo@attack.ru', 'cancel', '', 'gizmo', '', '', '', '', '', '', 'Бырбыр', 0, 0, '', 0, '', '', '', '', '', 20000, '', '', '', '', '', '', 'gizmo@attack.ru');
INSERT INTO `ri_user` VALUES (66, '2005-02-20', 'janna12000@mail.ru', '19722', '', 'janna', '', '', '(812)3773221', '9215724688', '', '', 'Санкт-Петербург', 0, 0, '', 127, '', '', '', '', '', 0, '', '', '', '', '', '', 'janna12000@mail.ru');
INSERT INTO `ri_user` VALUES (68, '2005-03-01', 'Alkion-vips@mail.ru', 'wert', '', 'Alkion', '', '', '(8342)355152', '89053894970', '', '', 'Саранск', 0, 0, '198898692', 952, '', '', '', '', '', 0, '', '', '', '', '', '', 'Alkion-vips@mail.ru');
INSERT INTO `ri_user` VALUES (69, '2005-03-03', 'nelepov@deagnostic.ru', 'ltymub', '', 'Mamont', '', '', '8 8634 395404', '', '8 8634 312165', '', 'Таганрог', 0, 0, '130011565', 103, '', '', '', '', '', 3, '', 'по возможности', '', '', '', '', 'nelepov@deagnostic.ru');
INSERT INTO `ri_user` VALUES (70, '2005-03-07', 'budeykin@mail.ru', 'budeykin@mail.ru', '', 'budeykin@mail.ru', '', '', '', '', '', '', 'Новосибирск', 0, 0, '', 51, '', '', '', '', '', 10, '', '', '', '', '', '', 'budeykin@mail.ru');
INSERT INTO `ri_user` VALUES (72, '2005-03-24', 'krasa_16@pisem.net', '0480', 'krasa_16@pisem.net', '', '', '', '(86147)23249', ' 79184743573', '86147  31400', '', 'Курганинск', 0, 0, '', 2308, '', '', '', '4100126905494', '', 0, '', '', '', '', '', '', 'krasa_16@pisem.net');
INSERT INTO `ri_user` VALUES (73, '2005-03-25', 'fin4@nm.ru', 'f608', '', 'i1n1n1a1', '', '', '(39022)38614', '', '', '', 'Абакан', 0, 0, '', 95, '', '', '', '', '', 0, '', '', '', '', '', '', 'fin4@nm.ru');
INSERT INTO `ri_user` VALUES (74, '2005-03-27', 'WWzhanna@yandex.ru', '1971', '', 'Жанна', '', '', '(88112)162826', '89113662725', '', '', 'Псков', 0, 0, '', 1112, '', '', '', '', '', 0, '', '', '', '', '', '', 'WWzhanna@yandex.ru');
INSERT INTO `ri_user` VALUES (75, '2005-04-06', 'andrei_kr@rambler.ru', 'fylhtq', '', 'SadAngel', '', '', '', '', '', '', 'Кировоград', 0, 0, '', 1311, '721264572536', '682856679298', '335029673141', '', '', 100, '', '', '', '', '', '', 'andrei_kr@rambler.ru');
INSERT INTO `ri_user` VALUES (76, '2005-04-10', 'arsenevai@mail.ru', 'cjkysirj', '', 'Aira', '', '', '(8634)361757', '89044420493', '', '', 'Таганрог', 0, 0, '202917929', 144, '', '', '', '', '', 0, '', '', '', '', '', '', 'arsenevai@mail.ru');
INSERT INTO `ri_user` VALUES (77, '2005-04-16', 'ProfiDiplom@mail.ru', 'ЗкщашВшздщь1978', '', 'ProfiDiplom', '', '', '(095)7998927', '8 905 7559904', '', '', 'г. Москва', 0, 0, '', 79, '', '', '', '', '', 0, '', '', '', '', '', '', 'ProfiDiplom@mail.ru');
INSERT INTO `ri_user` VALUES (78, '2005-04-17', 'jkz0olga@yandex.ru', 'jktymrf', '', 'Лёля', '', '', '', '89167945070', '', '', 'Москва', 0, 0, '', 0, '', '', '', '', '', 1, '', '', '', '', '', '', 'jkz0olga@yandex.ru');
INSERT INTO `ri_user` VALUES (79, '2005-04-17', 'sglana@yahoo.com', 'bharat', '', 'Lana', '', '', '()', '', '', '', 'Казань', 0, 0, '', 150, '', '', '', '', '', 0, '', '', '', '', '', '', 'sglana@yahoo.com');
INSERT INTO `ri_user` VALUES (80, '2005-04-17', 'qwe306@yandex.ru', '426677', '', 'Инна', '', '', '(8442)426677', '', '', '', 'Волгоград', 0, 0, '', 159, '', '', '', '', '', 0, '', '', '', '', '', '', 'qwe306@yandex.ru');
INSERT INTO `ri_user` VALUES (81, '2005-04-17', 'anhelika2000@list.ru', 'bvgthfnhbwf', '', 'Anhelika', '', '', '()', '', '', '', 'Москва', 0, 0, '262008426', 82, '', '', '', '', '', 0, '', '', '', '', '', '', 'anhelika2000@list.ru');
INSERT INTO `ri_user` VALUES (82, '2005-04-17', 'ire_melnik@list.ru', 'ira3579', '', 'irina', '', '', '(044)2745917', ' 380501988077', '', '', 'Киев', 0, 0, '347434252', 82, '', '', '', '', '', 0, '', '', '', '', '', '', 'ire_melnik@list.ru');
INSERT INTO `ri_user` VALUES (83, '2005-04-17', 'fomalhut@mail.ru', 'vesy79', '', 'novostok', '', '', '()', '', '', '', 'Новоуральск', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'fomalhut@mail.ru');
INSERT INTO `ri_user` VALUES (84, '2005-04-17', 'dellli@rambler.ru', '159', '', 'dellli', '', '', '()', '', '', '', 'Ставрополь', 0, 0, '', 89, '', '', '', '', '', 0, '', '', '', '', '', '', 'dellli@rambler.ru');
INSERT INTO `ri_user` VALUES (85, '2005-04-17', 'cool_masha@rambler.ru', 'poison', '', 'Мария', '', '', '(812)2339744', '89213036724', '', '', 'Санкт-Петербург', 0, 0, '323497215', 86, '', '', '', '', '', 50, '', '', '', '', '', '', 'cool_masha@rambler.ru');
INSERT INTO `ri_user` VALUES (86, '2005-04-17', 'calidaon@tochka.ru', 'лошадка', '', 'Яркая', '', '', '()', '', '', '', 'Москва', 0, 0, '', 227, '', '', '', '', '', 0, '', '', '', '', '', '', 'calidaon@tochka.ru');
INSERT INTO `ri_user` VALUES (87, '2005-04-17', 'milik@inbox.ru', '256685', '', 'pahan', '', '', '()', '', '', '', 'житомир', 0, 0, '', 84, '', '', '', '', '', 0, '', '', '', '', '', '', 'milik@inbox.ru');
INSERT INTO `ri_user` VALUES (88, '2005-04-17', 'haritonova-L2004@mail.ru', '208037', '', 'Alena', '', '', '(8452)281403', '', '', '', 'Саратов', 0, 0, '', 92, '', '', '', '', '', 0, '', '', '', '', '', '', 'haritonova-L2004@mail.ru');
INSERT INTO `ri_user` VALUES (89, '2005-04-17', 'yura-design@yandex.ru', '211817', '', 'Yura', '', '', '()', '', '', '', 'Димитровград', 0, 0, '', 84, '', '', '', '', '', 0, '', '', '', '', '', '', 'yura-design@yandex.ru');
INSERT INTO `ri_user` VALUES (90, '2005-04-18', 'vladiva72@mail.ru', 'djoshua', '', 'vladiva72', '', '', '(42622)2-45-01', ' 7-924-640-5961', '', '', 'Биробиджан', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'vladiva72@mail.ru');
INSERT INTO `ri_user` VALUES (91, '2005-04-18', 'peleng@khakasnet.ru', '327261', '', 'Delta', '', '', '()', '', '', '', 'Абакан', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'peleng@khakasnet.ru');
INSERT INTO `ri_user` VALUES (92, '2005-04-18', 'sorokin@online.debryansk.ru', 'gudkova', '', 'aes78', '', '', '()', '', '', '', 'Брянск', 0, 0, '', 83, '', '', '', '', '', 0, '', '', '', '', '', '', 'sorokin@online.debryansk.ru');
INSERT INTO `ri_user` VALUES (93, '2005-04-18', 'renia@aport.ru', '2222', '', 'renia', '', '', '', '8-903-165-74-30', '', '', 'Москва', 0, 0, '', 2455, '', '663041563549', '', '', '', 100, '', '1-2 месяц', '', '', '', '', 'renia@aport.ru');
INSERT INTO `ri_user` VALUES (94, '2005-04-18', 'fialka74@inbox.ru', '040401', '', 'mooncat', '', '', '(812)224-56-71', '8-911-266-33-13', '', '', 'Санкт-Петербург', 0, 0, '', 83, '', '', '', '', '', 0, '', '', '', '', '', '', 'fialka74@inbox.ru');
INSERT INTO `ri_user` VALUES (95, '2005-04-18', 'oksana_tugai@mail.ru', 'to8392', '', 'оксана', '', '', '80732200809', '89066714587', '', '', 'воронеж', 0, 0, '', 108, '', '', '', '', '', 30, '', '', 'студенточка. ru;5 баллов. ru;', 'студенточка. ru;', '5 баллов.ru;', '', 'oksana_tugai@mail.ru');
INSERT INTO `ri_user` VALUES (96, '2005-04-18', 'morediplomov@narod.ru', 'm8002005m', '', 'master', '', '', '()', '', '', '', 'Чебоксары', 0, 0, '194515492', 137, '', '', '', '', '', 0, '', '', '', '', '', '', 'morediplomov@narod.ru');
INSERT INTO `ri_user` VALUES (97, '2005-04-18', 'ellizium@list.ru', 'isik', '', 'Esperanza', '', '', '7198400', '80506602178', '', '', 'Odessa', 0, 0, '305918600', 84, '', '', '', '', '', 20, '', '', '', '', '', '', 'ellizium@list.ru');
INSERT INTO `ri_user` VALUES (98, '2005-04-18', 'semclan@mail.ru', 'semclan', '', 'semclan', '', '', '()', '', '', '', 'Волгоград', 0, 0, '', 833, '', '', '', '', '', 0, '', '', '', '', '', '', 'semclan@mail.ru');
INSERT INTO `ri_user` VALUES (99, '2005-04-19', 'ta_uz@mail.ru', '111', 'ta_uz', '', '', '', '(0572)7140737', '380504066012', '', '', 'Харьков', 0, 0, '', 1603, '', '', '', '', '', 30, '', '', '', '', '', '', 'ta_uz@mail.ru');
INSERT INTO `ri_user` VALUES (100, '2005-04-19', 'trigub@rol.ru', 'триник', '', 'Николай', '', '', '(0832)56-79-88', '8-909-240-84-32', '', '', 'г. Брянск', 0, 0, '', 93, '', '', '', '4100127689889', '', 50, '', '', 'gb.rol.ru;sentyabr.ru;referatw.ru;', 'gb.rol.ru;referatw.ru;', '5ballov.ru;doklad.ru;help-mgsu.narod.ru;refportal.ru;vseved.ru;', '', 'trigub@rol.ru');
INSERT INTO `ri_user` VALUES (101, '2005-04-20', 'Nika2110@bk.ru', 'dthjybrf', '', 'Nika2110', '', '', '()', '8-903-640-77-23', '', '', 'Рязань', 0, 0, '', 96, '', '', '', '', '', 0, '', '', '', '', '', '', 'Nika2110@bk.ru');
INSERT INTO `ri_user` VALUES (102, '2005-04-20', 'darkskies@inbox.ru', 'dark', '', 'Inferno', '', '', '()', '89281000916', '', '', 'Ростов-на-Дону', 0, 0, '207290368', 86, '', '', '', '', '', 0, '', '', '', '', '', '', 'darkskies@inbox.ru');
INSERT INTO `ri_user` VALUES (103, '2005-04-21', 'bratva2003@onego.ru', '797143', '', 'Дмитрий', '', '', '', '+79114109657', '', '', 'Петрозаводск', 0, 0, '', 155, '', '', '', '', '', 250, '', '', 'referat.ru;www.referator.com;', 'mreferat.tora.ru ;www.troek.net;', 'www.monax.ru;referat.studentassist.ru;', '', 'bratva2003@onego.ru');
INSERT INTO `ri_user` VALUES (104, '2005-04-21', 'eltka@mail.ru', 'pabl', '', 'agata', '', '', '(812)585-04-68', '8-9112828505', '', '', 'Санкт-Петербург', 0, 0, '', 89, '', '', '', '', '', 0, '', '', '', '', '', '', 'eltka@mail.ru');
INSERT INTO `ri_user` VALUES (105, '2005-04-23', 'lavrentii_stat@mail.ru', 'lavrik', '', 'Лаврентий Анищенко', '', '', '', '', '', '', 'Кишинев', 0, 0, '63809781', 0, '', '', '', '', '', 1, '', '', 'referat.ru;', 'referat.ru;', 'referat.ru;', '', 'lavrentii_stat@mail.ru');
INSERT INTO `ri_user` VALUES (106, '2005-04-25', 'oldham1978@mail.ru', 'qweasd', '', 'oldham1978', '', '', '()', '', '', '', 'Казань', 0, 0, '', 89, '', '', '', '', '', 0, '', '', '', '', '', '', 'oldham1978@mail.ru');
INSERT INTO `ri_user` VALUES (107, '2005-05-01', 'torris@ngs.ru', 'between', '', 'torris', '', '', '(3832)718284', '89139560494', '', '', 'Новосибирск', 0, 0, '138710393', 95, '', '', '', '', '', 0, '', '', '', '', '', '', 'torris@ngs.ru');
INSERT INTO `ri_user` VALUES (108, '2005-05-02', '3dt@rambler.ru', '179', '', 'Натали', '', '', '()', '', '', '', 'Днепропетровск', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', '3dt@rambler.ru');
INSERT INTO `ri_user` VALUES (109, '2005-05-03', 'dip4sale@yandex.ru', 'фдучгы', '', 'alexus', '', '', '()', '', '', '', 'Москва', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'dip4sale@yandex.ru');
INSERT INTO `ri_user` VALUES (110, '2005-05-03', 'yura5@mail15.com', 'dbiytdcrbq', '', 'Юрий Юров', '', '', 'нет', 'нет', 'нет', '', 'Шахты', 0, 0, '', 557, '', '', '', '', '', 20, '', '', '', '', '', '', 'yura5@mail15.com');
INSERT INTO `ri_user` VALUES (111, '2005-05-04', '_talisman_eva@mail.ru', '201180', '', 'Евгений', '', '', '()', '', '', '', 'Красноярск', 0, 0, '', 96, '', '', '', '', '', 0, '', '', '', '', '', '', '_talisman_eva@mail.ru');
INSERT INTO `ri_user` VALUES (112, '2005-05-04', 'ugbank@obrbank.ru', '191191191', '', 'ugbank', '', '', '()', '(8928) 258-63-16', '', '', 'Карабуак', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'ugbank@obrbank.ru');
INSERT INTO `ri_user` VALUES (113, '2005-05-04', 'andre30@mail.ru', 'вероника', '', 'Ника', '', '', '()', '', '', '', 'Екатеринбург', 0, 0, '', 97, '', '', '', '', '', 0, '', '', '', '', '', '', 'andre30@mail.ru');
INSERT INTO `ri_user` VALUES (114, '2005-05-04', 'helenarybakowa@rambler.ru', '240640', '', 'helenarybakowa', '', '', '(переезжаю)лучшая св', '', '', '', 'Смоленск (пока)', 0, 0, '', 97, '', '', '', '', '', 0, '', '', '', '', '', '', 'helenarybakowa@rambler.ru');
INSERT INTO `ri_user` VALUES (115, '2005-05-04', 'bel11@yandex.ru', '1111', '', 'Антон', '', '', '()', '', '', '', 'Жлобин', 0, 0, '', 4109, '', '', '', '4100112158217', '', 0, '', '', '', '', '', '', 'bel11@yandex.ru');
INSERT INTO `ri_user` VALUES (116, '2005-05-07', 'u2822@pub.ins.dn.ua', 'GutT38dC9', '', 'Игорёк', '', '', '(06264)33206', ' 38 (097) 9303742', '', '', 'Краматорск', 0, 0, '', 103, '', '', '', '', '', 0, '', '', '', '', '', '', 'u2822@pub.ins.dn.ua');
INSERT INTO `ri_user` VALUES (117, '2005-05-07', 'dim-kt2003@yandex.ru', 'lbvjxrf', '', 'Arnold', '', '', '530672', '', '', '', 'Ташкент', 0, 0, '220717685', 0, '', '', '', '', '', 1, '', '', 'economizdat.ru ;e5m.fastbb.ru ;tarasei.narod.ru ;', 'e5m.fastbb.ru ;ppsy.ru ;', 'www.avpu.ru ;dir.profdb.ru ;www.kazan.ru ;', '', 'dim-kt2003@yandex.ru');
INSERT INTO `ri_user` VALUES (118, '2005-05-10', 'purliktv@mail.ru', '121314', '', 'Пурлик Татьяна', '', '', '8-39563-2-25-95', '', '', '', 'Тайшет', 0, 0, '', 154, '', '', '', '', '', 3, '', '', '', '', 'monax.ru;students.ru;', '', 'purliktv@mail.ru');
INSERT INTO `ri_user` VALUES (119, '2005-05-12', 'zybins@mail.ru', '7723954', '', 'SergeZ', '', '', '()', '89024715042', '', '', 'Соликамск', 0, 0, '', 573, '', '', '', '', '', 0, '', '', '', '', '', '', 'zybins@mail.ru');
INSERT INTO `ri_user` VALUES (120, '2005-05-14', 'dargaard@inbox.ru', 'TRISTANIA', '', 'DARGAARD', '', '', '(8452)510652', '89053286278', '', '', 'SARATOV', 0, 0, '193032452', 110, 'R632092398394', 'Z792412428732', 'E993864326061', '4100128699974', '42301810856377056584/01', 0, '', '', '', '', '', '', 'dargaard@inbox.ru');
INSERT INTO `ri_user` VALUES (121, '2005-05-14', 'nikkey74@mail.ru', 'qazxcvb', '', 'nikkey', '', '', '(8452)388353', ' 79047018482', '', '', 'Саратов', 0, 0, '', 140, '', '', '', '', '', 0, '', '', '', '', '', '', 'nikkey74@mail.ru');
INSERT INTO `ri_user` VALUES (122, '2005-05-16', 'zraynins@rambler.ru', '16111983', '', 'Ирина', '', '', '(8442)754974', '8-917-841-5450', '', '', 'Волгоград', 0, 0, '', 1514, '', '', '', '', '', 0, '', '', '', '', '', '', 'zraynins@rambler.ru');
INSERT INTO `ri_user` VALUES (123, '2005-05-19', 'wwwumns1978@mail.ru', 'qweasd', '', 'wwwumns1978', '', '', '', '89172759085', '', '', 'Казань', 0, 0, '', 115, '', '', '', '4100127826822', '', 8, '', '', '', '', '', '', 'wwwumns1978@mail.ru');
INSERT INTO `ri_user` VALUES (124, '2005-05-23', 'auchebnik@inbox.ru', 'qazxcvb', '', 'Nikkey74', '', '', '8452388353', '89047018482', '', '', 'Саратов', 0, 0, '', 120, '417238324825', '048160996260', '969029637786', '4100128457185', '', 800, '', '', '', '', '', '', 'auchebnik@inbox.ru');
INSERT INTO `ri_user` VALUES (125, '2005-05-25', 'Devchonka2005@mail.ru', '208911', 'Яна', '', '', '', '(841-2) 60-91-81', '+79273660940', '', '', 'Заречный', 0, 0, '333855830', 1830, '', '', '', '4100130084107', '', 0, '', '', '', '', '', '', 'Devchonka2005@mail.ru');
INSERT INTO `ri_user` VALUES (126, '2005-05-26', 'nuclearValley@bk.ru', 'lover', '', 'KiLLER', '', '', '(8412)645782', '89022092992', '', '', 'Пенза', 0, 0, '231574943', 140, '', '', '', '', '', 0, '', '', '', '', '', '', 'nuclearValley@bk.ru');
INSERT INTO `ri_user` VALUES (127, '2005-05-27', 'tatusya@front.ru', 'Nataly', '', 'kvitka', '', '', '(095)5712034', '89265234456', '', '', 'Москва', 0, 0, '', 127, '', '', '', '', '', 0, '', '', '', '', '', '', 'tatusya@front.ru');
INSERT INTO `ri_user` VALUES (128, '2005-05-31', 'rybnikovus@mail.ru', '123', '', 'георгий', '', '', '(86392)39088', '89185231668', '', '', 'Волгодонск. Ростовская обл.', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'rybnikovus@mail.ru');
INSERT INTO `ri_user` VALUES (129, '2005-06-02', 'chikshov@atnet.ru', 'chikshova', '', 'chikshova', '', '', '(818 4 (2))55-60-11', '9115741727', '', '', 'Северодвинск', 0, 0, '', 1628, '', '', '', '', 'Сообщаю Вам свои банковские реквизиты:', 0, '', '', '', '', '', '', 'chikshov@atnet.ru');
INSERT INTO `ri_user` VALUES (130, '2005-06-04', 'Igitova@bk.ru', '08082004', '', 'Екатерина', '', '', '8(634)45110', '8904-343-80-47', '', '', 'Таганрог', 0, 0, '', 137, '', '', '', '', '', 20, '', '', '', '', '', '', 'Igitova@bk.ru');
INSERT INTO `ri_user` VALUES (131, '2005-06-06', 'djatlov@mail.ru', 'dcp', '', 'Djatlova', '', '', '(8443)250771', '9033165660', '', '', 'Волжский', 0, 0, '', 581, '', '', '', '', '', 0, '', '', '', '', '', '', 'djatlov@mail.ru');
INSERT INTO `ri_user` VALUES (132, '2005-06-11', 'Natalinka1971@mail.ru', 'Votkinsk', '', 'кепка', '', '', '()', '', '', '', 'Воткинск', 0, 0, '', 138, '', '', '', '', '', 0, '', '', '', '', '', '', 'Natalinka1971@mail.ru');
INSERT INTO `ri_user` VALUES (133, '2005-06-12', 'c.rbi@bk.ru', 'djdjxrf', '', 'project', '', '', '()', '', '', '', 'Якутск РС (Якутия)', 0, 0, '', 138, '', '', '', '', '', 0, '', '', '', '', '', '', 'c.rbi@bk.ru');
INSERT INTO `ri_user` VALUES (134, '2005-06-14', 'sveta1980q@mail.ru', '7058625', '', 'svetlanka', '', '', '(095)7058625', '89166676469', '', '', 'Москва', 0, 0, '', 1634, '', '', '', '', '', 0, '', '', '', '', '', '', 'sveta1980q@mail.ru');
INSERT INTO `ri_user` VALUES (135, '2005-06-20', 'pustk@mail.ru', '141522', '', 'Прохоров Алексей Александрович', '', '', '', '', '', '', 'Москва', 0, 0, '', 173, '', '', '', '', '', 70, '', '40 дней', '', '', '', '', 'pustk@mail.ru');
INSERT INTO `ri_user` VALUES (136, '2005-06-25', 'e1811@yandex.ru', '2027', '', 'Tyron', '', '', '(83130)60054', '89051936831', '', '', 'Саров Нижегород обл', 0, 0, '', 796, '', '', '', '', '', 0, '', '', '', '', '', '', 'e1811@yandex.ru');
INSERT INTO `ri_user` VALUES (137, '2005-06-26', 'ponomareva2_mspb@mail.ru', 'igorigor', '', 'Irina16021981', '', '', '()', '8-921-180-76-20', '', '', 'С-Петербург', 0, 0, '241-589-753', 148, '', '', '', '', '', 0, '', '', '', '', '', '', 'ponomareva2_mspb@mail.ru');
INSERT INTO `ri_user` VALUES (138, '2005-06-27', 'ekonom7@rambler.ru', '27impt6', '', 'киргиз', '', '', '()', '89023251607', '', '', 'Йошкар-Ола', 0, 0, '204-260-144', 315, '', '', '', '4100126150020', '', 0, '', '', '', '', '', '', 'ekonom7@rambler.ru');
INSERT INTO `ri_user` VALUES (139, '2005-06-27', 'rosavetrov@inbox.ru', '121212', '', 'Роза', '', '', '', '', '', '', 'Москва', 0, 0, '', 142, '', '', '', '', '', 100, '', '', '', '', '', '', 'rosavetrov@inbox.ru');
INSERT INTO `ri_user` VALUES (140, '2005-07-17', 'willi@dlm.ru', '4n%6323', '', 'Wilhelm', '', '', '83537253925', '83537396085', '', '', 'Орск', 0, 0, '236345931', 151, '575451590548', '279889109681', '870775741025', '4100119631494', '', 400, '', '', 'referat.ru;', 'referat.ru;', 'referat.ru;monah.ru;', '', 'willi@dlm.ru');
INSERT INTO `ri_user` VALUES (141, '2005-07-28', 'olegmilov@rambler.ru', 'igoryok', '', 'olegmilov', '', '', '(8512)308339', '89033483825', '', '', 'Астрахань', 0, 0, '', 895, '', '', '', '', '', 0, '', '', '', '', '', '', 'olegmilov@rambler.ru');
INSERT INTO `ri_user` VALUES (142, '2005-08-01', 'otlichnik@infomost.ru', 'otlichnik', '', 'otlichnik', '', '', '8(8452)-22-96-07', '8(904)-243-79-71', '', '', 'Saratov', 0, 0, '', 181, '', '', '', '4100129734124', '', 2000, '', '30 days', 'diplomz.com.ru;diplom.us;', 'forum.comchatka.ru;rbz.ru;prospect-omsk.ru;', '5balov.ru ;referatov.net;4students.ru;', '', 'otlichnik@infomost.ru');
INSERT INTO `ri_user` VALUES (143, '2005-08-10', 'breamkerr2004@bk.ru', '0987654', '', 'pavel', '', '', '()', '', '', '', 'Краснодар', 0, 0, '', 259, '', '', '', '', '', 0, '', '', '', '', '', '', 'breamkerr2004@bk.ru');
INSERT INTO `ri_user` VALUES (144, '2005-08-14', 'kleo_neo@mail.ru', 'kadriya', '', 'Kleo', '', '', '()', ' 78129132324', '', '', 'Санкт-Петербург', 0, 0, '', 821, '', '', '', '', '', 0, '', '', '', '', '', '', 'kleo_neo@mail.ru');
INSERT INTO `ri_user` VALUES (145, '2005-08-15', 'art8008@list.ru', 'hjgbt,ytvj', '', 'Art', '', '', '(8634)310584', ' 79094140080', '', '', 'Таганрог', 0, 0, '', 172, '', '', '', '', '', 0, '', '', '', '', '', '', 'art8008@list.ru');
INSERT INTO `ri_user` VALUES (146, '2005-08-18', 'ankazansky@yandex.ru', 'hs;bq2005', '', '', '', '', '(0932)324275', '', '', '', 'Иваново', 0, 0, '', 3757, '', '', '', '4100142729652', '', 0, '', '', '', '', '', '', 'ankazansky@yandex.ru');
INSERT INTO `ri_user` VALUES (147, '2005-08-25', 'korny81@mail.ru', '567030', '', 'Veronika', '', '', '(3812)567030', '89059409492', '', '', 'Омск', 0, 0, '', 0, '', '', '', '4100120808396', '', 0, '', '', '', '', '', '', 'korny81@mail.ru');
INSERT INTO `ri_user` VALUES (148, '2005-08-29', 'ikclezin@mail.ru', '123961', '', 'Вася', '', '', '(095)1524316', '89035707452', '', '', 'Москва', 0, 0, '', 4282, '', '', '', '', '', 0, '', '', '', '', '', '', 'ikclezin@mail.ru');
INSERT INTO `ri_user` VALUES (149, '2005-09-02', 'sanvik@mail15.com', '23021973', '', 'Ya', '', '', '()', '89222564252', '', '', 'Пермь', 0, 0, '', 159, '', '', '', '', '', 0, '', '', '', '', '', '', 'sanvik@mail15.com');
INSERT INTO `ri_user` VALUES (150, '2005-09-05', 'ikclezin83@mail.ru', '123961', '', 'Василий', '', '', '', '89264224010', '89264224010', '', '2005', 0, 0, '', 159, '', '', '', '', '', 2, '', '', 'referat.ru;kulichki.ru;', 'referat.ru;kulichki.ru;', 'bankreferatov.ru;referat.ru;kulichki.ru;', '', 'ikclezin83@mail.ru');
INSERT INTO `ri_user` VALUES (151, '2005-09-19', 'katya_asanova@mail.ru', 'english', '', 'Ekaterina', '', '', '(3412)525741', ' 79043197366', '', '', 'Ижевск', 0, 0, '', 169, '', '', '', '', '', 0, '', '', '', '', '', '', 'katya_asanova@mail.ru');
INSERT INTO `ri_user` VALUES (152, '2005-09-19', 'sl-smirnova@yandex.ru', 'mitya', '', 'ssmirnova', '', '', '()', '', '', '', 'Москва', 0, 0, '', 494, '', '', '', '', '', 0, '', '', '', '', '', '', 'sl-smirnova@yandex.ru');
INSERT INTO `ri_user` VALUES (153, '2005-09-19', 'urisdiplom@mail.ru', '22101978', '', 'urisdiplom', '', '', '(8793)37-33-28', '(906) 461-28-03', '', '', 'Пятигорск', 0, 0, '', 876, '', '', '', '', '', 0, '', '', '', '', '', '', 'urisdiplom@mail.ru');
INSERT INTO `ri_user` VALUES (154, '2005-09-21', 'dtp2004@yandex.ru', '260679', 'Автор', '', '', '', '', '89607549644', '', '', 'Красноярск', 0, 0, '', 1514, '', '', '', '4100179730077', '', 500, '', '', 'x-gold.ru;', 'x-gold.ru;', 'x-gold.ru;', '', 'dtp2004@yandex.ru');
INSERT INTO `ri_user` VALUES (155, '2005-09-22', 'tkk80@mail.ru', 'Rainbow_BL', 'Реальное имя', 'kirill', '', '', '(8634)323689', ' 79034323815', '', '', 'Таганрог', 0, 0, '', 915, '', '', '', '', '', 0, '', '', '', '', '', '', 'tkk80@mail.ru');
INSERT INTO `ri_user` VALUES (156, '2005-09-30', 'diksi@smtp.ru', 'cevvf', '', 'Donya', '', '', '', '+79043859489', '', '+79030865492', 'Серов', 0, 0, '', 205, '151038616456', '', '', '', '', 10, '', '', '', '', '', '', 'diksi@smtp.ru');
INSERT INTO `ri_user` VALUES (157, '2005-09-30', '', '', 'Чиста рэальное иМья', '', '', '', '', '', '', '', '', 0, 0, '', 4471, '', '', '', '', '', 0, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (158, '2005-10-11', 'lokovpered@yandex.ru', '312644', '', 'Nikka', '', '', '', '89059416500', '', '', 'Омск, Россия', 0, 0, '', 1832, '', '', '', '4100120808396', '', 10, '', '', '', '', '', '', 'lokovpered@yandex.ru');
INSERT INTO `ri_user` VALUES (159, '2005-10-15', 'rosita05@bk.ru', 'qazws', '', '', '', '', '()', '89044050736', '', '', 'волгоград', 0, 0, '', 545, '', '', '', '', '', 0, '', '', '', '', '', '', 'rosita05@bk.ru');
INSERT INTO `ri_user` VALUES (160, '2005-10-16', 'sdvdashutka@mail.ru', 'burkin', '', 'Даша', '', '', '', '89092637431', '', '', 'Тула', 0, 0, '', 220, '140546302012', '', '', '', '', 20, '', '', 'morereferatov.ru;studybank.info;', 'bankreferatov.ru;', 'bankreferatov.ru;', '', 'sdvdashutka@mail.ru');
INSERT INTO `ri_user` VALUES (161, '2005-10-21', 'tamara.iln@mail.ru', 'spartak', '', 'тамара', '', '', '(3912)550356', ' 79138375423', '', '', 'Красноярск', 0, 0, '', 4271, '', '', '', '', '', 0, '', '', '', '', '', '', 'tamara.iln@mail.ru');
INSERT INTO `ri_user` VALUES (162, '2005-10-21', 'anna98@inbox.ru', '12345', '', 'Анастасия05', '', '', '(095)166-98-79', '8-906-751-43-19', '', '', 'Москва', 0, 0, '', 664, '', '', '', '', '', 0, '', '', '', '', '', '', 'anna98@inbox.ru');
INSERT INTO `ri_user` VALUES (163, '2005-10-21', 'e1ena@inbox.ru', '0157114', '', 'АНЖЕЛИКА', '', '', '8-8616844331', '8-9282452074', '', '', 'РФ, КРАСНОДАРСКИЙ   КРАЙ, КУЩЕВСКИЙ  РАЙОН', 0, 0, '', 863, '427951641614', '240639301184', '272648107910', '', '', 5, '', '', '', '', '', '', 'e1ena@inbox.ru');
INSERT INTO `ri_user` VALUES (164, '2005-10-22', 'asf-klg@freemail.ru', 'lima', '', 'Condor', '', '', '+44(0)1625 576077', '', '', '', 'Манчестер', 0, 0, '', 195, '', '', '', '', '', 3, '', '', '', '', '', '', 'asf-klg@freemail.ru');
INSERT INTO `ri_user` VALUES (165, '2005-10-23', 'nana1012@mail.ru', 'cj,frf2', 'nana1020', '', '', '', '45455', '89179168198', '', '', 'Елабуга', 0, 0, '498-750-153', 4468, '', '', '', '41001107028602', '', 130, '', '', '', '', '', '', 'nana1012@mail.ru');
INSERT INTO `ri_user` VALUES (166, '2005-10-27', 'WWW.femida51@rambler.ru', 'zhl1', '', 'erlih nikolai', '', '', '', '89112592802', '', '', 'Санкт-Петербург', 0, 0, '', 0, '', '', '', '4100128414825', '', 10, '', '', 'zakazdiplom.ru;referat.ru;5ballov.ru;epoisk.ru;', 'zakazdiplom.ru;referat.ru;5ballov.ru;epoisk.ru;', 'referat.ru;', '', 'WWW.femida51@rambler.ru');
INSERT INTO `ri_user` VALUES (167, '2005-10-27', 'femida51@rambler.ru', 'zhl1', '', 'erlih nikolay', '', '', '', '89112592802', '', '', 'Cанкт- петербург', 0, 0, '', 210, '', '', '', '4100128414825', '', 51, '', '', 'referat.ru;zakazdiplom.ru;epoisk.ru;5ballov.ru;', 'referat.ru;zakazdiplom.ru;', 'referat.ru;', '', 'femida51@rambler.ru');
INSERT INTO `ri_user` VALUES (168, '2005-11-02', 'igs@academ.chita.ru', 'intel', '', 'Ширяев Игорь Геннадьевич', '', '', '', '+79144669275', '', '', 'Чита', 0, 0, '', 206, '', '', '', '', '', 1, 'exchange.academ.chita.ru', '', '', '', '', '', 'igs@academ.chita.ru');
INSERT INTO `ri_user` VALUES (169, '2005-11-09', '417@list.ru', 'Сафонов', '', '', '', '', '', '89043067382', '', '', 'Челябинск', 0, 0, '', 917, '', '', '', '', '', 1, '', '', 'checkout.ru;', '', '', '', '417@list.ru');
INSERT INTO `ri_user` VALUES (170, '2005-11-09', 'superslonik1974@mail.ru', '5555', '', 'Анастасия', '', '', '()', ' 7 921 3137441', '', '', 'Санкт-Петербург', 0, 0, '', 220, '', '', '', '', '', 0, '', '', '', '', '', '', 'superslonik1974@mail.ru');
INSERT INTO `ri_user` VALUES (171, '2005-11-19', 'ovsianka@yandex.ru', 'yana1', '', 'Yana', '', '', '', '89084627428', '', '', 'Владивосток', 0, 0, ' 345818881', 1803, '', '', '', ' 4100140689481', '', 250, 'www. psylib.narod.ru', '', '', '', 'psylib.narod.ru;', '', 'ovsianka@yandex.ru');
INSERT INTO `ri_user` VALUES (172, '2005-11-19', 'zam@mksat.net', 'LTS1971', '', 'Tanya', '', '', '(80512)36-50-55', '80505755896', '', '', 'Украина г. Николаев', 0, 0, '324870327', 240, '', '', '', '', '', 0, '', '', '', '', '', '', 'zam@mksat.net');
INSERT INTO `ri_user` VALUES (173, '2005-11-21', 'Swan2000@inbox.ru', 'НС1980', '', '', '', '', '(3812)155907', '89039806546', '', '', 'Омск', 0, 0, '28225415', 1584, '', '', '', '4100141628483', 'Получатель', 200, '', '', '', '', '', '', 'Swan2000@inbox.ru');
INSERT INTO `ri_user` VALUES (174, '2005-11-22', 'studentam@list.ru', '161181', '', 'Урий', '', '', '', '8-921-3572609', '', '', 'Санкт-Петербург', 0, 0, '109158281', 245, '', '', '', '', '', 1, '', '', 'rudiplom.ru;', 'miget.ru;', 'bestreferats.ru;', '', 'studentam@list.ru');
INSERT INTO `ri_user` VALUES (175, '2005-11-23', 'Stanger1@yandex.ru', '216772', '', 'Stanger1', '', '', '()', '89066499912', '', '', 'Рязань', 0, 0, '', 249, '', '', '', '', '', 0, '', '', '', '', '', '', 'Stanger1@yandex.ru');
INSERT INTO `ri_user` VALUES (176, '2005-11-24', 'elfica@pisem.net', 'djkxjyjr', '', 'Элфика', '', '', '(83952)513392', '', '', '', 'Иркутск', 0, 0, '284513485', 328, '', '', '', '', '', 0, '', '', '', '', '', '', 'elfica@pisem.net');
INSERT INTO `ri_user` VALUES (177, '2005-11-24', 'alevtina_semenov@mail.ru', 'fyyf1978', '', 'Alevtina', '', '', '', '910-948-20-83', '/0872/41-93-20(', '', 'Tula', 0, 0, '220768919', 0, '', '', '', '', '', 15, '', '', '', '', '', '', 'alevtina_semenov@mail.ru');
INSERT INTO `ri_user` VALUES (178, '2005-11-24', 'acmacros@ukr.net', 'groo8017', '', 'Stroom', '', '', '()', ' 380972275752', '', '', 'Львов', 0, 0, '234824717', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'acmacros@ukr.net');
INSERT INTO `ri_user` VALUES (179, '2005-11-29', 'kharvalentin@yahoo.com', 'waly083', '', '', '', '', '', '89609880693', '', '', 'ОМСК', 0, 0, '242517308', 379, '863857489641', '356348476279', '401846214923', '', '', 1500, '', '', '', '', 'referats.ru;', '', 'kharvalentin@yahoo.com');
INSERT INTO `ri_user` VALUES (180, '2005-12-06', 'stu_ra@mail.ru', 'анастасия', '', 'Стася', '', '', '', '', '', '', 'Рубцовск', 0, 0, '', 277, '', '', '', '', '', 12, '', '', '', '', '', '', 'stu_ra@mail.ru');
INSERT INTO `ri_user` VALUES (181, '2005-12-10', 'ingelot@gmail.com', '73501505', '', '', '', '', '', '89132300349', '', '', 'Новоалтайск', 0, 0, '', 348, '', '', '', '', '', 200, '', '', '', '', '', '', 'ingelot@gmail.com');
INSERT INTO `ri_user` VALUES (182, '2005-12-10', 'abitura2007@jandex.ru', 'asdfg111', '', '', '', '', '()', '89047715394', '', '', 'Волгоград', 0, 0, '', 316, '', '', '', '', '', 0, '', '', '', '', '', '', 'abitura2007@jandex.ru');
INSERT INTO `ri_user` VALUES (183, '2005-12-11', 'elenacor@bk.ru', 'qazqaz11', '', ' lina', '', '', '()', '89047715493', '', '', ' Волжский', 0, 0, '', 697, '', '', '', '', '', 0, '', '', '', '', '', '', 'elenacor@bk.ru');
INSERT INTO `ri_user` VALUES (184, '2005-12-12', 'r-p-s@rambler.ru', '05121978', '', 'РПС', '', '', '()', '89155311820', '', '', 'Брянск', 0, 0, '291104767', 306, '', '', '', '', '', 0, '', '', '', '', '', '', 'r-p-s@rambler.ru');
INSERT INTO `ri_user` VALUES (185, '2005-12-16', 'irinakvi@hotmail.com', 'supper', '', 'Irina A. Kvinnesland', '', '', '55276609', '', '', '47', 'Bergen, Norway', 0, 0, '', 306, '', '', '', '', '', 2147483647, '', '', '', '', '', '', 'irinakvi@hotmail.com');
INSERT INTO `ri_user` VALUES (186, '2005-12-17', 'newrshi@mail.ru', '915012', 'Ирина', '', '', '', '', '', '', '', 'Москва', 0, 0, '288748557', 2813, 'R665751384063', '', '', '', '', 60, '', '', '', '', '', '', 'newrshi@mail.ru');
INSERT INTO `ri_user` VALUES (187, '2005-12-21', 'olgadegtereva@yandex.ru', '15122202', '', 'ОльгаДегтерева', '', '', '()', '89115617428', '', '', 'Архангельск', 0, 0, '', 315, '', '', '', '', '', 0, '', '', '', '', '', '', 'olgadegtereva@yandex.ru');
INSERT INTO `ri_user` VALUES (188, '2005-12-21', 'bozn@svitonline.com', 'referats', '', 'yur', '', '', '', '+380972619784', '', '', 'Vinnitsa / Ukraine', 0, 0, '221248983', 315, '', '', '', '', '', 30, '', '', 'referat.ru;', 'ukrreferat.com.ua;', 'referat.ru;', '', 'bozn@svitonline.com');
INSERT INTO `ri_user` VALUES (189, '2005-12-21', 'juliamedved@mail.ru', 'sobel', '', 'Юлия', '', '', '(88332)35-10-21', '89226605653', '', '', 'Киров', 0, 0, '335-318-426', 315, '', '', '', '4100142457632', '', 0, '', '', '', '', '', '', 'juliamedved@mail.ru');
INSERT INTO `ri_user` VALUES (190, '2005-12-29', 'shnn82@mail.ru', 'nata28', '', 'kinder', '', '', '()', '', '', '', 'Харьков', 0, 0, '305644004', 996, '', '', '', '', '', 0, '', '', '', '', '', '', 'shnn82@mail.ru');
INSERT INTO `ri_user` VALUES (191, '2005-12-30', 'tuzec@mail.ru', 'tuzec1', '', '', '', '', '', '8-903-121-71-70', '', '', 'Москва', 0, 0, '', 774, '', '', '', '', 'счёт 40817810700230081988 в КБ "Юниаструм Банк" (ООО) г.Москва\r\nБИК 044585184, корр.сч. 30101810600000000184\r\nИНН 7707286199', 0, '', '', '', '', '', '', 'tuzec@mail.ru');
INSERT INTO `ri_user` VALUES (192, '2006-01-09', 'studentufa@mail.ru', '4171', '', 'СтудентУфа', '', '', '', '+79174061348', '', '', 'Уфа', 0, 0, '178713937', 338, '', '', '', '', '', 200, 'www.studentufa.ru', '', '', '', '', '', 'studentufa@mail.ru');
INSERT INTO `ri_user` VALUES (193, '2006-01-09', 'kostuk@rambler.ru', '121071', '', '', '', '', '(0872)-39-77-04', '8-905-621-88-81', '8-905-621-88-81', '', 'Тула', 0, 0, '', 334, '', '', '', '4100129551178', '', 100, 'mirstudenta.ru', '', 'mirstudenta.ru;', 'mirstudenta.ru;', 'referat.ru;', '', 'kostuk@rambler.ru');
INSERT INTO `ri_user` VALUES (194, '2006-01-11', 'femme1978@mail.ru', '567139', '', '', '', '', '', '', '', '', 'Саратов', 0, 0, '', 2671, '', '', '', '41001198776222', '', 150, '', '', 'http://forums.saratov.ru/;', 'http://forums.saratov.ru/;', 'http://orel.rsl.ru/disser/%5B19%5D.htm;', '', 'femme1978@mail.ru');
INSERT INTO `ri_user` VALUES (195, '2006-01-17', 'ikhat@yandex.ru', '6832', '', '', '', '', '()', '', '', '', 'Челябинск', 0, 0, '', 477, 'R112441362412', 'Z588715896219', '', '4100146855867', '', 0, '', '', '', '', '', '', 'ikhat@yandex.ru');
INSERT INTO `ri_user` VALUES (196, '2006-01-17', 'Jull21@hotmail.ru', '260154', '', 'Julia', '', '', '', '80509465202', '', '', 'полтава', 0, 0, '309712277', 0, '', '', '', '', '', 60, '', '', '', '', '', '', 'Jull21@hotmail.ru');
INSERT INTO `ri_user` VALUES (197, '2006-01-23', 'IrinaSig@mail.ru', '1978', '', 'Карепанова Ирина Георгиевна', '', '', '98332)31-25-90', '8-912-702-14-07', '(8332)31-87-55', '', 'Киров', 0, 0, '', 1736, '', '', '', '4100147343203', '', 17, '', '', '', '', '', '', 'IrinaSig@mail.ru');
INSERT INTO `ri_user` VALUES (198, '2006-01-30', 'Mishka@duma.kaluga.ru', '27003', '', 'Mishka', '', '', '()', '89109128520', '', '', 'КАЛУГА', 0, 0, '', 475, 'WMR173008991902', 'WMZ218483730617', 'WME', '', '', 0, '', '', '', '', '', '', 'Mishka@duma.kaluga.ru');
INSERT INTO `ri_user` VALUES (199, '2006-02-01', 'zakon1985@mail.ru', '000000', '', 'Pesha', '', '', '(88634)371512', '89085066112', '', '', 'Таганрог', 0, 0, '', 477, '', '', '', 'pesha5@yandex.ru', '', 0, '', '', '', '', '', '', 'zakon1985@mail.ru');
INSERT INTO `ri_user` VALUES (200, '2006-02-02', 'zns_nafig_999@mail.ru', 'ами9', '', 'АМИ', '', '', '', '9222020291', '', '', 'Алапаевск', 0, 0, '', 377, '', '', '', '', '', 48, '', '', '', '', '', '', 'zns_nafig_999@mail.ru');
INSERT INTO `ri_user` VALUES (201, '2006-02-04', 'drok88@mail.ru', 'galimov2', '', 'RexXar', '', '', '', '', '', '', 'Рыбинск', 0, 0, '', 0, '', '', '', '', '', 2, '', '', 'dic.ru;', 'rgv.com;', 'ref.ru;', '', 'drok88@mail.ru');
INSERT INTO `ri_user` VALUES (202, '2006-02-08', '03112000@mail.ru', '03110311', '', 'bulan', '', '', '', '', '', '', 'Россия', 0, 0, '243575705', 396, '', '920248259951', '', '', '', 500000, '', 'в течении 2 месяцев', '', '', '', '', '03112000@mail.ru');
INSERT INTO `ri_user` VALUES (203, '2006-02-08', 'lena1955@bk.ru', '24011976', '', 'Ольга', '', '', '(8352)66-54-40', '8-927-855-75-21', '', '', 'Чебоксары', 0, 0, '', 491, '', '', '', '', '', 50, '', '', '', '', '', '', 'lena1955@bk.ru');
INSERT INTO `ri_user` VALUES (204, '2006-02-12', 'feduy@ukr.net', '235595', 'Gala', '', '', '', '(80562)23-24-12', '8-050-73-22-102', '', '', 'Днепропетровск', 0, 0, '279-538-772', 1833, 'R552271021351', 'Z407094273297', 'E718073920152', '', '', 0, '', '', '', '', '', '', 'feduy@ukr.net');
INSERT INTO `ri_user` VALUES (205, '2006-02-15', 'siga@rambler.ru', 'dudochka', '', 'siga@rambler.ru', '', '', '(0542)250022', '', '', '', 'Сумы', 0, 0, '', 1554, '', '', '', '', '', 0, '', '', '', '', '', '', 'siga@rambler.ru');
INSERT INTO `ri_user` VALUES (206, '2006-02-16', 'morozova.anna1@rambler.ru', 'd7gjabp', '', 'morozova.anna1', '', '', '(49233)39028', '89607219678', '', '', 'Вязники', 0, 0, '', 504, '', '', '', '', '', 0, '', '', '', '', '', '', 'morozova.anna1@rambler.ru');
INSERT INTO `ri_user` VALUES (207, '2006-02-21', 'alinynok@mail.ru', '1214121412', '', 'Miranda', '', '', '()', '89109090201', '', '', 'Рязань', 0, 0, '', 833, '', '', '', '', '', 0, '', '', '', '', '', '', 'alinynok@mail.ru');
INSERT INTO `ri_user` VALUES (208, '2006-02-23', 'ita.60@mail.ru', '379шеф', '', 'Татиана', '', '', '8- 8622- 724903', '', '', '', ' Сочи', 0, 0, '', 440, '', '', '', '', '', 4, '', '', 'monax.ru;gb.rol.ru;', 'monax.ru;gb.rol.ru;', 'referatov.net;bankreferatov.ru;', '', 'ita.60@mail.ru');
INSERT INTO `ri_user` VALUES (209, '2006-02-24', 'pcservises@mail.esoo.ru', 'oms3012', '', 'ivan', '', '', '8 35348 3-21-73', '', '', '', 'Оренбургская область', 0, 0, '', 443, '', '131441412228', '', '', '', 580, 'http://elcomps.narod.ru', '', '', '', '', '', 'pcservises@mail.esoo.ru');
INSERT INTO `ri_user` VALUES (210, '2006-02-27', 'timur_113@mail.ru', '020784', '', 'Тимур', '', '', '', '89273838581', '', '', 'Пенза', 0, 0, '', 466, '796058208828', '', '230810572336', '', '', 10, '', '', '', '', '5ballov.ru;', '', 'timur_113@mail.ru');
INSERT INTO `ri_user` VALUES (211, '2006-02-28', 'dzhy27@mail.ru', 'mencbu', '', 'Аня', '', '', '()', '', '', '', 'Таганроге', 0, 0, '', 455, '', '', '', '', '', 0, '', '', '', '', '', '', 'dzhy27@mail.ru');
INSERT INTO `ri_user` VALUES (212, '2006-03-02', 'esperto@mail.ru', 'amsterdam', '', 'Defoe', '', '', '(8482) 323088', '(8482) 780205', '(8482) 339866', '', 'Тольятти', 0, 0, '222622880', 464, '312294620327', '344644947818', '382615385767', '', '', 3, '', '', '', '', '', '', 'esperto@mail.ru');
INSERT INTO `ri_user` VALUES (213, '2006-03-13', 'EOstashko@mail.ru', '30101984', '', 'Lena', '', '', '()', '79264602055', '', '', 'Москва', 0, 0, '', 494, '', '', '', '', '', 0, '', '', '', '', '', '', 'EOstashko@mail.ru');
INSERT INTO `ri_user` VALUES (214, '2006-03-16', 'otlichnik86@bk.ru', '09876', '', 'Jelya', '', '', '', '8-916-911-50-89', '', '', 'Москва', 0, 0, '', 504, '', '', '', '', '', 33, '', '', '', '', '', '', 'otlichnik86@bk.ru');
INSERT INTO `ri_user` VALUES (215, '2006-03-17', 'himeron@narod.ru', '2754665', '', '', '', '', '()', '89272003069', '', '', 'Самара', 0, 0, '', 2740, '', '', '', '', '', 250, '', '', '', '', '', '', 'himeron@narod.ru');
INSERT INTO `ri_user` VALUES (216, '2006-03-22', 'moukhametzyanova@rambler.ru', 'ltncrbq', '', 'Yatka', '', '', '( 843)260-24-84', 'тот же', '', '', 'Казань', 0, 0, '38400835', 848, '', '', '', '', '', 0, '', '', '', '', '', '', 'moukhametzyanova@rambler.ru');
INSERT INTO `ri_user` VALUES (217, '2006-03-22', 'voitina1@mail.ru', '200950', '', 'Yulia', '', '', '()', '89047031587', '', '', 'Саратов', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'voitina1@mail.ru');
INSERT INTO `ri_user` VALUES (218, '2006-03-25', 'vmk2201@land.ru', 'alexvmk2201alex', '', 'Alex', '', '', '', '', '', '', 'Volgograd', 0, 0, '', 544, '', '', '', '', '', 3, '', '', '', '', '', '', 'vmk2201@land.ru');
INSERT INTO `ri_user` VALUES (219, '2006-03-27', 'leon2010@ngs.ru', 'ghbdtn1', '', 'leon', '', '', '', '', '', '', 'Новосибирск', 0, 0, '', 616, '354288786158', '', '', '', '', 500, '', '', '', 'diplom-shop.ru;', 'referat.ru;referats.ws;', '', 'leon2010@ngs.ru');
INSERT INTO `ri_user` VALUES (220, '2006-03-27', 'riasgskih@mail.ru', '19811981', '', 'Serg', '', '', '', '', '', '', 'Ярославль', 0, 0, '', 559, '', '', '', '', '', 1, '', '', '', '', '', '', 'riasgskih@mail.ru');
INSERT INTO `ri_user` VALUES (221, '2006-03-27', 'DLarkov@mail.ru', '102030', '', 'Ларьков Д.Ю.', '', '', '', '', '', '', 'Санкт-Петербург', 0, 0, '', 773, '', '', '', '', '', 6, '', '', '', '', '', '', 'DLarkov@mail.ru');
INSERT INTO `ri_user` VALUES (222, '2006-03-28', 'prodiplom2006@yandex.ru', '3412265', '', 'prodiplom2006', '', '', '341-22-65', '8-916-910-44-79', '', '', 'Москва', 0, 0, '', 544, '', '', '', '4100149086745', '', 2, '', '', 'vzfei.ru;www.xion.ru;mifp.ru;', 'vzfei.ru;www.xion.ru;mifp.ru;', 'referat.ru;bankreferatov.ru;', '', 'prodiplom2006@yandex.ru');
INSERT INTO `ri_user` VALUES (223, '2006-03-29', 'lena0nline@yandex.ru', '202020', '', 'groza', '', '', '()', '89035611120', '', '', 'Москва', 0, 0, '', 633, '', '', '', '4100154924471', '', 0, '', '', '', '', '', '', 'lena0nline@yandex.ru');
INSERT INTO `ri_user` VALUES (224, '2006-04-04', 'Vasenkin@gmail.com', '12847059', '', 'Vasenkin', '', '', '(843)2692160', '89046619587', '', '', 'Казань', 0, 0, '179585513', 568, '', '', '', '', '', 0, '', '', '', '', '', '', 'Vasenkin@gmail.com');
INSERT INTO `ri_user` VALUES (225, '2006-04-05', 'musia-77@mail.ru', '2421411', '', 'Маша', '', '', '', '', '', '', 'Москва', 0, 0, '', 577, '', '', '', '', '', 20, '', '', '', '', '', '', 'musia-77@mail.ru');
INSERT INTO `ri_user` VALUES (226, '2006-04-07', 'Andre_78@bk.ru', '601120', '', '', '', '', '()', '8 909 941 30 76', '', '', 'Москва', 0, 0, '275-215-333', 1083, '', '', '', '4100158578480', '', 0, '', '', '', '', '', '', 'Andre_78@bk.ru');
INSERT INTO `ri_user` VALUES (227, '2006-04-07', '////////@mail.ru', 'ujcnm', '', '', '', '', '////////////////////', '////////////////////', '', '', '/////////////', 0, 0, '//////////////////', 821, '///////////////////////', '', '', '//////////////////////////', '', 20, '', '', '', '', '', '', '////////@mail.ru');
INSERT INTO `ri_user` VALUES (228, '2006-04-12', 'historicc@mail.ru', 'diplomna', '', 'historic', '', '', '', '+380664806615', '', '', 'Poltava', 0, 0, '258000458', 0, '', '', '', '', '', 250, 'http://www.ukr-kursovi.narod.ru', '', 'studybank.info;refsbank.info;', 'referats.info;', 'bankreferatov.ru;', '', 'historicc@mail.ru');
INSERT INTO `ri_user` VALUES (229, '2006-04-14', 'gramarchuk_irina@mail.ru', 'gramarchuk', 'Ирина', '', '', '', '8152388291', '89113165991', '', '', 'Мурманск', 0, 0, '347434252', 4467, '', '', '', '4100160056118', '', 100, '', '', 'gotovoe.ru;zakazdiplom.ru;morereferatov.ru;', 'gotovoe.ru;ornatus.ru;monax.ru;br.com.ua;netoteka.ru;allbest.ru;', 'referat.ru;gotovoe.ru;br.com.ua;referat.na5.ru;referatov.net;ukrreferat.com;', '', 'gramarchuk_irina@mail.ru');
INSERT INTO `ri_user` VALUES (230, '2006-04-25', 'Alisss76@mail.ru', '25393', '', '', '', '', '(83147)2-53-93', '89202571078', '', '', 'Арзамас', 0, 0, '230-203-825', 2262, '', '', '', '4100142125232', '', 0, '', '', '', '', '', '', 'Alisss76@mail.ru');
INSERT INTO `ri_user` VALUES (231, '2006-04-26', 'potehin_a@mail.ru', '2961', '', 'Катя', '', '', '', '89109825978', '', '', 'Иваново', 0, 0, '', 656, '', '', '', '', '', 10, '', '', '', '', '', '', 'potehin_a@mail.ru');
INSERT INTO `ri_user` VALUES (232, '2006-04-27', 'tri-a2005@yandex.ru', '322332', '', 'Пуаро', '', '', '53-59-22', '', '53-24-34', '', 'Нижний новгород', 0, 0, '', 686, '', '', '', '', '', 0, '', '', '', '', '', '', 'tri-a2005@yandex.ru');
INSERT INTO `ri_user` VALUES (233, '2006-05-02', 'Kse.nia@microsoft.com', 'нафаня', '', 'Бороденко Оксана Дмитриевна', '', '', '39162 26186', '', '', '', 'Таёжный', 0, 0, '', 0, '', '', '', '', '', 2, '', '', '', '', '', '', 'Kse.nia@microsoft.com');
INSERT INTO `ri_user` VALUES (234, '2006-05-04', 'coldcorpse@yandex.ru', 'mmmike12', '', 'Katerina', '', '', '', '80668569988', '', '', 'Симферополь', 0, 0, '', 817, '', '', '', '', '', 5, '', '', 'любая бесплатная доска объявлений.ru;', 'Monah.ru;', 'Heo.ru;', '', 'coldcorpse@yandex.ru');
INSERT INTO `ri_user` VALUES (235, '2006-05-04', 'manuy@inbox.ru', '220641', '', '', '', '', '', '', '', '', 'Москва', 0, 0, '196313721', 687, '', '', '', '', '', 100, '', 'за лето', 'sretgw45r.ru;', 'sertgwaerg.ru;', 'awergqaewrgs.ru;', '', 'manuy@inbox.ru');
INSERT INTO `ri_user` VALUES (236, '2006-05-06', 'kursovik_5@mail.ru', 'qweasd', '', '', '', '', '', '89044050737', '', '', 'Волгоград', 0, 0, '', 1443, '', '', '', '4100143226188', '', 300, '', '', '', '', '', '', 'kursovik_5@mail.ru');
INSERT INTO `ri_user` VALUES (237, '2006-05-10', 'pwgirl@rambler.ru', 'ьфчшьф', '', 'Катрин', '', '', '', '', '', '', 'Москва', 0, 0, '', 707, '', '', '', '', '', 6, '', '', '', '', '', '', 'pwgirl@rambler.ru');
INSERT INTO `ri_user` VALUES (238, '2006-05-11', 'svetulia21@yandex.ru', 'guru', '', '', '', '', '()', '', '', '', 'Санкт-Петербург', 0, 0, '', 1583, 'R290460462476', 'Z352426271057', '', '4100161898880', '', 0, '', '', '', '', '', '', 'svetulia21@yandex.ru');
INSERT INTO `ri_user` VALUES (239, '2006-05-13', 'J7-J7-J7@yandex.ru', '5574', '', 'Исакова Карина', '', '', '', '', '', '', 'Гусь-Хрустальный', 0, 0, '211530069', 1104, '330794473436', '211070036633', '406309144727', '', '', 2, '', '', '', '', '', '', 'J7-J7-J7@yandex.ru');
INSERT INTO `ri_user` VALUES (240, '2006-05-14', 'sveta_21@mail.ru', 'love you', '', 'Светлана', '', '', '', '', '', '', 'Москва', 0, 0, '', 731, '', '', '', '', '', 1, '', '', '', '', '', '', 'sveta_21@mail.ru');
INSERT INTO `ri_user` VALUES (241, '2006-05-15', 'uliy_82_6@mail.ru', '8641213zd', '', 'Рай Юлия Михайловна', '', '', '', '', '', '', 'Челябинск', 0, 0, '', 761, '', '', '', '', '', 5, '', '', '', '', '', '', 'uliy_82_6@mail.ru');
INSERT INTO `ri_user` VALUES (242, '2006-05-15', 'cmo3@rambler.ru', '190484', '', 'FoBoS', '', '', '', '89212193317', '', '', 'Псков', 0, 0, '', 779, '', '', '', '', '', 1, '', '', '', '', '', '', 'cmo3@rambler.ru');
INSERT INTO `ri_user` VALUES (243, '2006-05-16', 'vetalii.inzebeev@mail.ru', '080685', '', 'shade', '', '', '', '', '', '', 'самарская обл.', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '5ballov.ru;', '5ballov.ru;', '5ballov.ru;', '', 'vetalii.inzebeev@mail.ru');
INSERT INTO `ri_user` VALUES (244, '2006-05-23', 'akina@netroad.ru', '159753', '', 'Хельга', '', '', '(8422) 516708', ' 79278120542', '', '', 'Ульяновск', 0, 0, '332189124', 789, '', '', '', '', '', 0, '', '', '', '', '', '', 'akina@netroad.ru');
INSERT INTO `ri_user` VALUES (245, '2006-05-23', 'secret_84@mal.ru', '1236', '', 'Настя', '', '', '', '8-913-395-99-59', '', '', 'Новосибирск', 0, 0, '', 761, '', '', '', '', '', 40, '', '3 месяца', 'morereferatov.ru;referat.ru;5ballov.ru;', 'morereferatov.ru;referat.ru;5ballov.ru;', 'referat.ru;5ballov.ru;student.ru;', '', 'secret_84@mal.ru');
INSERT INTO `ri_user` VALUES (246, '2006-05-24', 'ruta1961@mail.ru', '9242569076', '', 'Татьяна', '', '', '(4236)632950', '', '', '', 'г. Находка Приморского края', 0, 0, '', 1604, '254821637848', '314661497392', '290879664454', '4100158937749', '', 20, '', '', '', 'albest.ru;', '', '', 'ruta1961@mail.ru');
INSERT INTO `ri_user` VALUES (247, '2006-05-27', 'ryzykov-xxx@mail.ru', 'pjkjnjq cjan', '', 'Сергей Николаевич', '', '', '', '89056884927', '', '', 'липецк', 0, 0, '', 0, '', '', '', '', '', 100, '', '', '', '', '', '', 'ryzykov-xxx@mail.ru');
INSERT INTO `ri_user` VALUES (248, '2006-05-30', 'sergey-spb-42@yandex.ru', '2910', '', 'sergey-spb-42@yandex', '', '', '(812)552-26-87', ' 7-906-26-00-552', '', '', 'Санкт-Петербург', 0, 0, '', 821, '', '', '', '', '', 0, '', '', '', '', '', '', 'sergey-spb-42@yandex.ru');
INSERT INTO `ri_user` VALUES (249, '2006-06-01', 'amster8888@gmail.com', '101004', '', 'amster', '', '', '()', '', '', '', 'Братск', 0, 0, '5222083', 784, '', '', '', '', '', 0, '', '', '', '', '', '', 'amster8888@gmail.com');
INSERT INTO `ri_user` VALUES (250, '2006-06-01', 'serg2195job@yandex.ru', '2195serg', '', 'Сергей', '', '', '', '', '', '', 'Ростов-на-Дону', 0, 0, '', 817, '880347211360', '909871332873', '039843044357', '', '', 50, '', 'август 2006', 'gotovoe.narod.ru;', 'gotovoe.narod.ru/;', '5ballov.ru;bankreferatov.ru;', '', 'serg2195job@yandex.ru');
INSERT INTO `ri_user` VALUES (251, '2006-06-04', 'Antimish@yandex.ru', '6666666', '', 'Алексашка', '', '', '7575655', '+79112091314', '', '', 'Санкт-Петербург', 0, 0, '', 872, '', '', '', '500', '', 3, '', '', '', '', '', '', 'Antimish@yandex.ru');
INSERT INTO `ri_user` VALUES (252, '2006-06-05', 'Rustam121@yandex.ru', '180682', '', 'Шарипов Рустам', '', '', '', '89039798161', '', '', 'Москва', 0, 0, '235065020', 789, '', '', '', '', '', 1, '', '', 'www.referat.ru;', 'www.student.ru;', 'www.bankreferatov.ru;', '', 'Rustam121@yandex.ru');
INSERT INTO `ri_user` VALUES (253, '2006-06-07', 'sophia01@mail.ru', '01031984', '', 'София', '', '', '', '', '', '', 'Хабаровск', 0, 0, '', 2254, '', '', '', '', '', 1, '', '', '', '', '', '', 'sophia01@mail.ru');
INSERT INTO `ri_user` VALUES (254, '2006-06-09', 'taisiya_r84@mail.ru', '147895', '', 'Таисия', '', '', '', '8-916-165-95-56', '', '', 'Москва', 0, 0, '', 796, '', '', '', '', '', 6, '', '', '', '', '', '', 'taisiya_r84@mail.ru');
INSERT INTO `ri_user` VALUES (255, '2006-06-14', 'qsy@rambler.ru', 'fifa', '', 'qsy2007', '', '', '()', '', '', '', 'Знаменск', 0, 0, '', 995, '', '', '', '', '', 0, '', '', '', '', '', '', 'qsy@rambler.ru');
INSERT INTO `ri_user` VALUES (256, '2006-06-15', 'moon-cat@email.su', '303+606', '', 'Лунный Кот', '', '', '', '', '', '', 'Серпухов', 0, 0, '282074803', 821, '', '', '', '', '', 1, '', '', '', '', '', '', 'moon-cat@email.su');
INSERT INTO `ri_user` VALUES (257, '2006-07-03', 'chernookaya@rambler.ru', '2709', '', '', '', '', '()', ' 375293364066', '', '', 'г. Лунинец, Беларусь', 0, 0, '', 879, '', 'Z366590677303', '', '', '', 0, '', '', '', '', '', '', 'chernookaya@rambler.ru');
INSERT INTO `ri_user` VALUES (258, '2006-07-24', 'mivacom@mail.ru', '4031968', '', 'Владислав', '', '', '', '89206726280', '', '', 'Москва', 0, 0, '', 0, '', '', '', '', '', 150, 'http://diplom-psychology.narod.ru/', '', '', '', '', '', 'mivacom@mail.ru');
INSERT INTO `ri_user` VALUES (259, '2006-07-25', 'urreferat2006@mail.ru', '22101978', '', 'Ирина22', '', '', '', '89064612803', '', '', 'Пятигорск', 0, 0, '', 899, '', '', '', '', '', 150, '', '', '', '', '', '', 'urreferat2006@mail.ru');
INSERT INTO `ri_user` VALUES (260, '2006-08-17', 'golden70@bk.ru', 'pjkjnj65', '', 'golden70', '', '', '(846)9996391', '8-905-305-7214', '', '', 'Тольятти', 0, 0, '194-089-808', 2032, '', '', '', '4100140887742', '', 0, '', '', '', '', '', '', 'golden70@bk.ru');
INSERT INTO `ri_user` VALUES (261, '2006-08-18', 'obuchalka@mail.ru', '505050', '', 'Инесса', '', '', '88352641347', '89022497119', '', '89262787772', 'Чебоксары', 0, 0, '', 851, '', '', '', '', '', 600, '', '', 'monah.ru;moreferatov.ru;', 'monah.ru;moreferatov.ru;', 'monah.ru;moreferatov.ru;', '', 'obuchalka@mail.ru');
INSERT INTO `ri_user` VALUES (262, '2006-08-21', 'erikap@mail.ru', '678899', '', 'lastochka71', '', '', '(372)53330471', '', '', '', 'kohtla jarve', 0, 0, '', 899, '', '', '', '', '', 0, '', '', '', '', '', '', 'erikap@mail.ru');
INSERT INTO `ri_user` VALUES (263, '2006-08-28', 'psychea82@mail.ru', '041982', '', 'Psychea', '', '', '', '+79051004446', '', '', 'Bryansk', 0, 0, '', 886, '', '', '', '', '', 40, '', '', 'Referat.ru;', 'Referat.ru;', 'Referat.ru;', '', 'psychea82@mail.ru');
INSERT INTO `ri_user` VALUES (264, '2006-09-06', 'bulat678@mail.ru', 'м68987191', '', '', '', '', ' (3812 ) 559-150', '8-913-602-59-64.', '', '', 'Омск', 0, 0, '', 1647, '229008427143', '', '', '', '', 150, '', '', '', '', 'allpravo.ru;', '', 'bulat678@mail.ru');
INSERT INTO `ri_user` VALUES (265, '2006-09-07', 'foop@yandex.ru', '1234', '', 'Анастасия Вячеславовна', '', '', '', '8-905-869-51-62', '', '', 'Нижний Новгород', 0, 0, '', 862, '', '', '', '4100175320095', '', 77, '', '', '', '', '', '', 'foop@yandex.ru');
INSERT INTO `ri_user` VALUES (266, '2006-09-12', 'referatdiplom@mail.ru', '255403', '', '', '', '', '(8452) 233085', '8-905-329-49-48', '', '', 'Саратов', 0, 0, '', 2767, '', '', '', '4100137056585', '', 550, '', '', 'referat.ru;morereferatov.ru;', 'referat.ru;', 'referat.ru;bankreferatov.ru;', '', 'referatdiplom@mail.ru');
INSERT INTO `ri_user` VALUES (267, '2006-09-14', 'Mila-110@yandex.ru', '18.kz', 'Mila-110', '', '', '', '()', '89187609907', '', '', 'Ставрополь', 0, 0, '', 2090, '', '', '', '4100170303456', '', 0, '', '', '', '', '', '', 'Mila-110@yandex.ru');
INSERT INTO `ri_user` VALUES (268, '2006-09-20', 'alex2603@yandex.ru', 'qwerty', '', 'alex2603', '', '', '', '', '', '', 'таганрог', 0, 0, '', 0, '', '', '', '', '', 10, '', '', '', '', '', '', 'alex2603@yandex.ru');
INSERT INTO `ri_user` VALUES (269, '2006-09-20', 'nic-morin@yandex.ru', 'qwerty', '', 'nic-morin', '', '', '()', '', '', '', 'taganrog', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'nic-morin@yandex.ru');
INSERT INTO `ri_user` VALUES (270, '2006-09-20', 'balexs@list.ru', 'uh2047jik', '', '', '', '', '()', '89603017547', '', '', 'Чебоксары', 0, 0, '', 1092, '', '', '', '4100178477640', '', 0, '', '', '', '', '', '', 'balexs@list.ru');
INSERT INTO `ri_user` VALUES (271, '2006-09-21', 'TANY-1002006@yandex.ru', '', 'Татьяна', 'Лукушина', '', '', '83456252285', '', '', '89222661136', 'Тобольск', 0, 0, '', 1022, '', '', '', '4100163426227', '', 30, '', 'месяц-два', '', '', '', '', 'TANY-1002006@yandex.ru');
INSERT INTO `ri_user` VALUES (272, '2006-09-22', 'luch-kurator@yandex.ru', '12345', '', 'luch', '', '', '(495)7153131', ' 79031429827', '', '', 'Москва', 0, 0, '', 3751, '', '', '', '', '', 0, '', '', '', '', '', '', 'luch-kurator@yandex.ru');
INSERT INTO `ri_user` VALUES (273, '2006-09-25', 'llmiha85@mail.ru', '789456123', '', 'llmiha85', '', '', '(47391)49060', '8-908-137-08-37', '', '', 'город Лиски Воронежской области', 0, 0, '282-074-457', 1403, '', '', '', '', '', 0, '', '', '', '', '', '', 'llmiha85@mail.ru');
INSERT INTO `ri_user` VALUES (274, '2006-10-06', 'almaz_yarulin@mail.ru', 'zamla', '', 'almaz', '', '', '', '', '', '', 'Альм', 0, 0, '', 908, '216319401120', '322928823368', '', '', '', 12, '', '', 'referat.ru ;', 'e-diplom.ru;', 'referat.ru;', '', 'almaz_yarulin@mail.ru');
INSERT INTO `ri_user` VALUES (275, '2006-10-12', 'centralbox@mail.ru', '12345', '', 'Centralbox', '', '', '', '', '', '', 'Москва', 0, 0, '', 927, '', '', '', '', '', 1000, '', '', 'studentcenter.ru;', '', '', '', 'centralbox@mail.ru');
INSERT INTO `ri_user` VALUES (276, '2006-10-16', 'jeannemax@yandex.ru', 'jeannemax', '', 'Jeanne', '', '', '', '8-921-756-49-29', '', '', 'Санкт-Петербург', 0, 0, '', 1147, '', '', '', '', '', 15, '', '', '', '', '', '', 'jeannemax@yandex.ru');
INSERT INTO `ri_user` VALUES (277, '2006-10-22', 'maxhim52@mail.ru', '146252', '', 'maxhim', '', '', '', '', '', '', 'Березники', 0, 0, '', 952, '385304106252', '129181458644', '', '4100164335108', '', 20, '', '', '', '', '', '', 'maxhim52@mail.ru');
INSERT INTO `ri_user` VALUES (278, '2006-10-26', 'aleksei.ref@rambler.ru', '198136', '', 'aleksei', '', '', '8613753371', '9183643404', '', '', 'армавир', 0, 0, '480834470', 1284, '', '', '', '4100186000164', '', 10, '', '', '', '', '', '', 'aleksei.ref@rambler.ru');
INSERT INTO `ri_user` VALUES (279, '2006-11-01', 'zolotovat@rambler.ru', '090780', '', '', '', '', '317-19-76', '8-903-814-45-93', '', '', 'Москва', 0, 0, '254425783', 1097, '', '', '', '', '', 4, '', '', '', '', '', '', 'zolotovat@rambler.ru');
INSERT INTO `ri_user` VALUES (280, '2006-11-02', 'orgcultura@mail.ru', '84JE2UPA07Zk5VPf', '', 'Павел', '', '', '', '', '', '', 'Тамбов', 0, 0, '', 990, '409414277257', '332816441477', '', '4100186691480', '', 30, '', '', 'referat.ru;', 'referat.ru;', 'referat.ru;', '', 'orgcultura@mail.ru');
INSERT INTO `ri_user` VALUES (281, '2006-11-08', 'anna-vladimirovna-87@yandex.ru', '17101987', '', 'Анна', '', '', '', '89175687174', '', '', 'Москва', 0, 0, '477226055', 1160, '', '', '', '', '', 15, '', '', '', '', '', '', 'anna-vladimirovna-87@yandex.ru');
INSERT INTO `ri_user` VALUES (282, '2006-11-14', 'sanolesya@yandex.ru', '26061981', '', 'Олеся', '', '', '6575615', '', '', '', 'Москва', 0, 0, '', 1103, '262951637589', '296081206389', '', '4100139135435', '', 20, '', '', '', '', '', '', 'sanolesya@yandex.ru');
INSERT INTO `ri_user` VALUES (283, '2006-11-15', 'O-012234@yandex.ru', 'КОСТЯ', '', 'Шардулева Оксана Алексеевна', '', '', '83456228113', '89222614675', '', '89129930849', 'г.Тобольск Тюменская область', 0, 0, '', 1412, '', '', '', '4100183379340', '', 20, '', '', '', '', '', '', 'O-012234@yandex.ru');
INSERT INTO `ri_user` VALUES (284, '2006-11-15', '4610651@mail.ru', '4601651', '', '4601651', '', '', '(3472) 50-44-56', '', '', '', 'уфа', 0, 0, '', 1284, '', '', '', '', '', 0, '', '', '', '', '', '', '4610651@mail.ru');
INSERT INTO `ri_user` VALUES (285, '2006-11-17', 'referatform@mail.ru', '32167', '', 'referatform', '', '', '(06153)75524', '80957411284', '', '', 'Бердянск', 0, 0, '302 693 641', 1139, '', '', '', '', '', 0, '', '', '', '', '', '', 'referatform@mail.ru');
INSERT INTO `ri_user` VALUES (286, '2006-11-17', 'pups2480@mail.ru', 'ufvfhybr', '', 'helen2680', '', '', '(3232)23-80-97', '', '', '', 'Усть-Каменогорск/Санкт-Петербург', 0, 0, '', 1059, '', '', '', '', '', 0, '', '', '', '', '', '', 'pups2480@mail.ru');
INSERT INTO `ri_user` VALUES (287, '2006-11-24', 'ml33@bk.ru', '1232', '', 'SANNA', '', '', '', '89207526075', '', '', 'Узловая Тульской обл.', 0, 0, '', 1058, '', '', '', '4100191427238', '', 100, '', '', 'moreferatov.ru;sessua.net;gb.rol.ru;boards.pokrovsk.info;', 'student.km.ru;gb.rol.ru;', 'refstar.ru;spisal.ru;studentport.ru;law-referat.ru;na5refs.ru;epoisk.ru;', '', 'ml33@bk.ru');
INSERT INTO `ri_user` VALUES (288, '2006-11-24', 'gtothjd@yandex.ru', 'akbgrf-gbgrf', '', 'pemafe', '', '', '()', '9217501016', '', '', 'Выборг, Ленинградской области', 0, 0, '', 1072, '', '', '', '', '', 0, '', '', '', '', '', '', 'gtothjd@yandex.ru');
INSERT INTO `ri_user` VALUES (289, '2006-11-24', 'fotin_list@list.ru', '060260', '', '', '', '', '(3812)769560', '8-913-970-1596', '', '', 'Омск', 0, 0, '', 1059, '', '', '', '4100179412924', '', 0, '', '', '', '', '', '', 'fotin_list@list.ru');
INSERT INTO `ri_user` VALUES (290, '2006-11-25', 'wolowikow@mail.ru', '964109', '', 'wolowikow', '', '', '(4242)500-687', '8-924-188-81-51', '', '', 'Южно-Сахалинск', 0, 0, '', 1061, '', '', '', '', '', 0, '', '', '', '', '', '', 'wolowikow@mail.ru');
INSERT INTO `ri_user` VALUES (291, '2006-11-28', 'referatov-mnogo@narod.ru', '55150158', '', 'Евгений Викторович', '', '', '', '89242035623', '', '', 'Хабаровск', 0, 0, '', 1072, '', '', '', '4100188795983', '', 10, 'http://www.referatov-mnogo.narod.ru/', '', 'narod.ru;', '', '', '', 'referatov-mnogo@narod.ru');
INSERT INTO `ri_user` VALUES (292, '2006-11-29', 'ankushev-aleksandr@rambler.ru', '19985', '', 'aleksa', '', '', '354338', '', '', '', 'тюмень', 0, 0, '', 1098, '', '', '', '', '', 3, '', '', '', '', '', '', 'ankushev-aleksandr@rambler.ru');
INSERT INTO `ri_user` VALUES (293, '2006-12-01', 'mystery-1985@mail.ru', 'rehlerjdf', '', 'MysTerY', '', '', '(4212)704311', '89142063306', '', '', 'Хабаровск', 0, 0, '201894680', 1354, '', '', '', '', '', 0, '', '', '', '', '', '', 'mystery-1985@mail.ru');
INSERT INTO `ri_user` VALUES (294, '2006-12-02', 'reise83@mail.ru', '2gxs85mnop', '', 'UHIMO', '', '', '(87937)78871', ' 7-918-806-72-05', '', '', 'Кисловодск', 0, 0, '', 1087, '', '', '', '', '', 0, '', '', '', '', '', '', 'reise83@mail.ru');
INSERT INTO `ri_user` VALUES (295, '2006-12-04', 'Ser_29@mail.ru', '291280', '', '', '', '', '', '', '', '', 'москва', 0, 0, '333-297-146', 3747, '', '', '', '41001138745141', '', 100, '', '', '', '', '', '', 'Ser_29@mail.ru');
INSERT INTO `ri_user` VALUES (296, '2006-12-06', 'lena270788@avtograd.ru', '270788', '', '', '', '', '()', '', '', '', 'Тольятти', 0, 0, '312225373', 1138, 'R270651434380', 'Z554618434398', 'E314111830318', '4100178921694', '', 0, '', '', '', '', '', '', 'lena270788@avtograd.ru');
INSERT INTO `ri_user` VALUES (297, '2006-12-06', 'harizmatic@bk.ru', 'pflhfkb', '', 'Daria', '', '', '', '', '', '', 'Moscow', 0, 0, '', 1097, '', '', '', '', '', 5, '', '', 'slando.ru;', 'izrukvruki.ru;', 'bankreferatov.ru;', '', 'harizmatic@bk.ru');
INSERT INTO `ri_user` VALUES (298, '2006-12-11', 'mezivan@yandex.ru', 'йцук454', '', 'Иван', '', '', '', '89242432415', '', '', 'Владивосток', 0, 0, '', 1361, '', '', '', '4100189029526', '', 60, '', '40', 'ukrweb.com;', '', 'referatbase.ru;', '', 'mezivan@yandex.ru');
INSERT INTO `ri_user` VALUES (299, '2006-12-16', 'valem@mail.iks.ru', '121185', '', 'valem', '', '', '', '89098321231', '', '', 'Петропавловск - Камчатский', 0, 0, '', 1896, '', '', '', '', '', 1, '', '', 'site.ru;', 'site.ru;', 'site.ru;', '', 'valem@mail.iks.ru');
INSERT INTO `ri_user` VALUES (300, '2006-12-21', 'Chichenkoff.81@mail.ru', 'loveru', '', 'ch81', '', '', '798239', '', '', '', 'Воронеж', 0, 0, '', 1162, '', '', '', '4100195010719', '', 8, '', '', '', '', '', '', 'Chichenkoff.81@mail.ru');
INSERT INTO `ri_user` VALUES (301, '2006-12-24', 'unker222@mail.ru', 'vfksirf', '', 'Unker', '', '', '()', '', '', '', 'Odincovo', 0, 0, '', 1225, '', '', '', '', '', 0, '', '', '', '', '', '', 'unker222@mail.ru');
INSERT INTO `ri_user` VALUES (302, '2007-01-03', 'podarok1.1@rambler.ru', 'Nfnmzyf', '', '', '', '', '', '80954951220', '', '', 'Донецк', 0, 0, '', 1182, '', '', '', '', '', 2, '', '', '', '', '', '', 'podarok1.1@rambler.ru');
INSERT INTO `ri_user` VALUES (303, '2007-01-06', 'pryster@mail.ru', 'ganna', '', '', '', '', '', '', '', '', 'Челябинск', 0, 0, '', 1805, '', '', '', '4100129407892', '', 0, '', '', '', '', '', '', 'pryster@mail.ru');
INSERT INTO `ri_user` VALUES (304, '2007-01-08', 'navi_gator@mail.ru', 'allala', '', '', '', '', '(452) 78-24-33', '8-917-983-49-16', '', '', 'Саратов', 0, 0, '', 1284, 'R186475188938', 'Z291301782080', 'E394318005099', '', '', 0, '', '', '', '', '', '', 'navi_gator@mail.ru');
INSERT INTO `ri_user` VALUES (305, '2007-01-08', 'family_klaim@mail.ru', '141278', '', 'IraKlaim', '', '', '()', '8-908-833-33-63', '', '', 'Шадринск', 0, 0, '157251993', 1664, '', '', '', '', '', 0, '', '', '', '', '', '', 'family_klaim@mail.ru');
INSERT INTO `ri_user` VALUES (306, '2007-01-15', 'alanbelyakov@rambler.ru', '4589111', '', '', '', '', '', '', '', '', 'Москва', 0, 0, '', 1783, '', '', '', '4100184756634', '', 70, '', '', 'referat.ru;repetitor-m.ru;open.ref.uz;rebona.ru;referat.com;students.ru;5balov.ru;kref.ru;p6.ru;', 'referat.ru;bankreferatov.ru;repetitor-m.ru;open.ref.uz;referat.com;5balov.ru;rebona.ru;kref.ru;p6.ru;', '', '', 'alanbelyakov@rambler.ru');
INSERT INTO `ri_user` VALUES (307, '2007-01-16', 'Leftjan@mail.ru', '12345', '', '', '', '', '', '89183467590', '', '89182877265', 'Краснодар', 0, 0, '', 1370, '', '', '', '4100192852782', '', 250, '', '1года', 'moreferatov.ru;diplomz.ru;', 'zakagidiplom.ru;', 'bankreferatov.ru;', '', 'Leftjan@mail.ru');
INSERT INTO `ri_user` VALUES (308, '2007-01-18', 'light83@mail.ru', 'ruslan', '', '', '', '', '', '8-927-374-68-82', '', '', 'Пенза', 0, 0, '297805800', 3791, '', '', '', '41001156383561', 'Оплата принимается почтовым переводом, денежными системами Western Union, Contact. Возможна оплата сотовой связи при заказе курсовой работы, доклада, реферата (вы можете пополнить баланс моего счета, либо прислать по смс номер карточки. мой опреатор - Мегафон Поволжье)? а также веб-моней', 24, '', '', 'penza-online.ru;', 'penza-online.ru;', 'kulichiki.ru;', '', 'light83@mail.ru');
INSERT INTO `ri_user` VALUES (309, '2007-01-20', 'gul7772@yandex.ru', 'пароль', '', 'Гульназ', '', '', '', '', '', '', 'Баймак', 0, 0, '', 3701, '811439250368', '146410103808', '', '4100192380455', '', 100, '', '', '', '', '5ballov.ru;referat.ru;referatovnet.ru;mamadu.ru;', '', 'gul7772@yandex.ru');
INSERT INTO `ri_user` VALUES (310, '2007-01-22', 'mistlle@bk.ru', '1243', '', 'LNK', '', '', '', '8-915-437-90-92', '', '', 'Москва', 0, 0, '', 1240, '', '', '', '', '', 500, '', '', '', '', '', '', 'mistlle@bk.ru');
INSERT INTO `ri_user` VALUES (311, '2007-01-23', 'trinik67@mail.ru', 'avtor', '', 'Тригубенко Николай', '', '', '(4832) 567988', '8-909-240-84-32', '', '', 'Брянск', 0, 0, '369554798', 1982, '', '', '', '41001116539008', '', 100, '', '', '', '', '', '', 'trinik67@mail.ru');
INSERT INTO `ri_user` VALUES (312, '2007-01-24', 'nkhimina@yandex.ru', '19841985', '', 'Jocker9', '', '', '()', '', '', '', 'Ярославль', 0, 0, '', 1799, '', '', '', '', '', 0, '', '', '', '', '', '', 'nkhimina@yandex.ru');
INSERT INTO `ri_user` VALUES (313, '2007-01-31', 'iv-vi@mail.ru', 'IVVIIVVI', '', 'IV-VI', '', '', '()', '89021102367', '', '', 'Астрахань', 0, 0, '', 1267, '', '', '', '', '', 0, '', '', '', '', '', '', 'iv-vi@mail.ru');
INSERT INTO `ri_user` VALUES (314, '2007-02-01', 'grechko71@yandex.ru', 'altpacdz', '', 'grechko', '', '', '()', '8-917-213-07-36', '', '', 'Саратов', 0, 0, '', 1273, '', '', '', '', '', 0, '', '', '', '', '', '', 'grechko71@yandex.ru');
INSERT INTO `ri_user` VALUES (315, '2007-02-01', 'rudneva_marina@mail.ru', '11071978', '', '', '', '', '8/06256/5-27-28', '+380979204354', '', '', 'Снежное', 0, 0, '163773908', 1409, '', '', '', '41001118785924', '', 70, '', '', '', '', 'bankreferatov.ru;', '', 'rudneva_marina@mail.ru');
INSERT INTO `ri_user` VALUES (316, '2007-02-02', 'Stas1810@yandex.ru', '412212', '', 'Стас', '', '', '412212', '', '', '', 'Братск', 0, 0, '', 1275, '', '', '', '4100194463707', '', 10, '', '', '', '', '', '', 'Stas1810@yandex.ru');
INSERT INTO `ri_user` VALUES (317, '2007-02-02', 'independenttt@yandex.ru', 'mystery', '', 'parvenu', '', '', '', '+7 926 2744976', '', '', 'Москва', 0, 0, '306450997', 1501, '', '', '', '4100193167476', '', 20, '', '', 'bankrabot.ru;', 'pravodiplom.ru;', '', '', 'independenttt@yandex.ru');
INSERT INTO `ri_user` VALUES (318, '2007-02-02', 'pvcom@bk.ru', 'pontcho', '', 'pvcom', '', '', '()', '89051209181', '', '', 'Тамбов', 0, 0, '', 1275, '', '', '', '', '', 0, '', '', '', '', '', '', 'pvcom@bk.ru');
INSERT INTO `ri_user` VALUES (319, '2007-02-04', 'discovery13@yandex.ru', 'qwert13', '', 'discovery13', '', '', '()', '89023803217', '', '', 'Волгоград', 0, 0, '371948750', 1278, '', '', '', '', '', 0, '', '', '', '', '', '', 'discovery13@yandex.ru');
INSERT INTO `ri_user` VALUES (320, '2007-02-05', 'maxinform@pochta.ru', '19844891', '', 'MaxInform', '', '', '', '+380675451020', '+380577577593', '+380686060624', 'Харьков', 0, 0, '362003641', 1279, '275891071558', '536568056317', '761855599644', '', '', 150, '', '30', '', 'bankreferatov.ru;', 'bankreferatov.ru;', '', 'maxinform@pochta.ru');
INSERT INTO `ri_user` VALUES (321, '2007-02-05', 'nmishurova@rambler.ru', 'nataschka', '', 'Nataschka', '', '', '', '80977138235', '7559185', '', 'Харьков', 0, 0, '478979190', 1287, '', '165247757632', '', '', '', 40, '', '', '', '', '', '', 'nmishurova@rambler.ru');
INSERT INTO `ri_user` VALUES (322, '2007-02-06', 'katya_lal@mail.ru', 'rfnz', '', 'katya_lal', '', '', '', '', '', '', 'Киров', 0, 0, '', 1281, '', '', '', '4100131036811', '', 100, '', '', 'bankreferatov.ru;', 'bankreferatov.ru;', 'bankreferatov.ru;', '', 'katya_lal@mail.ru');
INSERT INTO `ri_user` VALUES (323, '2007-02-07', 'cra147@vlpost.ru', '121314', '', '', '', '', '()', '8-9026562562', '', '', 'Фролово Волгоградской области', 0, 0, '', 1813, '', '', '', '', '42301810811230188117/01 во Фроловском ОСБ№3950 Волгоградского ОСБ №8621  БИК 041806001 к/сч 30101810100000000647', 0, '', '', '', '', '', '', 'cra147@vlpost.ru');
INSERT INTO `ri_user` VALUES (324, '2007-02-10', 'olga200581@mail.ru', 'zrmfaxna', '', 'Bykova', '', '', '', '89021788853', '', '', 'Усолье-Сибирское', 0, 0, '', 1290, '934744303663', '624006071109', '310351572105', '', '', 10, '', '', 'laborant.org.ua;', 'open.ref.uz;krasnodar.bip.ru;', 'referats.ru;', '', 'olga200581@mail.ru');
INSERT INTO `ri_user` VALUES (325, '2007-02-13', 'kagon@bk.ru', '220604', '', 'Sashik', '', '', '()', '910-585-15-05', '', '', 'Тула', 0, 0, '273997464', 1323, '', '', '', '', '', 0, '', '', '', '', '', '', 'kagon@bk.ru');
INSERT INTO `ri_user` VALUES (326, '2007-02-18', 'smileee@list.ru', '12345', '', 'Nata', '', '', '', '', '', '', 'Владикавказ', 0, 0, '', 1311, '', '', '', '', '', 100, '', '', '', '', '', '', 'smileee@list.ru');
INSERT INTO `ri_user` VALUES (327, '2007-02-20', 'zlata_ruaf@mail.ru', '310553', '', '', '', '', '()', '8(050)297-07-54', '', '', 'Феодосия', 0, 0, '270887227', 1591, '241766074511', '207578496521', '417245262449', '', '', 0, '', '', '', '', '', '', 'zlata_ruaf@mail.ru');
INSERT INTO `ri_user` VALUES (328, '2007-02-21', 'mnbv-001@mail.ru', '030878', '', '', '', '', '()', '89278538010', '', '', 'Н.Чебоксарск', 0, 0, '', 1376, '', '', '', '', 'Чувашское ОСБ 8613 Волго-вятского банка\r\nДополнительный офис №8613\\017 г.Чебоксары\r\nБИК 049706609\r\nИНН 7707083893\r\nКор\\сч 30101810300000000609\r\nРасчетный счет: 42307810675222110152\r\nПолучатель: Петрова Светлана Валерьевна\r\n\r\n', 0, '', '', '', '', '', '', 'mnbv-001@mail.ru');
INSERT INTO `ri_user` VALUES (329, '2007-02-21', 'karina-home@bk.ru', '20440499', '', '', '', '', '()', '89242218251', '', '', 'Хабаровск', 0, 0, '376-787-975', 1561, 'R711461307711', '', '', '', '', 0, '', '', '', '', '', '', 'karina-home@bk.ru');
INSERT INTO `ri_user` VALUES (330, '2007-02-22', 'estdelo@gmail.com', '', '', '', '', '', '(495)7519214', '9060482108', '', '', 'москва', 0, 0, '', 1332, '', '', '', '', '', 0, '', '', '', '', '', '', 'estdelo@gmail.com');
INSERT INTO `ri_user` VALUES (331, '2007-02-22', 'poletovaev@mail.ru', 'ledi1982', '', '', '', '', '()', '8-905-667-09-14', '', '', 'Кстово', 0, 0, '', 2885, 'R158314580802', '', '', '41001131805994', '', 12, '', '', '', '', '', '', 'poletovaev@mail.ru');
INSERT INTO `ri_user` VALUES (332, '2007-02-26', 'il_25@inbox.ru', '5675', '', '', '', '', '89184647707', '', '', '', 'Краснодар', 0, 0, '303424672', 1348, '', '', '', '', '', 0, '', '', '', '', '', '', 'il_25@inbox.ru');
INSERT INTO `ri_user` VALUES (333, '2007-03-02', 'programpc@mail.ru', 'mk325509', '', '', '', '', '()', '80679413717', '', '', 'Харьков', 0, 0, '334872435', 1443, 'R400634988548', 'Z202186669172', 'E353665235860', '', '', 50, '', '', '', '', '', '', 'programpc@mail.ru');
INSERT INTO `ri_user` VALUES (334, '2007-03-04', 'yelloygerda@list.ru', 'verba', '', 'Varshava', '', '', '', '', '', '', 'Москва', 0, 0, '347244743', 1352, '', '', '', '4100172772516', '', 2, '', '', 'community.livejournal.com;', 'community.livejournal.com;', 'findreferat.ru;', '', 'yelloygerda@list.ru');
INSERT INTO `ri_user` VALUES (335, '2007-03-07', 'bulat678@mail.ru', 'z68987191', '', 'Булат', '', '', '(3812)559-150', '8 913 602 59 64', '', '', 'Омск', 0, 0, '', 1449, '', '', '', '', '', 0, '', '', '', '', '', '', 'bulat678@mail.ru');
INSERT INTO `ri_user` VALUES (336, '2007-03-11', 'kronvol@mail.ru', '240668', '', 'ФЕДОРОВ', '', '', '8(812)3110305', '89112927324', '', '', 'С-ПЕТЕРБУРГ', 0, 0, '', 1630, '', '', '', '', '', 10, '', '', '', 'http://www.reff.ru/;', '', '', 'kronvol@mail.ru');
INSERT INTO `ri_user` VALUES (337, '2007-03-12', 'superdiplom@inbox.ru', 'rabbit', '', 'superdiplom', '', '', '()', ' 375292772464', '', '', 'Минск', 0, 0, '262-757-005', 1444, '', '', '', '', '', 0, '', '', '', '', '', '', 'superdiplom@inbox.ru');
INSERT INTO `ri_user` VALUES (338, '2007-03-12', 'logoped76@mail.ru', '1234', '', 'Козубl', '', '', '(3532)89225365636', '89225365636', '', '', 'Оренбург', 0, 0, '362-813-049', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'logoped76@mail.ru');
INSERT INTO `ri_user` VALUES (339, '2007-03-17', 'saenko.e.sunny@mail.ru', 'rhjkbr', '', 'Sunny', '', '', '()', '89275053456', '', '', 'Волгоград', 0, 0, '', 1386, '', '', '', '', '', 0, '', '', '', '', '', '', 'saenko.e.sunny@mail.ru');
INSERT INTO `ri_user` VALUES (340, '2007-03-18', 'avrodionova@yandex.ru', 'animaya', '', 'майя', '', '', '(812)4445663', '', '', '', 'СПб', 0, 0, '', 1387, '', '', '', '', '', 0, '', '', '', '', '', '', 'avrodionova@yandex.ru');
INSERT INTO `ri_user` VALUES (341, '2007-03-18', 'anton00778@mail.ru', '20012007', '', 'Юлия Андреевна', '', '', '()', '8(906)7935570', '', '', 'Электросталь Московской области', 0, 0, '', 1417, '', '', '', '', '', 0, '', '', '', '', '', '', 'anton00778@mail.ru');
INSERT INTO `ri_user` VALUES (342, '2007-03-18', 'artem55552007@yandex.ru', '20041985', '', '', '', '', '', '89012658870', '', '', 'Пермь', 0, 0, '', 2135, '', '', '', '41001140842891', '', 28, '', '', 'ZAKAZDIPLOM.RU;', 'ZAKAZDIPLOM.RU;', 'bankreferatov.ru;', '', 'artem55552007@yandex.ru');
INSERT INTO `ri_user` VALUES (343, '2007-03-19', 'aleksei_aduevski@mail.ru', 'qwerty', '', '', '', '', '', '123456789', '', '', 'Москва', 0, 0, '', 1444, '', '', '', '', '', 8, '', '', 'readywork.ru;diplommake.ru;diplom.diplomz.ru;diplompravo.ru;diplom-market.ru;www.diplomx.ru;morereferatov.ru;planetareferatov.ru;exay.ru;', 'exay.ru;planetareferatov.ru;morereferatov.ru;www.diplomx.ru;diplompravo.ru;diplom-market.ru;diplom.diplomz.ru;diplommake.ru;readywork.ru;', '5ballov.ru;referatov.ne;referat.ru;sachok.ru;', '', 'aleksei_aduevski@mail.ru');
INSERT INTO `ri_user` VALUES (344, '2007-03-23', 'intellektual@bk.ru', 'agapesekret', '', '', '', '', '((4732))91-72-79', '8-9507599856', '', '', 'г. Воронеж', 0, 0, '', 1712, '', '', '', '4100128848682', '', 0, '', '', '', '', '', '', 'intellektual@bk.ru');
INSERT INTO `ri_user` VALUES (345, '2007-03-27', 'miromax_06@mail.ru', '281284', 'Miromax', '', '', '', '', '', '', '', 'Омск', 0, 0, '', 4426, '', '', '', '', '', 8, '', '', '', '', '', '', 'miromax_06@mail.ru');
INSERT INTO `ri_user` VALUES (346, '2007-03-30', 'demenev81@mail.ru', '567030', '', 'Roman', '', '', '()', '89620344903', '', '', 'Омск', 0, 0, '', 1832, '', '', '', '4100120808396', '', 0, '', '', '', '', '', '', 'demenev81@mail.ru');
INSERT INTO `ri_user` VALUES (347, '2007-04-02', 'lida4101984@yandex.ru', '9417', '', 'Лидия', '', '', '', '+79198880053', '', '', 'Ростов-на-Дону', 0, 0, '', 1464, '', '', '', '', '', 20, '', '', '', '', '', '', 'lida4101984@yandex.ru');
INSERT INTO `ri_user` VALUES (348, '2007-04-03', 'ivanov-alen@yandex.ru', 'pfzw-,tkzr', '', 'Gessen', '', '', '()', '8-903-949-35-20', '', '', 'Барнаул', 0, 0, '336138410', 1663, '', '', '', '', '', 0, '', '', '', '', '', '', 'ivanov-alen@yandex.ru');
INSERT INTO `ri_user` VALUES (349, '2007-04-03', 'incarium@yandex.ru', '17121949', '', 'incarium', '', '', '()', '80987907688', '', '', 'Украина, Сумы', 0, 0, '289015510', 1474, '', '', '', '', '', 0, '', '', '', '', '', '', 'incarium@yandex.ru');
INSERT INTO `ri_user` VALUES (350, '2007-04-04', 'alinamail168@rambler.ru', '631234', '', 'Алина', '', '', '', '', '', '', 'Асекеево', 0, 0, '423654929', 1549, '', '', '', '', '', 0, '', '', '', '', '', '', 'alinamail168@rambler.ru');
INSERT INTO `ri_user` VALUES (351, '2007-04-09', 'garmall@yandex.ru', 'zvkwhpdy', '', 'allagarmanova', '', '', '()', '89067563070', '', '', 'Москва', 0, 0, '424224996', 1495, '', '', '', '', '', 0, '', '', '', '', '', '', 'garmall@yandex.ru');
INSERT INTO `ri_user` VALUES (352, '2007-04-12', 'vaulter@nm.ru', 'demonium', '', 'Vaulter', '', '', '()', ' 79053397660', '', '', 'Волгоград', 0, 0, '', 1516, '', '', '', '', '', 0, '', '', '', '', '', '', 'vaulter@nm.ru');
INSERT INTO `ri_user` VALUES (353, '2007-04-12', 'margo123@list.ru', '270385', '', '', '', '', '', '', '', '', 'Москва', 0, 0, '', 4262, '', '', '', '41001300968601', '', 13, '', '', '', '', '', '', 'margo123@list.ru');
INSERT INTO `ri_user` VALUES (354, '2007-04-17', 'julia147_81@mail.ru', '20012007', '', 'Джульетта', '', '', '', '9067935570', '', '', 'Ногинск', 0, 0, '456279852', 1538, '', '', '', '41001128206412', '', 15, '', '', '', '', '', '', 'julia147_81@mail.ru');
INSERT INTO `ri_user` VALUES (355, '2007-04-22', 'Balagurov_V@mail.ru', 'B340v792347', '', 'Балагуров Владимир Юрьевич', '', '', '8 4752 521566', '8 920 23 11 555', '', '', 'Тамбов', 0, 0, '', 1555, '434165206438', '713283621676', '473750604859', '', '', 0, '', '', '', '', '', '', 'Balagurov_V@mail.ru');
INSERT INTO `ri_user` VALUES (356, '2007-04-24', 'seregarem@rambler.ru', '1983', '', 'seregarem', '', '', '(8332)63-21-41', '8-912-376-40-23', '', '', 'Киров', 0, 0, '314-357-150', 1561, '', '', '', '', '', 0, '', '', '', '', '', '', 'seregarem@rambler.ru');
INSERT INTO `ri_user` VALUES (357, '2007-04-30', 'degotb@rambler.ru', '729559', '', 'Борис', '', '', '(812)573356', '89114039624', '', '', 'Петрозаводск', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'degotb@rambler.ru');
INSERT INTO `ri_user` VALUES (358, '2007-04-30', 'Anusha25@mail.ru', '250580', '', 'Anusha25', '', '', '(812)590-29-20', '89500250510', '', '', 'Санкт-Петербург', 0, 0, '', 1583, '', '', '', '', '', 0, '', '', '', '', '', '', 'Anusha25@mail.ru');
INSERT INTO `ri_user` VALUES (359, '2007-04-30', 'helper_stud@mail.ru', 'xaxa2007stud', '', '', '', '', '', '', '', '', 'Москва', 0, 0, '', 1586, '527465774319', '809745517123', '382017246505', '', '', 51, '', '30 дней', '5ka.ru;', '5ka.ru;', 'referat.com;bankreferatov.ru;referat.ru;5ballov.ru;kursoviki.spb.ru  ;stydenty.ru;vsereferati.ru  ;free-referat.ru ;', '', 'helper_stud@mail.ru');
INSERT INTO `ri_user` VALUES (360, '2007-05-06', 'mahotina_s@mail.ru', 'znanie5', 'Светлана Александровна', '', '', '', '(4852) 98-36-07', '89038200500', '', '89159702224', 'Ярославль', 0, 0, '', 4345, 'R817565300259', 'Z368269072060', 'E714247168888', '41001146481526', 'Ярославское отделение Сбербанка России № 6625 (150049, г. Ярославль, Свободы, 91)\r\nСчет № 42307.810.7.77120001287/48\r\nМахотина Светлана Александровна', 75, '', '', 'www.studenti.ru;', '', '5ballov.ru;', '', 'mahotina_s@mail.ru');
INSERT INTO `ri_user` VALUES (361, '2007-05-15', 'dmgubenko@yandex.ru', 'k1zhpqj', '', 'Dim', '', '', '', '', '', '', 'Новосибирск', 0, 0, '', 1679, '062586924642', '727234336000', '543389164728', '', '', 10, '', '', 'refbank.ru;', 'refbank.ru;', 'refbank.ru;', '', 'dmgubenko@yandex.ru');
INSERT INTO `ri_user` VALUES (362, '2007-05-15', 'stasiya2@rambler.ru', '020986', '', '', '', '', '', '8-926-3965546', '', '', 'Москва', 0, 0, '347975483', 1751, '', '', '', '4100192095037', '', 10, '', '', '', '', '', '', 'stasiya2@rambler.ru');
INSERT INTO `ri_user` VALUES (363, '2007-05-16', 'zion@newmail.ru', '07051986', '', 'zion', '', '', '', '', '', '', 'Тюмень', 0, 0, '390426634', 1647, '', '', '', '41001135915497', '', 20, '', '', '', '', '', '', 'zion@newmail.ru');
INSERT INTO `ri_user` VALUES (364, '2007-05-16', 'kazakov_ilya@mail.ru', 'gjrfnbktyrj', '', 'Казаков Илья Владимирович', '', '', '83812557891', '89045850528', '', '', 'Омск', 0, 0, '', 1813, '003086836798', '', '', '', '', 5, '', '', '', '', '', '', 'kazakov_ilya@mail.ru');
INSERT INTO `ri_user` VALUES (365, '2007-05-16', 'mathbox@rambler.ru', '4121751983', '', '', '', '', '(4872)412175', '8-920-753-2082', '', '', 'Тула', 0, 0, '', 1771, '', '', '', '', 'Сбербанк – Maestro 40817810966064911771', 200, '', '', '', '', '', '', 'mathbox@rambler.ru');
INSERT INTO `ri_user` VALUES (366, '2007-05-16', 'o_gyrianova@mail.ru', 'qwertyuiop', '', 'гурьянчик', '', '', '4922506', '8-926-41-77-869', '7814848 доб.204', '', 'Москва', 0, 0, '', 0, '', '', '', '', '', 25, '', 'месяц', 'neZnau.ru;', 'neZnau.ru;', 'neZnau.ru;', '', 'o_gyrianova@mail.ru');
INSERT INTO `ri_user` VALUES (367, '2007-05-17', 'nad_zer@list.ru', 'ghbdtn', '', 'Надежда', '', '', '83012-233106', '89503856944', '', '', 'Улан-Удэ', 0, 0, '', 3752, '', '', '', '4100124227404', '', 1000, '', '', '', '', '', '', 'nad_zer@list.ru');
INSERT INTO `ri_user` VALUES (368, '2007-05-17', 'z-novoch@bk.ru', 'spiro', '', 'duk', '', '', '(886352)43316', '', '', '', 'Новочеркасск', 0, 0, '', 0, '', '', '', '41001106808192', '', 0, '', '', '', '', '', '', 'z-novoch@bk.ru');
INSERT INTO `ri_user` VALUES (369, '2007-05-20', 'xom7@rambler.ru', 'эпсон', '', '', '', '', '6773957', '89164120210', '', '', 'Москва', 0, 0, '207343290', 1806, '', '', '', '', 'Оплата производится через Сбербанк\r\n\r\nРасчетный счет   30301810838000603825\r\n\r\nКорсчет   30101810400000000225\r\n\r\nБИК   044525225     ИНН   7707083893\r\n\r\nКПП   775001001', 25, '', '', '', '', '', '', 'xom7@rambler.ru');
INSERT INTO `ri_user` VALUES (370, '2007-05-22', 'm-e-f@list.ru', '12140925', '', 'Жесика', '', '', '', '89184151383', '', '', 'Армавир', 0, 0, '', 1783, '349433926251', '150713334307', '266963729005', '41001141590327', '', 10, '', '', 'prepadav.net;shumilin.kurskline.ru;diplomukr.com.ua;', 'gotovoe.narod.ru;moreferatov.ru;', 'bankreferatov.ru;economika.info;realreferat.ru;refstar.ru;examen.od.ua;', '', 'm-e-f@list.ru');
INSERT INTO `ri_user` VALUES (371, '2007-05-22', 'jhon@santechnika.ru', 'tinajhon', '', 'jhon', '', '', '', '', '', '', 'москва', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'jhon@santechnika.ru');
INSERT INTO `ri_user` VALUES (372, '2007-05-22', 'alet2104@rambler.ru', 'vfvfyz', '', 'VaLPet', '', '', '()', ' 7 920 639 70 65', '', '', 'Рязань', 0, 0, '491294483', 1672, '', '', '', '', '', 0, '', '', '', '', '', '', 'alet2104@rambler.ru');
INSERT INTO `ri_user` VALUES (373, '2007-05-25', 'svragov@yandex.ru', '912760', '', 'svragov', '', '', '', '', '', '', 'Воронеж', 0, 0, '423478358', 1688, '', '', '', '', '', 0, '', '', 'bankreferatov.ru;', 'bankreferatov.ru;', 'bankreferatov.ru;', '', 'svragov@yandex.ru');
INSERT INTO `ri_user` VALUES (374, '2007-06-01', 'OK-1111@yandex.ru', '2rhjyz', '', 'ok-1111', '', '', '', '896216576543', '', '', 'Москва', 0, 0, '', 2316, '', '', '', '4100170329163', '', 7000, '', '', 'Реферат.ру;Олбест.ру;Студенточка.ру;', 'Реферат.ру;Олбест.ру;Студенточка.ру;', 'Реферат.ру;Олбест.ру;Студенточка.ру;', '', 'OK-1111@yandex.ru');
INSERT INTO `ri_user` VALUES (375, '2007-06-04', 'lena.shvedun@mail.ru', '09081978', '', '03021996', '', '', '()', '80976755549', '', '', 'Киевская обл. г. Белая Церковь', 0, 0, '', 1725, '', '', '', '', '', 0, '', '', '', '', '', '', 'lena.shvedun@mail.ru');
INSERT INTO `ri_user` VALUES (376, '2007-06-05', 'dietalove@mail.ru', 'nefteygansk', '', 'КВНщица', '', '', '', '89224797009', '', '', 'Тюмень', 0, 0, '337074528', 1730, '', '', '', '', '', 35, '', '', '', '', '', '', 'dietalove@mail.ru');
INSERT INTO `ri_user` VALUES (377, '2007-06-08', 'tuchka0@rambler.ru', '240787', '', 'tuchka0', '', '', '', '', '', '', 'Ставрополь', 0, 0, '', 1751, '1500', '', '', '', '', 10, '', '', '', '', '', '', 'tuchka0@rambler.ru');
INSERT INTO `ri_user` VALUES (378, '2007-06-13', 'balina.natalja@rambler.ru', 'natasha', '', 'Natasha', '', '', '', '8 903 1323792', '', '', 'москва', 0, 0, '479014635', 1777, '', '', '', '', '', 2, '', '', '', '', '', '', 'balina.natalja@rambler.ru');
INSERT INTO `ri_user` VALUES (379, '2007-06-14', 'avaddon07@yahoo.com', 'armageddon', '', 'avaddon', '', '', '()', ' 73514422108', '', '', 'Челябинск', 0, 0, '', 1749, '', '', '', '41001124546245', '', 0, '', '', '', '', '', '', 'avaddon07@yahoo.com');
INSERT INTO `ri_user` VALUES (380, '2007-06-15', 'lebed2008@ngs.ru', 'yfvtcnybr', '', '', '', '', '()', '8 913 207 79 76', '', '', 'Новосибирск', 0, 0, '', 1749, '', '', '', '41001144141185', '', 0, '', '', '', '', '', '', 'lebed2008@ngs.ru');
INSERT INTO `ri_user` VALUES (381, '2007-06-18', 'olesbus@mail.ru', 'Jktcz1963', '', '', '', '', '', '89265931413', '5971011', '', 'москва', 0, 0, '', 1771, '', '', '', '', '', 2, '', '', 'referatovnet.ru;', 'referatovnet.ru;', 'referatovnet.ru;', '', 'olesbus@mail.ru');
INSERT INTO `ri_user` VALUES (382, '2007-06-21', 'rus-alexis-ukr@mail.ru', '159357', '', 'Alexis_FX', '', '', '()', ' 380682595580', '', '', 'Одесса', 0, 0, '292081911', 1912, '', '', '', '', '', 0, '', '', '', '', '', '', 'rus-alexis-ukr@mail.ru');
INSERT INTO `ri_user` VALUES (383, '2007-06-23', 'kapusta1985@list.ru', '1306', '', 'Nuetti', '', '', '', '89184897233', '', '', 'Краснодар', 0, 0, '', 1801, '2500', '', '', '', '', 5, '', '', 'bankreferatov.ru;', 'bankreferatov.ru;', 'bankreferatov.ru;', '', 'kapusta1985@list.ru');
INSERT INTO `ri_user` VALUES (384, '2007-06-24', 'rusalochka85@rambler.ru', '198559245', '', 'Бутенко', '', '', '', '994503558881', '', '', 'Баку', 0, 0, '', 1779, '902025436723', '068508880762', '491512287470', '', '', 1, '', '', '', '', '', '', 'rusalochka85@rambler.ru');
INSERT INTO `ri_user` VALUES (385, '2007-06-25', 'Lezhnefant@mail.ru', '30061981', '', 'Дугаева  Алёна', '', '', '', '89617923185', '', '', 'Челябинск', 0, 0, '', 1935, '', '', '', '41001123986493', '', 75, '', '', '', '', 'cityref.ru;', '', 'Lezhnefant@mail.ru');
INSERT INTO `ri_user` VALUES (387, '2007-07-13', 'nif-nif82@mail.ru', 'uss82', '', 'тов. Фрунзе', '', '', '', '', '', '', 'Саратов', 0, 0, '', 1841, '', '', '', '', '', 100, '', '', '', '', '', '', 'nif-nif82@mail.ru');
INSERT INTO `ri_user` VALUES (388, '2007-07-17', 'ele2364@yandex.ru', '3230930721', '', 'Захарченко  Алена', '', '', '80625930721', '80982160358', '80625923218', '', 'Амвросиевка', 0, 0, '422442657', 0, '427474726500', '702572798335', '596920991352', '4100147846107', '', 100, '', '6  месяцев', 'diplomz.com;', 'job.ru;', 'albest.ru;', '', 'ele2364@yandex.ru');
INSERT INTO `ri_user` VALUES (389, '2007-07-20', 'diplom_77@mail.ru', '764199', '', 'sanek', '', '', '', '', '', '', 'Москва', 0, 0, '', 1799, '', '', '', '', '', 100, '', '', 'bankreferatov.ru;', 'bankreferatov.ru;', 'bankreferatov.ru;', '', 'diplom_77@mail.ru');
INSERT INTO `ri_user` VALUES (390, '2007-07-25', 'my-phoenix@mail.ru', 'atybrc', '', 'Oksana', '', '', '046(22)952342', '', '', '', 'Чернигов', 0, 0, '363213892', 1800, '', '', '', '', '', 10, '', '', '', '', '', '', 'my-phoenix@mail.ru');
INSERT INTO `ri_user` VALUES (391, '2007-07-27', 'dokish75@mail.ru', 'лето', '', 'Нелли', '', '', '()', '89066413838', '', '', 'Боровск Калужская обл.', 0, 0, '', 1801, '', '', '', '', '', 0, '', '', '', '', '', '', 'dokish75@mail.ru');
INSERT INTO `ri_user` VALUES (392, '2007-08-07', 'bsr07@list.ru', '160703', '', 'Лана', '', '', '', '', '', '', 'Чебоксары', 0, 0, '', 1805, '', '', '', '', '', 800, '', '', '', '', '', '', 'bsr07@list.ru');
INSERT INTO `ri_user` VALUES (393, '2007-08-13', 'burova-irene@mail.ru', 'ira18', '', 'Vivie', '', '', '()', ' 79209517024', '', '', 'Москва', 0, 0, '', 2716, '', '', '', '', '', 0, '', '', '', '', '', '', 'burova-irene@mail.ru');
INSERT INTO `ri_user` VALUES (394, '2007-08-18', 'Loky-332.80@mail.ru', '33322232', '', 'Loky-332', '', '', '4712 50-34-80', '', '4712 560880', '', 'Курск', 0, 0, '', 3752, '178611665364', '', '', '', '', 25, '', '', '', '', '', '', 'Loky-332.80@mail.ru');
INSERT INTO `ri_user` VALUES (395, '2007-08-19', 'ildiz1@yandex.ru', '5168824', '', '', '', '', '()', ' 79119001368', '', '', 'Санкт-Петербург', 0, 0, '252565370', 2703, '', '', '', '4100153611781', '', 170, '', '', '', '', '', '', 'ildiz1@yandex.ru');
INSERT INTO `ri_user` VALUES (396, '2007-08-19', 'constantamv2006@rambler.ru', '180977', '', 'marinavv', '', '', '(8443)415039', '89023872773', '', '', 'Волгоград', 0, 0, '', 1810, '', '', '', '', '', 0, '', '', '', '', '', '', 'constantamv2006@rambler.ru');
INSERT INTO `ri_user` VALUES (397, '2007-08-23', '213826@mail.ru', 'tolerance', '', 'Vita', '', '', '37322(213826)', '37369300388', '', '', 'Кишинёв', 0, 0, '216733671', 2127, '', '', '', '', '', 0, '', '', '', '', '', '', '213826@mail.ru');
INSERT INTO `ri_user` VALUES (398, '2007-09-04', 'info.createit@gmail.com', 'creator', '', 'CreatOR', '', '', '363815', '', '', '', 'Rostov', 0, 0, '', 1843, '', '', '', '', '', 120, '', '15days', '', '', '', '', 'info.createit@gmail.com');
INSERT INTO `ri_user` VALUES (399, '2007-09-05', 'sneg2@ellink.ru', '250391', '', '', '', '', '(250)2-14-62', '911-371-95-22', '', '', 'Псковская обл., ПГТ Усвяты', 0, 0, '', 4349, '№41001157869871', '', '', '', '', 0, '', '', '', '', '', '', 'sneg2@ellink.ru');
INSERT INTO `ri_user` VALUES (400, '2007-09-10', 'brownie2007@bk.ru', '', '', '', '', '', '', '+79616310597', '', '', 'Городец', 0, 0, '357452552', 4240, '', '', '', '41001123783903', '', 16, '', '', '', '', 'Allbest.ru;Bankreferatov.ru;', '', 'brownie2007@bk.ru');
INSERT INTO `ri_user` VALUES (401, '2007-09-12', 'nastref@rambler.ru', 'asddsa', 'Реальное имя', '', '', '', '', '+79047704344', '', '', 'Жирновск', 0, 0, '', 4169, '', '', '', '4100143226188', '', 250, '', '', '', '', '', '', 'nastref@rambler.ru');
INSERT INTO `ri_user` VALUES (402, '2007-09-13', 'cher_vlad@mail.ru', '2101', '', 'Vladimir', '', '', '247300', '9132304480', '', '', 'Бийск', 0, 0, '', 0, '', '', '', '', '', 30, '', '', '', '', '', '', 'cher_vlad@mail.ru');
INSERT INTO `ri_user` VALUES (403, '2007-09-15', 'retyhnec@mail.ru', 'qwed32a', '', 'Romann', '', '', '80532 637559', '8097 8625599', '', '', 'Полтава', 0, 0, '', 1914, '599767013427', '087376223530', '415814043484', '', '', 8, '', '', 'diplom-service.ru;1001referat.ru;', 'diplom-service.ru;1001referat.ru;', 'diplom-service.ru;1001referat.ru;', '', 'retyhnec@mail.ru');
INSERT INTO `ri_user` VALUES (404, '2007-09-17', 'refavtor@mail.ru', 'uvk83', '', 'Константин Лосев', '', '', '', '+79053686459', '', '', 'Саратов', 0, 0, '', 2298, '246257539670', '372880954958', '', '41001165345577', '', 200, '', '', 'bankreferatov.ru;referatov.net;referatoff.ru;doski.ru;referat.ru;', 'bankreferatov.ru;referatov.net;referatoff.ru;doski.ru;referat.ru;', 'bankreferatov.ru;referatov.net;referatoff.ru;doski.ru;referat.ru;', '', 'refavtor@mail.ru');
INSERT INTO `ri_user` VALUES (405, '2007-09-18', 'v_dinara@mail.ru', '395847', '', '', '', '', '()', ' 79063259510', '', '', 'Казань', 0, 0, '392-371-638', 4222, '', '', '', 'valeevadinara@yandex.ru', '', 0, '', '', '', '', '', '', 'v_dinara@mail.ru');
INSERT INTO `ri_user` VALUES (406, '2007-09-18', 'bibi222@mail.ru', '8462', '', 'bibi222', '', '', '', '89202843160', '', '', 'Oryol', 0, 0, '', 2441, '197168293031', '', '', '', '', 10, '', '', 'weblancer.ru;', '5ka.ru;', '5ka.ru;', '', 'bibi222@mail.ru');
INSERT INTO `ri_user` VALUES (407, '2007-09-19', 'lenkom1905@mail.ru', '160774', '', 'Елена', '', '', '547246', '', '', '+79051337586', 'Ярославль', 0, 0, '', 1883, '', '', '', '4100139052467', '', 500, '', '', 'nesnau.ru;', 'nesnau.ru;', 'nesnau.ru;', '', 'lenkom1905@mail.ru');
INSERT INTO `ri_user` VALUES (408, '2007-09-21', 'z190404@rambler.ru', '190404', '', 'z190404', '', '', '()', '9058353824', '', '', 'Челябинск', 0, 0, '', 1867, '', '', '', '', '', 0, '', '', '', '', '', '', 'z190404@rambler.ru');
INSERT INTO `ri_user` VALUES (409, '2007-09-22', 'beloborodovdmitrij@rambler.ru', '02041977', '', 'Белобородов', '', '', '', '+79138932711', '', '', 'Куйбышев', 0, 0, '', 2429, '', '', '', '', '', 5, 'http://www.beloborodov6622.narod.ru', '', 'webdoska.msk.ru;bankrabot.ru;', 'bankrabot.ru;', 'eruditiob.ru;', '', 'beloborodovdmitrij@rambler.ru');
INSERT INTO `ri_user` VALUES (410, '2007-10-04', 'sciencevavt@mail.ru', 'cveiimepi', '', 'Kaiser', '', '', '()', ' 79067421240', '', '', 'Москва', 0, 0, '390863926', 1875, '', '', '', '', '', 0, '', '', '', '', '', '', 'sciencevavt@mail.ru');
INSERT INTO `ri_user` VALUES (411, '2007-10-05', 'diplomka@yandex.ru', '198775', '', 'Elka', '', '', '( 38066)8848501', '', '', '', 'Луганск', 0, 0, '204207360', 1973, '', '', '', '', '', 0, '', '', '', '', '', '', 'diplomka@yandex.ru');
INSERT INTO `ri_user` VALUES (412, '2007-10-05', 'cheremok@mail.ru', '090284', '', 'cheremok', '', '', '(3462)210272', '', '', '', 'Сургут', 0, 0, '', 2002, '', '', '', '', '', 0, '', '', '', '', '', '', 'cheremok@mail.ru');
INSERT INTO `ri_user` VALUES (413, '2007-10-07', 'zakazdiplom2007@yandex.ru', 'm67hj90', '', 'Мария8310', '', '', '', '8 924 255 79 76', '', '', 'Владивосток', 0, 0, '', 4341, '', '', '', '41001167698471', '', 250, '', '', 'referat.ru;tixit.ru;master-class-realty.ru;tihomir.ru;doski-pro.ru;', 'referat.ru;tixit.ru;master-class-realty.ru;tihomir.ru;doski-pro.ru;', 'bankreferatov.ru  ;referat.ru;stydenty.ru;VSEREFERATI.RU ;kursach.info;', '', 'zakazdiplom2007@yandex.ru');
INSERT INTO `ri_user` VALUES (414, '2007-10-10', 'kanffx@mail.ru', 'rjhybtyrj', '', 'Корниенко Алексей Николаевич', '', '', '', '79615986280', '', '', 'Краснодар', 0, 0, '', 1898, '693927917479', '599507261020', '', '', '', 6, '', '', '', '', '', '', 'kanffx@mail.ru');
INSERT INTO `ri_user` VALUES (415, '2007-10-16', 'aleksandra-krasn@mail.ru', '140385', '', 'Алекандра', '', '', '(499)6100428', '89031000067', '', '', 'Москва', 0, 0, '458525281', 1900, '', '', '', '', '', 0, '', '', '', '', '', '', 'aleksandra-krasn@mail.ru');
INSERT INTO `ri_user` VALUES (416, '2007-10-18', 'alina-8611@yandex.ru', 'alina261086', '', 'Alina', '', '', '', '', '', '', 'Санкт-Петербург', 0, 0, '', 2225, '', '', '', '41001173059831', '', 10, '', '', '', '', '', '', 'alina-8611@yandex.ru');
INSERT INTO `ri_user` VALUES (417, '2007-10-24', 'ksyxa@mail.ru', '060280', '', 'ksyxa', '', '', '(8152)246743', '8921-734-48-97', '', '', 'Мурманск', 0, 0, '', 1935, '', '', '', '', '', 0, '', '', '', '', '', '', 'ksyxa@mail.ru');
INSERT INTO `ri_user` VALUES (418, '2007-10-26', 'dansu2006@gmail.com', '312644', '', 'dansu', '', '', '()', '420774137327', '', '', 'Прага', 0, 0, '', 1943, '', '', '', '41001152652494', '', 0, '', '', '', '', '', '', 'dansu2006@gmail.com');
INSERT INTO `ri_user` VALUES (419, '2007-10-28', 'neduga@mail.ru', '010483', '', ' igla', '', '', '()', '89112522698', '', '', 'санкт-петербург', 0, 0, '413191590', 1969, '', '', '', '', '', 0, '', '', '', '', '', '', 'neduga@mail.ru');
INSERT INTO `ri_user` VALUES (420, '2007-10-28', 'tignata@yandex.ru', 'nikita', '', 'tignata', '', '', '(8908)7418044', '', '', '', 'Нижний Новгород', 0, 0, '', 2057, '', '', '', '', '', 0, '', '', '', '', '', '', 'tignata@yandex.ru');
INSERT INTO `ri_user` VALUES (421, '2007-10-28', 'oiltanker73@mail.ru', 'sabanov1973', '', '', '', '', '', '', '', '', 'Tyumen', 0, 0, '391284000', 2087, '156318149133', '330864536177', '096737644626', '41001182921620', '', 50, '', '', '', '', '', '', 'oiltanker73@mail.ru');
INSERT INTO `ri_user` VALUES (422, '2007-10-29', 'kanjukva@rambler.ru', 'zgjikfljvjq', '', 'Канюкова Надежда Владимировна', '', '', '28393', '89028192870', '37811', '', 'Ханты-Мансийск', 0, 0, '', 0, '', '', '', '', '', 15, '', '', '', '', '', '', 'kanjukva@rambler.ru');
INSERT INTO `ri_user` VALUES (423, '2007-10-30', 'dveg2004@mail.ru', 'zaikamoy210179', '', '', '', '', '', '', '', '', 'Владивосток', 0, 0, '497419848', 4348, '287419825692', '272007631405', '184654848394', '', '', 2000, '', '', 'www.stydenty.info;', 'www.allbest.ru;', 'www.5ballov.ru;', '', 'dveg2004@mail.ru');
INSERT INTO `ri_user` VALUES (424, '2007-10-31', 'nadin@bendery.md', '07ног653ы', '', 'Надин', '', '', '34977', '', '', '', 'Бендеры', 0, 0, '', 0, '', '', '', '', '', 5, '', '', '', '', '', '', 'nadin@bendery.md');
INSERT INTO `ri_user` VALUES (425, '2007-10-31', 'medved2628@bk.ru', '05081961', '', 'оксана юрьевна', '', '', '(962)688-86-96', '8-962-688-86-96', '', '', 'Санкт-Петербург', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'medved2628@bk.ru');
INSERT INTO `ri_user` VALUES (426, '2007-11-02', 'n-15b@yandex.ru', '654321', '', 'Nastia', '', '', '', '', '', '', 'Novosibirsk', 0, 0, '300474103', 2178, '', '', '', '', '', 10, '', '', '', '', '', '', 'n-15b@yandex.ru');
INSERT INTO `ri_user` VALUES (427, '2007-11-06', 'ppapp2006@rambler.ru', '262084', '', '', '', '', '', '', '', '', 'Астрахань', 0, 0, '303668995', 2750, '', '', '', '41001177909893', '', 7, '', '', '', '', '', '', 'ppapp2006@rambler.ru');
INSERT INTO `ri_user` VALUES (428, '2007-11-06', 'snkononova@mail.ru', '011204', '', 'СНК', '', '', '83466951326', '', '', '', 'Лангепас', 0, 0, '', 1977, '', '', '', '', '', 30, '', '', '', '', '', '', 'snkononova@mail.ru');
INSERT INTO `ri_user` VALUES (429, '2007-11-06', 'duhoss@mail.ru', 'rbckjdjlcr', '', 'BaiT', '', '', '()', '89188045835', '', '', 'Кисловодск', 0, 0, '', 1999, '', '', '', '', '', 0, '', '', '', '', '', '', 'duhoss@mail.ru');
INSERT INTO `ri_user` VALUES (430, '2007-11-06', 'marketolog-pr@mail.ru', 'samira', '', 'Шайхутдинова Оксана Юрьевна', '', '', '', '912 816 37 10', '', '', 'Сургут', 0, 0, '', 2573, '', '', '', '41001178110331', '', 50, '', '', '', '', '', '', 'marketolog-pr@mail.ru');
INSERT INTO `ri_user` VALUES (431, '2007-11-07', 'ho-chul@rambler.ru', 'Flarik', '', '', '', '', '', '', '', '', 'Казань', 0, 0, '', 2194, '863987578243', '311680112134', '311959103306', '', '', 10, '', '', 'bankreferatov.ru;bestru.ru;dsks.ru;', 'bankreferatov.ru;', 'monax.ru;student.km.ru;eduworld.ru;p6.ru;5ballov.ru;epoisk.ru ;allsoch.ru;bankreferatov.ru;referat.su;', '', 'ho-chul@rambler.ru');
INSERT INTO `ri_user` VALUES (432, '2007-11-09', 'diplomers@yandex.ru', 'natasha777', '', 'dipa', '', '', '', '5080227', '', '', 'Москва', 0, 0, '', 2038, '', '', '', '4100179383251', '', 1000, '', '', 'referat.ru;', 'referat.ru;', 'referat.ru;', '', 'diplomers@yandex.ru');
INSERT INTO `ri_user` VALUES (433, '2007-11-10', 'dmitrij.beloborodov@rambler.ru', '02041977', '', 'Диман', '', '', '', '', '', '', 'куйбышев', 0, 0, '', 2559, '', '', '', '', '', 60, 'http://beloborodov6622.narod.ru/', '', 'bankreferatof.ru;', 'bankreferatof.ru;', 'bankreferatof.ru;', '', 'dmitrij.beloborodov@rambler.ru');
INSERT INTO `ri_user` VALUES (434, '2007-11-13', 'stk90@yandex.ru', '24031977', '', 'stk90', '', '', '()', '89506452645', '', '', 'Нижний Тагил', 0, 0, '', 2168, '', '', '', '', '', 0, '', '', '', '', '', '', 'stk90@yandex.ru');
INSERT INTO `ri_user` VALUES (435, '2007-11-21', 'antips@mail.ru', '711313', '', 'Антип', '', '', '(0536)711313', '097 32 80 678', '', '', 'Кременчуг', 0, 0, '', 2073, '', '', '', '', '', 0, '', '', '', '', '', '', 'antips@mail.ru');
INSERT INTO `ri_user` VALUES (436, '2007-11-22', 'genya1979@mail.ru', 'rjdifhbr', '', 'EvaRed', '', '', '(8352)334153', '89023274886', '', '89276664887', 'Чебоксары', 0, 0, '496662953', 2035, '', '', '', '', '', 500, 'www.diplommag.ru', '', 'www.bankreferatov.ru;', 'www.bankreferatov.ru;', 'www.bankreferatov.ru;', '', 'genya1979@mail.ru');
INSERT INTO `ri_user` VALUES (437, '2007-11-26', 'Goosha-5@bk.ru', '05081961', '', 'Goosha', '', '', '', '8-962-688-86-96', '', '', 'Санкт-Петербург', 0, 0, '', 2090, '', '', '', '41001146789822', '', 200, '', '', '', '', '', '', 'Goosha-5@bk.ru');
INSERT INTO `ri_user` VALUES (438, '2007-11-28', 'elena_slon@mail.ru', '89283486805', '', 'Slon', '', '', '(887922)63732', '89283486805', '', '', 'Минводы', 0, 0, '', 2079, '', '', '', '41001154941556', '', 0, '', '', '', '', '', '', 'elena_slon@mail.ru');
INSERT INTO `ri_user` VALUES (439, '2007-11-29', 'rusava@list.ru', 'rusava', '', '', '', '', '()', '80637457481', '', '', 'Донецк', 0, 0, '', 4401, 'R211668166661', 'Z328594377598', '', '41001184549245', '', 0, '', '', '', '', '', '', 'rusava@list.ru');
INSERT INTO `ri_user` VALUES (440, '2007-12-01', 'bound@inbox.ru', '171182', '', 'Рина', '', '', '', '89133904098', '', '', 'Новосибирск', 0, 0, '', 2090, '', '', '', '', '', 200, '', '', '', '', '', '', 'bound@inbox.ru');
INSERT INTO `ri_user` VALUES (441, '2007-12-02', 'viktorovanna@yandex.ru', '31032007', '', 'Lulu1602', '', '', '', '89516981477', '', '', 'Смоленск', 0, 0, '', 2148, '', '', '', '41001182381727', '', 10, '', '', 'vipreferat.ru;albest.ru;', 'sessia.ru;ronl.ru;', 'vipreferat.ru;sessia.ru;ref-gora.ru;albest.ru;ronl.ru;', '', 'viktorovanna@yandex.ru');
INSERT INTO `ri_user` VALUES (442, '2007-12-03', 'y555y2007@yandex.ru', '14rbhbkk', '', 'Зинченко Юлия', '', '', '', '+79624127820', '', '', 'Ставрополь', 0, 0, '', 2092, '', '', '', '41001181901197', '', 400, '', '', 'referat.ru;allbest.ru;', 'referat.ru;allbest.ru;', 'referat.ru;allbest.ru;bankreferatov.ru;', '', 'y555y2007@yandex.ru');
INSERT INTO `ri_user` VALUES (443, '2007-12-04', 'www.voyaka@e-izhevsk.ru', 'qd08jszk', '', '', '', '', '', '89090552626', '', '', 'ижевск', 0, 0, '376142417', 2098, '', '', '', '', '', 2, '', '', '', '', '', '', 'www.voyaka@e-izhevsk.ru');
INSERT INTO `ri_user` VALUES (444, '2007-12-04', 'SSkryleva@yandex.ru', '19031980', '', '', '', '', '', '+79034008787', '', '', 'Ростов-на-Дону', 0, 0, '', 2279, '', '', '', '41001182853975', '', 11, '', '', 'student.km.ru;studzone.dp.ua;', 'referats.sbn.bz;bankreferatov.ru;studzone.dp.ua;student.km.ru;zakazdiplom.ru;bestreferat.ru;', 'student.km.ru;bankreferatov.ru;zakazdiplom.ru;studzone.dp.ua;bestreferat.ru;', '', 'SSkryleva@yandex.ru');
INSERT INTO `ri_user` VALUES (445, '2007-12-05', 'Eurosquare@rambler.ru', 'hjlbyfhjccbz', 'Редгрин', '', '', '', '()', '89101220770', '', '', 'Москва', 0, 0, '', 4426, '', '', '', '41001184745496', '', 0, '', '', '', '', '', '', 'Eurosquare@rambler.ru');
INSERT INTO `ri_user` VALUES (446, '2007-12-08', 'RSavelui@gmail.com', 'КЫфмудгш9', '', 'RSavelui', '', '', '', '', '', '', 'Москва', 0, 0, '374019953', 2119, '', '', '', '41001186790469', '', 70, '', '', 'superdiplom.ru;', 'superdiplom.ru;', 'superdiplom.ru;', '', 'RSavelui@gmail.com');
INSERT INTO `ri_user` VALUES (447, '2007-12-09', 'gash2007@mail.ru', 'diehard', '', 'Kanna', '', '', '(8362)579346', '89276807872', '', '', 'Йошкар-Ола', 0, 0, '34522874', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'gash2007@mail.ru');
INSERT INTO `ri_user` VALUES (448, '2007-12-10', 'perevod4ik-profi@rambler.ru', 'яимир', '', 'Маргарита', '', '', '()', '89211632267', '', '', 'Апатиты', 0, 0, '', 2376, '', '', '', '', '', 0, '', '', '', '', '', '', 'perevod4ik-profi@rambler.ru');
INSERT INTO `ri_user` VALUES (449, '2007-12-11', 'nadenka@hitv.ru', '05101986', '', 'Nadya', '', '', '()', '89503203952', '', '', 'Казань', 0, 0, '330214157', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'nadenka@hitv.ru');
INSERT INTO `ri_user` VALUES (450, '2007-12-11', 'mariella@mail.ru', '7307880', '', 'Mariella', '', '', '()', '8-926-560-49-00', '', '', 'Воскресенск, моск.обл.', 0, 0, '220-933-291', 2308, '', '', '', '41001122336974', '', 0, '', '', '', '', '', '', 'mariella@mail.ru');
INSERT INTO `ri_user` VALUES (451, '2007-12-12', 'mary8021@rambler.ru', 'qweqaz', '', 'mary', '', '', '()', '89047714042', '', '', 'Фролово', 0, 0, '', 4428, '', '', '', '', '', 0, '', '', '', '', '', '', 'mary8021@rambler.ru');
INSERT INTO `ri_user` VALUES (452, '2007-12-13', 'serega-r1@narod.ru', '160790', '', 'Seregatlt', '', '', '', '', '', '', 'Тольятти', 0, 0, '453801220', 2207, '253861655268', '731303907009', '', '', '', 5, '', '', '', '', '', '', 'serega-r1@narod.ru');
INSERT INTO `ri_user` VALUES (453, '2007-12-17', 'xe4@rambler.ru', '221324', '', 'Хечумов Александр', '', '', '', '89261662064', '', '', 'Зеленоград', 0, 0, '291075882', 2172, '', '', '', '41001189622803', '', 1, '', '', '', '', '', '', 'xe4@rambler.ru');
INSERT INTO `ri_user` VALUES (454, '2007-12-22', 'gabarit@rambler.ru', '6128607', '', '', '', '', '', '9159649242', '', '9057943892', 'Москва', 0, 0, '394610593', 2528, '', '', '', '41001191955004', '', 50, '', 'год', 'referats-economy.ru;referats-medicine.ru;', '', '', '', 'gabarit@rambler.ru');
INSERT INTO `ri_user` VALUES (455, '2007-12-23', 'elena_shiryaeva@list.ru', 'gfynthf', '', 'Ширяева Елена Владим', '', '', '()', ' 7 904 55 222 90', '', '', 'Санкт-Петербург', 0, 0, '', 2190, '', '', '', '', '', 0, '', '', '', '', '', '', 'elena_shiryaeva@list.ru');
INSERT INTO `ri_user` VALUES (456, '2007-12-24', 'malk2007@inbox.ru', 'melvion', '', 'Andrey', '', '', '()', '89055706377', '', '', 'Кимры', 0, 0, '', 2199, '', '', '', '', '', 0, '', '', '', '', '', '', 'malk2007@inbox.ru');
INSERT INTO `ri_user` VALUES (457, '2007-12-29', 'kuny@inbox.ru', 'gfhjkm', '', 'Куницына О.И.', '', '', '(8482)337013', '89171224370', '', '', 'Тольятти', 0, 0, '431923270', 4169, '', '', '', '1001192371030', '', 10, '', '', '', '', '', '', 'kuny@inbox.ru');
INSERT INTO `ri_user` VALUES (458, '2008-01-03', 'marusia_83@mail.ru', '3489670', '', 'marusia_83@mail.ru', '', '', '()', '8-916-967-13-30', '', '', 'Москва', 0, 0, '', 2291, '', '', '', '', '', 0, '', '', '', '', '', '', 'marusia_83@mail.ru');
INSERT INTO `ri_user` VALUES (459, '2008-01-07', 'melkiy.inc@mail.ru', '331945', '', 'dark_messiah', '', '', '', '', '', '', 'Луганск', 0, 0, '410153400', 0, '', '', '', '', '', 1, '', '30', 'intway.com;', '', '', '', 'melkiy.inc@mail.ru');
INSERT INTO `ri_user` VALUES (460, '2008-01-14', 'talia9@mail.ru', '07122003', '', 'TALIA', '', '', '()', ' 79173378112', '', '', 'Волжский', 0, 0, '448791607', 2281, '', '', '', '', '', 0, '', '', '', '', '', '', 'talia9@mail.ru');
INSERT INTO `ri_user` VALUES (461, '2008-01-15', 'lar2617@yandex.ru', '10111982', '', 'lar2617', '', '', '()', '89622847270', '', '', 'г. Благовещенск', 0, 0, '465519771', 2741, '', '', '', '41001189849993', '', 0, '', '', '', '', '', '', 'lar2617@yandex.ru');
INSERT INTO `ri_user` VALUES (462, '2008-01-15', 'ppjln@yandex.ru', '83Ln77', '', '', '', '', '()', '89633376805', '', '', 'Санкт-Петербург', 0, 0, '', 4371, '', '', '', '41001169337766', '', 25, '', '', '', '', '', '', 'ppjln@yandex.ru');
INSERT INTO `ri_user` VALUES (463, '2008-01-15', 'FENIX-1003@yandex.ru', '970585bQ', '', '', '', '', '', '8-927-139-31-79', '', '', 'Саратов', 0, 0, '', 2298, '', '', '', '41001197176438', '', 300, '', '2-3 месяца', '', '', '', '', 'FENIX-1003@yandex.ru');
INSERT INTO `ri_user` VALUES (464, '2008-01-21', 'myha007@mail.ru', '007007', '', 'myha', '', '', '', '89275768454', '', '', 'Астрахань', 0, 0, '', 2350, 'R744751007857', '', '', '41001198082849', '', 0, '', '', '', '', '', '', 'myha007@mail.ru');
INSERT INTO `ri_user` VALUES (465, '2008-01-23', 'Alenka_aev@mail.ru', 'made22', '', 'Sivirina', '', '', '()', ' 7(921)654 34 64', '', '', 'Санкт-Петербург', 0, 0, '222452589', 2273, '', '', '', '', '', 0, '', '', '', '', '', '', 'Alenka_aev@mail.ru');
INSERT INTO `ri_user` VALUES (466, '2008-01-27', 'www.shnyrok20071@rambler.ru', '666666', '', 'shnyrok20071', '', '', '', '', '', '', 'Самара', 0, 0, '', 0, '', '', '', '41001179398723', '', 2, '', '', '', '', '', '', 'www.shnyrok20071@rambler.ru');
INSERT INTO `ri_user` VALUES (467, '2008-01-27', 'shnyrok20071@rambler.ru', '666666', '', 'shnyrok20081', '', '', '', '', '', '', 'Самара', 0, 0, '', 2282, '', '', '', '41001179398723', '', 2, '', '', '', '', '', '', 'shnyrok20071@rambler.ru');
INSERT INTO `ri_user` VALUES (468, '2008-01-31', 'Golydkova@yandex.ru', '03071978', '', '', '', '', '(347)2577279', '89177767521', '', '', 'Уфа', 0, 0, '', 4339, '089465795964', '', '', '41001177917427', '', 150, '', '', '', '', '', '', 'Golydkova@yandex.ru');
INSERT INTO `ri_user` VALUES (469, '2008-01-31', 'markinawork@yandex.ru', 'kelpie', '', 'zhanna', '', '', '', '903-621-73-37', '', '', 'Москва', 0, 0, '443617849', 0, '', '', '', '41001184381444', '', 10, '', '', '', '', '', '', 'markinawork@yandex.ru');
INSERT INTO `ri_user` VALUES (470, '2008-02-03', 'LenaVetrova2006@rambler.ru', '28061967', '', '', '', '', '(812)4699080', '89214322961', '', '89214322961', 'Санкт-Петербург', 0, 0, '', 2309, '', '', '', '', '', 0, '', '', '', '', '', '', 'LenaVetrova2006@rambler.ru');
INSERT INTO `ri_user` VALUES (471, '2008-02-03', 'ntrachuk@rambler.ru', '123456789', '', 'ntrachuk', '', '', '( 373)555 3-37-18', '', '', '', 'г. Рыбница Молдова', 0, 0, '282013682', 2851, '', '', '', '', '', 0, '', '', '', '', '', '', 'ntrachuk@rambler.ru');
INSERT INTO `ri_user` VALUES (472, '2008-02-07', 'Loki2603@yandex.ru', '5263125', '', 'Loki', '', '', '()', ' 79602730912', '', '', 'Санкт-Петербург', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'Loki2603@yandex.ru');
INSERT INTO `ri_user` VALUES (473, '2008-02-09', 'rintra@rambler.ru', 'rin12519tra', '', 'rintra', '', '', '()', '89604798789', '', '', 'Краснодар', 0, 0, '296-580-395', 2331, '', '', '', '', '', 0, '', '', '', '', '', '', 'rintra@rambler.ru');
INSERT INTO `ri_user` VALUES (474, '2008-02-12', 'rus-landia@mail.ru', 'olgashka', '', '', '', '', '(3952)нет', '89246041612', '', '', 'Иркутск', 0, 0, '', 2331, 'R318811700859', '', '', '41001164744567', 'Наименование Банка получателя: ВТБ 24 (ЗАО) \r\nБИК Банка получателя: 044525716 \r\nК/С Банка получателя: 30101810100000000716 \r\nПолучатель: Загуменова Ольга Ивановна, л/с 40817810927001010096 в Системе \r\nТелебанк \r\nСчет получателя в банке получателя: 47422810800000000677 ', 0, '', '', '', '', '', '', 'rus-landia@mail.ru');
INSERT INTO `ri_user` VALUES (475, '2008-02-15', 'lev4enkoirina@yandex.ru', 'levira1984', '', 'Irianna', '', '', '', '', '', '', 'Киев', 0, 0, '', 2477, '369982926343', '297699241279', '', '', '', 25, '', '', 'stydenty.info;prepadav.net;', '', '', '', 'lev4enkoirina@yandex.ru');
INSERT INTO `ri_user` VALUES (476, '2008-02-21', 'ares111@yandex.ru', '637231', '', 'ares111', '', '', '()', '89206380497', '', '', 'Рязань', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'ares111@yandex.ru');
INSERT INTO `ri_user` VALUES (477, '2008-02-24', 'art3501@ya.ru', 'artem79', '', '', '', '', '', '', '', '', 'Санкт-Питербург', 0, 0, '', 4470, '', '', '', '41001215605698', '', 70, '', '', '', '', '', '', 'art3501@ya.ru');
INSERT INTO `ri_user` VALUES (478, '2008-02-27', 'hoohoohoo@ya.ru', 'htathfns', '', 'hoohoohoo', '', '', '', '', '', '', 'Саранск', 0, 0, '', 2887, '', '', '', '', '', 1, '', '', 'referats.ru;', '', '', '', 'hoohoohoo@ya.ru');
INSERT INTO `ri_user` VALUES (479, '2008-03-01', 'eskamaeva@ya.ru', '1q2w3e4r', '', 'ЕленаСергеевна', '', '', '', '8-902-807-93-72', '', '', 'Пермь', 0, 0, '370743800', 2410, '', '', '', '41001209316423', '', 100, '', '', '5ballov.ru;allbest.ru;', 'bankreferatov.ru;', 'bankreferatov.ru;bestreferat.ru;5ballov.ru;allbest.ru;', '', 'eskamaeva@ya.ru');
INSERT INTO `ri_user` VALUES (480, '2008-03-02', 'natol198@mail.ru', 'xthyjdf', '', '', '', '', '413122', '89039103566', '', '', 'Барнаул', 0, 0, '', 2861, '', '', '', 'nat31369034', '', 2000, '', '', '', '', '', '', 'natol198@mail.ru');
INSERT INTO `ri_user` VALUES (481, '2008-03-04', 'ri-z-ik@mail.ru', 'yfnfcz', '', 'Rizik', '', '', '()', '89132516062', '', '', 'Барнаул', 0, 0, '365015581', 2390, '', '', '', '41001206203927', '', 0, '', '', '', '', '', '', 'ri-z-ik@mail.ru');
INSERT INTO `ri_user` VALUES (482, '2008-03-05', 'lukyanov-2003@mail.ru', '842248', '', 'Alexander', '', '', '(8634)620750', '79044443958', '', '', 'Таганрог', 0, 0, '', 2409, '', '', '', '', '', 0, '', '', '', '', '', '', 'lukyanov-2003@mail.ru');
INSERT INTO `ri_user` VALUES (483, '2008-03-06', 'lotos21581@mail.ru', 'cft6yh', '', 'lotos21581', '', '', '()', ' 79622947992', '', '', 'г.Благовещенск', 0, 0, '380814021', 2390, '', '', '', '', '', 0, '', '', '', '', '', '', 'lotos21581@mail.ru');
INSERT INTO `ri_user` VALUES (484, '2008-03-06', 'marym@kmtn.ru', '291084', '', 'marym', '', '', '(4942)421740', '8-920-380-10-87', '', '', 'Кострома', 0, 0, '', 2390, '', '', '', '', '', 0, '', '', '', '', '', '', 'marym@kmtn.ru');
INSERT INTO `ri_user` VALUES (485, '2008-03-07', 'sto.ru@bk.ru', '1979', '', 'Руслан Николаевич', '', '', '()', ' 7 910 641 80 26', '', '', 'Красноярск', 0, 0, '448812166', 2729, '', '', '', '', '', 0, '', '', '', '', '', '', 'sto.ru@bk.ru');
INSERT INTO `ri_user` VALUES (486, '2008-03-13', 'ilchenko_k79@mail.ru', 'cat2000', '', '', '', '', '(8352)621930', '89176539610', '', '', 'ЧР, г. Чебоксары', 0, 0, '163039305', 4149, '', '', '', '41001216767718', '', 0, '', '', '', '', '', '', 'ilchenko_k79@mail.ru');
INSERT INTO `ri_user` VALUES (487, '2008-03-14', 'i_tan@mail.ru', '1q2q3q', '', 'tatia79', '', '', '()', '9207443247', '', '', 'Тула', 0, 0, '468164878', 2502, '394879094631', 'Z100564002111', '', '', '', 0, '', '', '', '', '', '', 'i_tan@mail.ru');
INSERT INTO `ri_user` VALUES (488, '2008-03-14', 'mn_market@mail.ru', '300177', '', '', '', '', '()', '89642620475', '', '89501344539', 'Красноярск', 0, 0, '331-032-545', 4468, '', '', '', '', '', 50, '', '', '', '', '', '', 'mn_market@mail.ru');
INSERT INTO `ri_user` VALUES (489, '2008-03-16', 'idaberc@yandex.ru', 'idasalve', '', 'Ida', '', '', '(371)2566353', '3225663', '', '', 'Ташкент', 0, 0, '', 2433, '', '', '', '', '', 0, '', '', '', '', '', '', 'idaberc@yandex.ru');
INSERT INTO `ri_user` VALUES (490, '2008-03-17', 'matriza@inbox.ru', 'dfl.if', '', 'matriza', '', '', '()', '8-922-236-22-33', '', '', 'Златоуст', 0, 0, '370994671', 2645, '', '', '', '', '', 0, '', '', '', '', '', '', 'matriza@inbox.ru');
INSERT INTO `ri_user` VALUES (491, '2008-03-21', 'lenochka.76@list.ru', '1101972', '', 'mouse72', '', '', '8(3953) 438856', '', '', '8(3953) 438856', 'Братск', 0, 0, '', 2449, '', '', '', '', '', 1, '', '', '', '', '', '', 'lenochka.76@list.ru');
INSERT INTO `ri_user` VALUES (492, '2008-03-22', 'ann-ua@yandex.ru', 'fhfrtkzy', '', 'ann-ua', '', '', '()', ' 79184683994', '', '', 'Краснодар', 0, 0, '3530048', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'ann-ua@yandex.ru');
INSERT INTO `ri_user` VALUES (493, '2008-03-26', 'max-programma@yandex.ru', '21092003', '', '', '', '', '()', ' 375298079826', '', '', 'Брест, Беларусь', 0, 0, '423889336', 2469, '', '', '', '41001221442327', '', 0, '', '', '', '', '', '', 'max-programma@yandex.ru');
INSERT INTO `ri_user` VALUES (494, '2008-04-04', 'chelseazam@inbox.ru', 'steroid', '', 'Арслан', '', '', '83477539900', '89272329898', '', '', 'Сибай', 0, 0, '', 2535, '', '', '', '', '', 5, '', '', '', '', '', '', 'chelseazam@inbox.ru');
INSERT INTO `ri_user` VALUES (495, '2008-04-05', 'tumanink@yandex.ru', '629083', '', '', '', '', '()', '8 924 850 84 38', '', '', 'Магадан', 0, 0, '', 2885, '', '', '', '41001224600812', '', 0, '', '', '', '', '', '', 'tumanink@yandex.ru');
INSERT INTO `ri_user` VALUES (496, '2008-04-09', 'dalai-lama_67@mail.ru', '608217', '', 'dalailama', '', '', '()', '7 985 1614667', '', '', 'Москва', 0, 0, '4421819', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'dalai-lama_67@mail.ru');
INSERT INTO `ri_user` VALUES (497, '2008-04-13', 'Roxya2003@mail.ru', '1819', '', '', '', '', '()', '89080811166', '', '', 'Челябинск', 0, 0, '450-728-997', 4206, '', '', '', '41001184515461', 'Челябинск, Калининское отделение сберегательного банка  8544. Получатель: ИНН 7707083893\r\nКалининское ОСБ  8544/0231 Уральского Банка СБ РФ\r\nБИК 047501602\r\nКПП 744702001\r\nБанк получателя: Челябинское ОСБ 8597 г.Челябинск к/сч 30101810700000000602\r\nДля зачисления на сб/кн (как у меня) счет 47422810272199940001\r\nвклад Универсальный\r\nсчет: 42307.810.0.7219.3225411\r\nФИО: Луцкина Анастасия Вениаминовна\r\n', 0, '', '', '', '', '', '', 'Roxya2003@mail.ru');
INSERT INTO `ri_user` VALUES (498, '2008-04-16', 'tsafi@ya.ru', '13102000', '', 'Anuta', '', '', '()', '79055638610', '', '', 'Коломна', 0, 0, '452828612', 2568, '', '', '', '', '', 0, '', '', '', '', '', '', 'tsafi@ya.ru');
INSERT INTO `ri_user` VALUES (499, '2008-04-18', 'larisagrnik@rambler.ru', '20111977', '', 'Алиса', '', '', '', '', '8-836-41-2-31-6', '', 'Марий Эл п.Оршанка', 0, 0, '', 2573, '', '', '', '', '', 15, '', '', '', '', '', '', 'larisagrnik@rambler.ru');
INSERT INTO `ri_user` VALUES (500, '2008-04-20', 'pskov_pechat@mail.ru', '336170', '', 'GrEeNn', '', '', '', '89045190117', '', '', 'Выборг', 0, 0, '479209700', 2752, '', '', '', '4100161270859', '', 20, '', 'год', '', '', '', '', 'pskov_pechat@mail.ru');
INSERT INTO `ri_user` VALUES (501, '2008-04-21', 'nelenser@mail.ru', 'прототип', '', 'Nelenser', '', '', '', '89135707383', '', '', 'Красноярск', 0, 0, '', 2586, '', '', '', '', '', 10, '', '', '', '', '', '', 'nelenser@mail.ru');
INSERT INTO `ri_user` VALUES (502, '2008-04-27', 'din_din_86@mail.ru', 'galadrial', '', 'Дина', '', '', '()', '89501201497', '', '', 'Иркутск', 0, 0, '', 2612, '', '', '', '', '', 0, '', '', '', '', '', '', 'din_din_86@mail.ru');
INSERT INTO `ri_user` VALUES (503, '2008-04-29', 'veko79@trunkcom.ru', '23042007', '', 'veko79', '', '', '(8512)493186', '', '', '', 'г.Астрахань', 0, 0, '', 2625, '', '', '', '', '', 0, '', '', '', '', '', '', 'veko79@trunkcom.ru');
INSERT INTO `ri_user` VALUES (504, '2008-05-04', 'alfy@tula.net', '546975', '', 'Skela', '', '', '()', '89207416840', '', '', 'Тула', 0, 0, '', 4168, '206675127633', '', '', '', '', 0, '', '', '', '', '', '', 'alfy@tula.net');
INSERT INTO `ri_user` VALUES (505, '2008-05-10', 'Julie-Pch@yandex.ru', 'marsel', '', 'жюли', '', '', '8-863-276-33-88', '8-906-183-73-19', '', '', 'Ростов-на-Дону', 0, 0, '455875448', 2671, '', '', '', '', '', 10, '', '', '', 'vkontakte.ru;', '5баллов.ru;', '', 'Julie-Pch@yandex.ru');
INSERT INTO `ri_user` VALUES (506, '2008-05-11', 'Slaytan@rambler.ru', '020187', '', 'Slaytan', '', '', '', '89095542454', '', '', 'Архангельск', 0, 0, '', 0, '', '', '', '', '', 1, '', '', '', '', '', '', 'Slaytan@rambler.ru');
INSERT INTO `ri_user` VALUES (507, '2008-05-11', 'vale4ka8905@yandex.ru', '112005', '', 'Валентинка', '', '', '389092', '89051132216', '', '', 'Тула', 0, 0, '', 4254, '', '', '', '41001235178054', '', 7, '', '', '', '', '', '', 'vale4ka8905@yandex.ru');
INSERT INTO `ri_user` VALUES (508, '2008-05-17', 'turistu@inbox.ru', '7926hkjsg', '', 'turistu', '', '', '', '', '', '', 'Томск', 0, 0, '', 2708, '', '', '', '41001123352578', '', 30, '', '', 'http://weblancer.net;http://free-lance.ru;http://www.educationservice.ru/;', 'http://www.bankreferatov.ru;http://weblancer.net;http://free-lance.ru;http://www.educationservice.ru/;', 'http://www.bankreferatov.ru;http://5ballow.ru;www.referat.su;', '', 'turistu@inbox.ru');
INSERT INTO `ri_user` VALUES (509, '2008-05-20', 'juliaexpert@rambler.ru', 'djkuf123', '', 'Юлия1985', '', '', '()', '89176647488', '', '', 'Самара', 0, 0, '499443219', 4193, '', '', '', '', '', 0, '', '', '', '', '', '', 'juliaexpert@rambler.ru');
INSERT INTO `ri_user` VALUES (510, '2008-05-20', 'Pantera_89@mail.ru', '2458924589', '', '', '', '', '', '89617557547', '', '', 'Пермь', 0, 0, '426805905', 3710, '143196525290', '341212724012', '', '', '', 15, '', '', '', '', '', '', 'Pantera_89@mail.ru');
INSERT INTO `ri_user` VALUES (511, '2008-05-20', 'Roma-zenit@yandex.ru', '21111987', '', 'Roman- zenit', '', '', '', '89113940408', '', '', 'Псков', 0, 0, '', 2756, '', '', '', '', '', 1, '', '', '', '', '', '', 'Roma-zenit@yandex.ru');
INSERT INTO `ri_user` VALUES (512, '2008-05-22', 'tolstechok@bk.ru', '123456789', '', 'Hook', '', '', '', '', '', '', 'Москва', 0, 0, '256214241', 2729, '', '', '', '', '', 3, '', '', 'mgpu.ru;', 'mgpu.ru;', 'kursoviki.spb.ru;', '', 'tolstechok@bk.ru');
INSERT INTO `ri_user` VALUES (513, '2008-05-22', 'yura88-pochta@rambler.ru', '1376150188', '', 'Scooter', '', '', '', '89226381355', '', '', 'Озёрск', 0, 0, '', 4116, '227856486365', '419495390639', '', '', '', 10, '', '', '', '', '', '', 'yura88-pochta@rambler.ru');
INSERT INTO `ri_user` VALUES (514, '2008-05-27', 'Kitkatt@yandex.ru', '385385', '', 'Kitkatt', '', '', '', '', '', '', 'Москва', 0, 0, '461032042', 4307, '', '415949148352', '', '', '', 10, '', '', '', '', '', '', 'Kitkatt@yandex.ru');
INSERT INTO `ri_user` VALUES (515, '2008-05-28', 'chistyyuliya@yndex.ru', 'mugulya', '', 'chistulya', '', '', '3012442419', '89148464441', '', '', 'Улан - Удэ', 0, 0, '479471022', 0, '409827651065', '409827651065', '409827651065', '', '', 5, '', '6 месяц', 'www.referat.ru;', 'www.referat.ru;', 'www.referat.ru;', '', 'chistyyuliya@yndex.ru');
INSERT INTO `ri_user` VALUES (516, '2008-05-28', 'makdim78@mail.ru', '1978', '', 'Харина Светлана Анатольевна', '', '', '(4217)277678', '8 924 226 0765', '', '8 914 186 0661', 'Комсомольск-на-Амуре', 0, 0, '415852110', 3710, '', '', '', '41001234766991', '', 300, '', '', '', '', '', '', 'makdim78@mail.ru');
INSERT INTO `ri_user` VALUES (517, '2008-05-31', 'antkache@ya.ru', '12345', '', 'Ткачева Анна', '', '', '', '', '', '', 'Киев', 0, 0, '428262215', 2866, '', '', '', '41001239972045', '', 100, '', '', 'referat.ru;ukrreferat.com;', 'allbest.ru;', '5ballov.ru;', '', 'antkache@ya.ru');
INSERT INTO `ri_user` VALUES (518, '2008-06-07', 'sivenok@mail.ru', '361811339253', '', 'Cbdtyjr', '', '', '', '', '', '', 'Кокшетау', 0, 0, '326239593', 4169, '698321945653', '310416579149', '261695183318', '41001199878339', '', 4, '', '', 'bankrabot.ru;', 'bakrabot.ru;', 'allbest.ru;', '', 'sivenok@mail.ru');
INSERT INTO `ri_user` VALUES (519, '2008-06-09', '7marta89@mail.ru', '7245427', '', '', '', '', '', '+375297941904', '', '', 'Брест', 0, 0, '487926160', 2875, '250907462328', '189612824390', '', '', '', 200, '', '', '', '', '', '', '7marta89@mail.ru');
INSERT INTO `ri_user` VALUES (520, '2008-06-12', 'nonalias@mail.ru', 'xfiles', '', 'Alias', '', '', '6726380', '', '89057403652', '', 'Москва', 0, 0, '348889987', 4348, '', '', '', '', '', 3, '', '', '', '', '', '', 'nonalias@mail.ru');
INSERT INTO `ri_user` VALUES (521, '2008-06-13', 'kapitalez@ya.ru', 'zimalex', '', 'AlexZimniy', '', '', '', '9053763103', '', '', 'Казань', 0, 0, '', 2841, '', '', '', '41001108185097', '', 50, '', 'месяц', '', '', '', '', 'kapitalez@ya.ru');
INSERT INTO `ri_user` VALUES (522, '2008-06-15', 'snoockey@mail.ru', '2534771', '', 'snoockey', '', '', '()', ' 375293236381', '', '', 'Минск', 0, 0, '397578621', 4200, '', '', '', '', '', 0, '', '', '', '', '', '', 'snoockey@mail.ru');
INSERT INTO `ri_user` VALUES (523, '2008-06-17', 'yarco84@yandex.ru', '9023218444', '', 'Яркий', '', '', '()', '89271010273', '', '', 'Энгельс', 0, 0, '436862752', 2885, '', '', '', '', '', 0, '', '', '', '', '', '', 'yarco84@yandex.ru');
INSERT INTO `ri_user` VALUES (524, '2008-06-20', 'galin-v@yandex.ru', '1952', '', 'galin-v', '', '', '()', '8 919 654 3718', '', '', 'Чебоксары', 0, 0, '', 2955, '', '', '', '', '', 0, '', '', '', '', '', '', 'galin-v@yandex.ru');
INSERT INTO `ri_user` VALUES (525, '2008-06-24', 'svklim84@mail.ru', '200184', '', 'Veta', '', '', '', '89270099440', '', '', 'Самара', 0, 0, '392595170', 0, '', '', '', '41001243829346', '', 1, '', '', 'diplomaster.ru;', 'diplomaster.ru;', 'diplomaster.ru;', '', 'svklim84@mail.ru');
INSERT INTO `ri_user` VALUES (526, '2008-06-27', 'diplomdim@mail.ru', '369852147', '', '', '', '', '', '', '', '', 'Сургут', 0, 0, '486130247', 2885, '193964686474', '', '', '41001240754166', '', 61, 'http://diplom2008.ucoz.ru', '', 'diplom-iq.ru;diplom-gotovie.ru;bankrabot.ru;referat.ru;', 'diplom-zakaz.ru;studshop.ru;', 'referatbank.ru;', '', 'diplomdim@mail.ru');
INSERT INTO `ri_user` VALUES (527, '2008-06-28', 'rrr_77@rambler.ru', 'renatik', '', 'Lora', '', '', '(88662)914173', '8928-968-69-48', '', '', 'Нальчик', 0, 0, '', 4345, '', '', '', '', '', 0, '', '', '', '', '', '', 'rrr_77@rambler.ru');
INSERT INTO `ri_user` VALUES (528, '2008-07-07', 'sds29@yandex.ru', '1977', '', '', '', '', '8(38445)3-58-11', '8-905-904-46-06', '3-26-64', '', 'Кемеровская обл., г.Березовский.', 0, 0, '', 4358, '', '', '', '', 'Самойленко Ольга Владимировна картсчет № 40817810805151065504Банк:КФ ОАО "УРСА Банк", ИНН 5408117935, БИК 043207784, к/с 30101810400000000784.\r\n', 50, '', '', '', '', '', '', 'sds29@yandex.ru');
INSERT INTO `ri_user` VALUES (529, '2008-07-10', 'lawlib@mail.ru', '7777777', '', 'lawlib', '', '', '()', ' 7-921-168-54-01', '', '', 'Мурманск', 0, 0, '', 3302, '', '', '', '', '', 0, '', '', '', '', '', '', 'lawlib@mail.ru');
INSERT INTO `ri_user` VALUES (530, '2008-07-11', 'n_ars@mail.ru', 'ars72', '', 'ARS', '', '', '()', '918 436 62 11', '', '', 'Новороссийск', 0, 0, '492294953', 3690, '', '', '', '4100183542897', '', 0, '', '', '', '', '', '', 'n_ars@mail.ru');
INSERT INTO `ri_user` VALUES (531, '2008-07-14', 'vladaley@ukr.net', '13081982', '', 'vladaely', '', '', '()', ' 380966094762', '', '', 'Хмельницкий', 0, 0, '218658881', 3596, 'R137458240689', 'Z784342949165', '', '', '', 0, '', '', '', '', '', '', 'vladaley@ukr.net');
INSERT INTO `ri_user` VALUES (532, '2008-07-15', 'busheneva@inbox.ru', '290907', '', 'Юлия Ивановна', '', '', '', '89119312050', '', '', 'Санкт-Петербург', 0, 0, '', 3752, '', '', '', '', '', 500, '', '', 'studline.ru;', 'studline.ru;', 'studentochka.ru;', '', 'busheneva@inbox.ru');
INSERT INTO `ri_user` VALUES (533, '2008-07-18', 'ivan_lion@mail.ru', 'figureskating', '', 'Lion', '', '', '', '89608486374', '', '', 'Тольятти', 0, 0, '356496511', 3686, '360916258329', '846515243468', '', '41001249902268', '', 10, '', '', '', '', '', '', 'ivan_lion@mail.ru');
INSERT INTO `ri_user` VALUES (534, '2008-07-30', 'succes69@mail.ru', '2322925', '', 'iness69', '', '', '()', ' 79132322925', '', '', 'Барнаул', 0, 0, '', 4362, '', '', '', '', '', 0, '', '', '', '', '', '', 'succes69@mail.ru');
INSERT INTO `ri_user` VALUES (535, '2008-08-06', 'diablo999@dom.raid.ru', 'fantomas777', '', '', '', '', '', '', '', '', 'Пермь', 0, 0, '', 3748, '', 'Z178773572610', '', '', '', 3, '', '', '', '', '', '', 'diablo999@dom.raid.ru');
INSERT INTO `ri_user` VALUES (536, '2008-08-06', 'skeleton84@mail.ru', '23662366', '', 'Оля', '', '', '()', '89315002777', '', '', 'Вологда', 0, 0, '', 4127, '', '', '', '', '', 0, '', '', '', '', '', '', 'skeleton84@mail.ru');
INSERT INTO `ri_user` VALUES (537, '2008-08-07', 'ollyvel@mail.ru', 'ksusha2303', '', '', '', '', '()', '9115004026', '', '', 'Вологда', 0, 0, '277-059-435', 4148, '', '', '', '', '', 0, '', '', '', '', '', '', 'ollyvel@mail.ru');
INSERT INTO `ri_user` VALUES (538, '2008-08-07', 'oksana-fomina@yandex.ru', '11031987', '', 'Оксаночка', '', '', '()', '8-927-161-76-13', '', '', 'Саратов', 0, 0, '', 3710, '', '', '', '', '', 0, '', '', '', '', '', '', 'oksana-fomina@yandex.ru');
INSERT INTO `ri_user` VALUES (539, '2008-08-09', 'Elavolkova@ya.ru', '333333', '', 'Elavolkova', '', '', '(812)731646', '911 114 02 42', '', '', 'СПб', 0, 0, '380494661', 3748, '', '', '', '41001218159392', '', 0, '', '', '', '', '', '', 'Elavolkova@ya.ru');
INSERT INTO `ri_user` VALUES (540, '2008-08-11', 'loko1976@yandex.ru', 'tloko', '', '', '', '', '', '89035829917', '', '', 'Московская область', 0, 0, '', 4371, '', '', '', '', '', 10, '', '', '', '', '', '', 'loko1976@yandex.ru');
INSERT INTO `ri_user` VALUES (541, '2008-08-17', 'Penitsillin@mail.ru', 'Fyfcnfcbz', '', 'Penitsillin', '', '', '', '+79098620706', '', '', 'Комсомольск на Амуре', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'Penitsillin@mail.ru');
INSERT INTO `ri_user` VALUES (542, '2008-08-20', 'balamut-n@yandex.ru', 'n357', '', 'Balamut', '', '', '()', '926 583 38 06', '', '', 'Москва', 0, 0, '354435645', 4234, 'R361279719979', 'Z353471193809', '', '41001252047823', '', 0, '', '', '', '', '', '', 'balamut-n@yandex.ru');
INSERT INTO `ri_user` VALUES (543, '2008-08-22', 'katerinka-0808@yandex.ru', 'zolotko', '', 'katerinka-0808', '', '', '()', '89087282465', '', '', 'Нижний Новгород', 0, 0, '', 4178, '', '', '', '', '', 0, '', '', '', '', '', '', 'katerinka-0808@yandex.ru');
INSERT INTO `ri_user` VALUES (544, '2008-08-24', 'lavrentyevs@rambler.ru', '20061985', '', 'lavrentyevs', '', '', '(8352)670884', '89196736812', '', '', 'Чебоксары', 0, 0, '274856618', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'lavrentyevs@rambler.ru');
INSERT INTO `ri_user` VALUES (545, '2008-08-27', 'alta_leta@mail.ru', 'kbb11b', '', 'Leta', '', '', '', '89503700151', '', '', 'Нижний Новгород', 0, 0, '', 4323, '', '', '', '', '', 5, '', '', '', '', '', '', 'alta_leta@mail.ru');
INSERT INTO `ri_user` VALUES (546, '2008-08-29', 'emad84@mail.ru', '161616', '', '', '', '', '()', '89206055206', '', '', 'Белгород', 0, 0, '', 3752, 'R182869069923', 'Z286556941214', '', '41001262835959', '', 0, '', '', '', '', '', '', 'emad84@mail.ru');
INSERT INTO `ri_user` VALUES (547, '2008-09-02', 'sega747@mail.ru', '89113585747', '', 'Falgot', '', '', '', '', '', '+79602268656', 'Псков', 0, 0, '329677705', 3777, '285512247349', '339339472383', '', '4100139135676', '', 15, '', '', '', '', '', '', 'sega747@mail.ru');
INSERT INTO `ri_user` VALUES (548, '2008-09-03', 'dr_anjell@yahoo.com', 'vodkapivo', '', 'Anjell', '', '', '', '8 (915)489-89-31', '', '', 'Москва', 0, 0, '333736338', 3929, '', '', '', '', '', 300, '', '', '', '', '', '', 'dr_anjell@yahoo.com');
INSERT INTO `ri_user` VALUES (549, '2008-09-05', 'bagirailn@mail.ru', '4444', '', 'Алексанкова Ольга', '', '', '8-86144-3-14-78', '8-928-426-78-98', '', '', 'ст. Отрадная', 0, 0, '', 4060, '', '', '', '', '', 1, '', '', 'referat.su ;', 'poluchi5.ru;', '', '', 'bagirailn@mail.ru');
INSERT INTO `ri_user` VALUES (550, '2008-09-07', 'sergeyitaly@yahoo.com', 'myzhitomir', '', 'sergeyitaly', '', '', '', '380671648843', '', '', 'Житомир', 0, 0, '', 3791, '', '', '', '', '', 20, '', '', 'www.refineua.com.ru;', '', '', '', 'sergeyitaly@yahoo.com');
INSERT INTO `ri_user` VALUES (551, '2008-09-08', 'Lubasha84@bk.ru', 'lbgkjvyfz', '', 'Сафина Любовь', '', '', '', '79062781583', '', 'факс (812)342-1', 'Санкт-Петербург', 0, 0, '440773518', 3793, '', '', '', '41001215812370', '', 5, '', '', '', '', '', '', 'Lubasha84@bk.ru');
INSERT INTO `ri_user` VALUES (552, '2008-09-09', 'rok732@mail.ru', 'rok732473', '', 'rok732', '', '', '', '8-960-600-77-20', '', '', 'Тула', 0, 0, '', 3858, '', '', '', '41001229836345', '', 10, '', '3 месяца', 'www.moyareklama.ru;', 'diplomer.net;diplomka.ru;', 'kursoviki.spb.ru;www.stydenty.ru;', '', 'rok732@mail.ru');
INSERT INTO `ri_user` VALUES (553, '2008-09-10', 'Pakhotinskaya@mail.ru', '311984', '', '', '', '', '', '+79231552510', '', '', 'Новосибирск', 0, 0, '495072015', 3842, '', '', '', '41001267523340', '', 300, '', '', '', '', '', '', 'Pakhotinskaya@mail.ru');
INSERT INTO `ri_user` VALUES (554, '2008-09-14', 'dadlasdj2ds@mail.ru', '1flvby', '', 'hell', '', '', '', '', '', '', 'Piter', 0, 0, '', 3899, '', '', '', '', '', 40, '', 'год', '', '', '', '', 'dadlasdj2ds@mail.ru');
INSERT INTO `ri_user` VALUES (555, '2008-09-15', 'diadia@pnz.ru', 'diadia', '', '', '', '', '', '', '', '', 'Лондон)', 0, 0, '463115489', 4307, '', '', '', '', '', 30, '', '', '', '', '', '', 'diadia@pnz.ru');
INSERT INTO `ri_user` VALUES (605, '2009-01-12', 'Vitrina_s@rambler.ru', '080980', '', '', '', '', '(3532) 99-85-02', '89033668926', '', '', 'Оренбург', 0, 0, '414604914', 4342, '', '', '', '', '', 11, '', '', '', '', '', '', 'Vitrina_s@rambler.ru');
INSERT INTO `ri_user` VALUES (556, '2008-09-17', 'diplomzakaz@rambler.ru', 'fyyf27', '', 'Анна Казадаева', '', '', '', '+7 913 015 19 58', '', '', 'Новосибирск', 0, 0, '357908379', 3933, '', '', '', '41001142952172', '', 2000, 'http://www.diplom-1000.ru', '', '', '', '', '', 'diplomzakaz@rambler.ru');
INSERT INTO `ri_user` VALUES (557, '2008-10-01', 'lhfrekf@ya.ru', '221983', '', 'axara', '', '', '()', '89033499472', '', '', 'Астрахань', 0, 0, '394070248', 4109, '', '', '', '', '', 0, '', '', '', '', '', '', 'lhfrekf@ya.ru');
INSERT INTO `ri_user` VALUES (558, '2008-10-02', 'regpsl@mail.ru', 'qwert', '', 'regina-sl', '', '', '(342) 244-30-09', '8-908-27-18-833', '(342) 244-30-28', '', 'Пермь', 0, 0, '', 0, '', '', '', '41001234014007', '', 300, '', '', '', '', '', '', 'regpsl@mail.ru');
INSERT INTO `ri_user` VALUES (559, '2008-10-02', 'mantissa-r@mail.ru', 'qwerty', '', '', '', '', '', '8-908-27-18-833', '(342) 244-30-09', '', 'Пермь', 0, 0, '442123020', 4262, '', '', '', '41001234014007', 'старый емэйл: regina_sl@mail.ru', 500, '', '', '', '', '', '', 'mantissa-r@mail.ru');
INSERT INTO `ri_user` VALUES (560, '2008-10-03', 'B.M.X.Q@mail.ru', '19791979', '', 'Шмакова Юлия', '', '', '', '8-922-508-39-55', '', '', 'Пермь', 0, 0, '378535799', 4116, '', '', '', '41001265462587', '', 300, '', '', '', '', '', '', 'B.M.X.Q@mail.ru');
INSERT INTO `ri_user` VALUES (561, '2008-10-03', 'nkra7@mail.ru', '201276', '', 'nkra', '', '', '()', '921 497 96 85', '', '', 'Архангельск', 0, 0, '245856024', 4098, '', '', '', '4100149687861', '', 0, '', '', '', '', '', '', 'nkra7@mail.ru');
INSERT INTO `ri_user` VALUES (562, '2008-10-03', 'saratov-diplom@YA.RU', '543606', '', 'Елена Владимировна', '', '', '(8452)543-606', '8-960-359-29-37', '', '', 'Саратов', 0, 0, '390889480', 4134, '', '', '', '41001158937963', '', 3000, 'http://saratov-diplom.narod.ru', '', 'sarbc.ru;superjob.ru;hh.ru ;rabota.ru ;job.ru ;zarplata.ru ;joblist.ru ;vacansia.ru;mostrud.ru ;', 'sarbc.ru;superjob.ru;hh.ru ;rabota.ru ;job.ru ;zarplata.ru ;joblist.ru ;vacansia.ru;mostrud.ru ;rjb.ru ;', 'allbest.ru ;referat.ru ;bankreferatov.ru ;chertezh.narod.ru ;corbina.ru ;cityref.ru ;studentochka.ru ;bestreferat.ru ;doklad.ru ;referatbank.ru ;referatik.ru ;epoisk.ru ;', '', 'saratov-diplom@YA.RU');
INSERT INTO `ri_user` VALUES (563, '2008-10-05', 'brain04@pochta.ru', 'referats08', '', '', '', '', '', '89102408119', '', '', 'Белгородская обл.', 0, 0, '351692073', 4286, '308648222675', '440397318669', '', '41001236845563', '', 80, '', '', '', '', '', '', 'brain04@pochta.ru');
INSERT INTO `ri_user` VALUES (564, '2008-10-05', 'sonata1987@yandex.ru', 'yfnfif397803', '', 'SoNata', '', '', '', '', '', '', 'Тула', 0, 0, '', 0, '', '', '', '', '', 15, '', '', '', '', '', '', 'sonata1987@yandex.ru');
INSERT INTO `ri_user` VALUES (565, '2008-10-07', 'mantissa-ukc@mail.ru', 'qwert', '', 'Regina', '', '', '', '8-908-27-18-833', '(342)244-30-09', '442123020', 'Пермь', 0, 0, '', 4109, '', '', '', '41001234014007', '', 1000, '', '', '', '', '', '', 'mantissa-ukc@mail.ru');
INSERT INTO `ri_user` VALUES (566, '2008-10-09', 'StolicaZnaniy@yandex.ru', '19520212', '', 'StolicaZnaniy', '', '', '()', ' 7-913-873-30-32', '', '', 'Томск', 0, 0, '', 4125, '', '', '', '', '', 0, '', '', '', '', '', '', 'StolicaZnaniy@yandex.ru');
INSERT INTO `ri_user` VALUES (567, '2008-10-15', 'lotoos79@bk.ru', 'DTHJYBRF', '', 'Anry', '', '', '', '+79233369263', '', '', 'Боготол', 0, 0, '', 4127, '', '', '', '', '', 10, '', '2 недели', '', '', '', '', 'lotoos79@bk.ru');
INSERT INTO `ri_user` VALUES (568, '2008-10-21', 'VIP_SHADOWS@yahoo.com', '347164', '', 'Зоя', '', '', '', '', '', '', 'Хабаровск', 0, 0, '', 0, '', '', '', '', '', 3, '', '', '', '', '', '', 'VIP_SHADOWS@yahoo.com');
INSERT INTO `ri_user` VALUES (569, '2008-10-22', 'komatozzznic@mail.ru', '528747', '', 'komatozzz', '', '', '', '', '', '', 'Курган', 0, 0, '363941028', 4142, '285725937053', '436410170786', '', '', '', 15, '', '', 'www.readywork.ru;www.troek.net;www.stydenty.info;www.studzona.com;', 'www.prepadav.ru;www.bestreferat.ru;www.psyhologi.ru;www.znaj.ru;', 'www.prepadav.ru;www.open.ref.uz;www.5ballov.ru;www.megastock.ru;', '', 'komatozzznic@mail.ru');
INSERT INTO `ri_user` VALUES (570, '2008-10-23', 'hordichuk@mail.ru', 'яблоконавсегда', '', '', '', '', '', '', '', '', 'Омск', 0, 0, '401361438', 4142, '705885474382', '', '', '', '', 10, '', '', '5ka.ru;', 'obyava.ru;', '5ka.ru;', '', 'hordichuk@mail.ru');
INSERT INTO `ri_user` VALUES (571, '2008-10-25', 'postsof@rambler.ru', '89515342450', '', 'Sofland', '', '', '', '+79515342450', '', '+79198957572', 'Ростов-на-Дону', 0, 0, '367689728', 4179, '', '', '', '41001265661172', '', 8, '', '', '', '', '', '', 'postsof@rambler.ru');
INSERT INTO `ri_user` VALUES (572, '2008-10-27', 'mashenkaswan@yandex.ru', 'swan11', '', 'mashenkaswan', '', '', '', '', '', '', 'Москва', 0, 0, '', 4147, '178669982060', '155222745370', '', '', '', 50, '', '', '', '', '', '', 'mashenkaswan@yandex.ru');
INSERT INTO `ri_user` VALUES (573, '2008-10-29', 'aleksandrLubk@yandex.ru', '', '', '', '', '', '()', ' 79053666838', '', '', 'Пенза', 0, 0, '', 4163, '', '', '', '41001284348406', '', 0, '', '', '', '', '', '', 'aleksandrLubk@yandex.ru');
INSERT INTO `ri_user` VALUES (574, '2008-10-29', 'irinamorozo@mail.ru', 'Zebu05051975', '', 'Zebra', '', '', '(7212)516823', '7778027916', '', '', 'Караганда', 0, 0, '470665704', 4284, 'R306035611176', 'Z418061485125', '', '41001268011029', '', 0, '', '', '', '', '', '', 'irinamorozo@mail.ru');
INSERT INTO `ri_user` VALUES (575, '2008-10-29', 'zarinan@mail.ru', '327925', '', 'Таша', '', '', '()', '906 148 31 62', '', '', 'Саратов', 0, 0, '285513315', 4149, '', '', '', '', '', 0, '', '', '', '', '', '', 'zarinan@mail.ru');
INSERT INTO `ri_user` VALUES (576, '2008-11-01', 'MariyaPolikarpovna@gmail.com', '0549115', '', 'Mariya061', '', '', '()', '918 054 91 15', '', '', 'Ростов, КраснодарРостов, Краснодар', 0, 0, '204176159', 4251, '', '', '', '41001265288827', '', 0, '', '', '', '', '', '', 'MariyaPolikarpovna@gmail.com');
INSERT INTO `ri_user` VALUES (577, '2008-11-03', 'leogorn@ya.ru', 'jnrhsnm', '', 'Г-н', '', '', '843 2753941', '89050386900', '', '', 'Казань', 0, 0, '314319903', 4159, '110581361309', '', '', '41001121666364', '', 300, 'http://diplom.kzn.ru', '', '', '', '', '', 'leogorn@ya.ru');
INSERT INTO `ri_user` VALUES (578, '2008-11-04', 'nba1985@rambler.ru', 'nfkfyn1985', '', 'Pyshistic', '', '', '', '89059576685', '', '', 'Новосибирск', 0, 0, '', 0, '', '', '', '41001271146134', '', 50, '', '', '', '', '', '', 'nba1985@rambler.ru');
INSERT INTO `ri_user` VALUES (579, '2008-11-04', 'planeta-diplom@mail.ru', '190598', '', 'Людмила', '', '', '(343) 354-84-43', '89041659625', '', '', 'Екатеринбург', 0, 0, '242368890', 4183, '', '', '', '41001236752129', '', 600, '', '', 'bankrabot.ru;', 'bankrabot.ru;', '5ballov.ru;', '', 'planeta-diplom@mail.ru');
INSERT INTO `ri_user` VALUES (580, '2008-11-08', 'valentinamayorova@yahoo.com', 'dfktynbyf', '', 'Valentina', '', '', '', '89278450119', '', '', 'Чебоксары', 0, 0, '431357336', 4223, '', '', '', '41001198389567', '', 10, '', '', '', '', '', '', 'valentinamayorova@yahoo.com');
INSERT INTO `ri_user` VALUES (581, '2008-11-08', 'OKSANA_7579@mail.ru', '123456', '', '', '', '', '', '79242022931', '', '', 'Хабаровск', 0, 0, '', 4348, '', '', '', '41001290983567', '', 4, '', '', '', '', '', '', 'OKSANA_7579@mail.ru');
INSERT INTO `ri_user` VALUES (582, '2008-11-10', '125sascha@mail.ru', '020486', '', 'Александра', '', '', '', '', '', '', 'Ростов-на-Дону', 0, 0, '', 4172, '', '', '', '', '', 3, '', '', '', '', '', '', '125sascha@mail.ru');
INSERT INTO `ri_user` VALUES (583, '2008-11-13', 'oxy85@inbox.ru', 'kisikoxy', '', '', '', '', '(495)3843216', '', '', '', 'Москва', 0, 0, '', 4230, '', '', '', '', '', 0, '', '', '', '', '', '', 'oxy85@inbox.ru');
INSERT INTO `ri_user` VALUES (584, '2008-11-15', 'robyn1@yandex.ru', 'ub,cjy', '', 'Mishel', '', '', '', '903-504-52-40', '', '', 'Москва', 0, 0, '', 4178, '', '', '', '', '', 15, '', '', '', '', '', '', 'robyn1@yandex.ru');
INSERT INTO `ri_user` VALUES (585, '2008-11-20', 'group-phd@mail.ru', 'red123co', '', '', '', '', '', '', '', '', 'Старый Оскол', 0, 0, '431229698', 4277, 'R209739356781', '', '', '41001284068409', '', 5, '', '', 'Ваш сайт первый куда я зашел;', '', '', '', 'group-phd@mail.ru');
INSERT INTO `ri_user` VALUES (586, '2008-11-20', 'ostkat@yandex.ru', '123456', '', 'Катюша', '', '', '', '', '', '', 'Курск', 0, 0, '', 4354, '', '', '', '', '', 40, '', '', '', '', '', '', 'ostkat@yandex.ru');
INSERT INTO `ri_user` VALUES (587, '2008-11-21', 'alilyubnik@yandex.ru', 'podrabotka', '', 'Олег Николаевич', '', '', '', '8-916-748-00-41', '', '', 'МО, г.Подольск', 0, 0, '', 4199, '', '', '', '', '', 18, '', '', '', '', '', '', 'alilyubnik@yandex.ru');
INSERT INTO `ri_user` VALUES (588, '2008-11-24', 'zakaz5@list.ru', 'olesyazakharova', '', 'Захарова О.А.', '', '', '8 (8552) 56-70-02, +', '+ 7 917-231-13-38', '', '', 'Набережные Челны', 0, 0, '407085593', 4278, '', '', '', '', '', 55, '', '1-2 месяца', 'chelnyltd.ru;', '', '', '', 'zakaz5@list.ru');
INSERT INTO `ri_user` VALUES (589, '2008-12-05', 'Ankotova@yandex.ru', 'anna0109', '', '@nn@', '', '', '( 7)903-84-99-760', '', '', '', 'Дзержинск Нижегородской области', 0, 0, '', 4388, '', '', '', '', '', 0, '', '', '', '', '', '', 'Ankotova@yandex.ru');
INSERT INTO `ri_user` VALUES (590, '2008-12-12', 'dashutka-belova@yandex.ru', '361151', '', 'Дарья', '', '', '', '', '', '', 'Волгоград', 0, 0, '', 4400, '', '', '', '', '', 6, '', '', '', '', 'bankreferatov.ru ;', '', 'dashutka-belova@yandex.ru');
INSERT INTO `ri_user` VALUES (591, '2008-12-12', 'abakumovaolgamir@yandex.ru', '220192', '', 'abak', '', '', '()', '89065744880', '', '', 'Воронеж', 0, 0, '490411395', 4257, '', '', '', '41001282109335', '', 0, '', '', '', '', '', '', 'abakumovaolgamir@yandex.ru');
INSERT INTO `ri_user` VALUES (592, '2008-12-16', 'viktoria-star1@rambler.ru', '382581567', '', 'Виктория', '', '', '', '', '', '', 'Благовещенск', 0, 0, '382581567', 4352, '', '', '', '41001276803583', '', 50, '', '', 'http://rabotadoma.ru;', 'www.slando.ru ;', 'studentport.su;', '', 'viktoria-star1@rambler.ru');
INSERT INTO `ri_user` VALUES (593, '2008-12-16', 'tonya-shevchenko@mail.ru', 'RJSGJGRF1', '', 'Тоня', '', '', '', '8 067 873 99 61', '', '', '. Біла Церква', 0, 0, '', 4277, '', '', '', '', '', 1200, '', '', '', '', '', '', 'tonya-shevchenko@mail.ru');
INSERT INTO `ri_user` VALUES (594, '2008-12-17', 'altynajka@mail.ru', 'akkem', '', 'cvet vesny', '', '', '(383)2199714', '89137410625', '', '', 'Новосибирск', 0, 0, '416-471-866', 4265, '', '', '', '41001300892137', '', 0, '', '', '', '', '', '', 'altynajka@mail.ru');
INSERT INTO `ri_user` VALUES (595, '2008-12-19', 'Slavyanuch@yandex.ru', 'fcnfvfymzyf', '', 'Продавец', '', '', '', '', '', '', 'Москва', 0, 0, '', 4296, '', '', '', '', '', 5, '', '', 'dontknow.ru;because.ru;this.is.ru;first.ru;web.page.ru;', '', '', '', 'Slavyanuch@yandex.ru');
INSERT INTO `ri_user` VALUES (596, '2008-12-23', 'mar-research@yandex.ru', '19021984', '', 'Mar-research', '', '', '(916)6693776', '', '', '', 'Москва', 0, 0, '', 4277, '', '', '', '', '', 0, '', '', '', '', '', '', 'mar-research@yandex.ru');
INSERT INTO `ri_user` VALUES (597, '2008-12-26', 'Iguana1981@mail.ru', '150681', '', 'Iguana', '', '', '', '9190264627', '', '', 'Ковров', 0, 0, '455622836', 4283, '135583850791', '', '', '', '', 10, '', '', '', '', '', '', 'Iguana1981@mail.ru');
INSERT INTO `ri_user` VALUES (598, '2008-12-31', 'PISUN9999@yandex.ru', 'dKmn45bs', '', 'KMR945', '', '', '3435 36-15-53', '+7 922 1021348', '', '', 'Нижний Тагил', 0, 0, '', 4294, '357570286413', '173682894320', '255360073424', '41001232895864', '', 5, 'http://vla59437674.narod.ru/index.htm', '', '.readywork.ru;', 'bankrabot.ru;', 'diplom-service.ru;', '', 'PISUN9999@yandex.ru');
INSERT INTO `ri_user` VALUES (599, '2009-01-03', 'golvit@meta.ua', 'holovnia', '', 'golvit', '', '', '', '+380637840395', '', '+380976132209', 'Polonne', 0, 0, '', 4286, '', '376813999432', '', '', '', 2000, '', '', 'google.com;meta.ua;rambler.ru;', 'meta.ua;pr-71.ucoz.ua;refer.in.ua;', '5balov.ru;', '', 'golvit@meta.ua');
INSERT INTO `ri_user` VALUES (600, '2009-01-03', 'Max_litvin-888@ukr.net', '1983ML', '', 'max', '', '', '80509857778', '', '', '', 'Дебальцево', 0, 0, '120', 4286, '', '', '', '', '', 1, '', '', '', '', '', '', 'Max_litvin-888@ukr.net');
INSERT INTO `ri_user` VALUES (601, '2009-01-06', 'jrcfyf22_23_24@mail.ru', '17031984', '', 'o-pole', '', '', '', '+7 911 533 05 41', '', '', 'Вологда', 0, 0, '', 4471, '', '', '', '41001313958635', '', 1, '', '', 'moreferatov.ru;', 'moreferatov.ru;', 'moreferatov.ru;', '', 'jrcfyf22_23_24@mail.ru');
INSERT INTO `ri_user` VALUES (602, '2009-01-06', 'scdiger@inbox.ru', 're1114', '', 'scdiger', '', '', '', '', '', '', 'Владивосток', 0, 0, '', 4293, '142578331806', '366243446267', '373514575855', '', '', 2, '', '', '', '', '', '', 'scdiger@inbox.ru');
INSERT INTO `ri_user` VALUES (603, '2009-01-11', 'serok@pochta.ru', 'wert418ds', '', 'Serkrav', '', '', '', '', '', '', 'Котлас', 0, 0, '', 4306, '212829477905', '411739205695', '', '4100153066011', '', 4, '', '', '', '', '', '', 'serok@pochta.ru');
INSERT INTO `ri_user` VALUES (604, '2009-01-11', 'valeriya_ale.ru@mail.ru', '19880823', '', '', '', '', '3953573934', '+79025766820', '', '', 'Усть-Илимск', 0, 0, '', 4396, 'R277193463147', '', '', '', '', 2, '', '', 'referats.ru;', 'referats.ru;', 'bank referatof.ru;', '', 'valeriya_ale.ru@mail.ru');
INSERT INTO `ri_user` VALUES (606, '2009-01-14', '7824841@mail.ru', '111111', '', 'mirikle', '', '', '', '89629392386', '', '', 'Москва', 0, 0, '', 4302, '', '', '', '', '', 15, '', '', '', '', '', '', '7824841@mail.ru');
INSERT INTO `ri_user` VALUES (607, '2009-01-15', 'dr3-love@yandex.ru', 'qwert789', '', '', '', '', '', '89160727307', '', '', 'Москва', 0, 0, '489920781', 4454, 'R668205533099', '', '', '', '', 20, '', '', '', '', '', '', 'dr3-love@yandex.ru');
INSERT INTO `ri_user` VALUES (608, '2009-01-17', 'olxovec@yandex.ru', '281284', '', 'Vitaol', '', '', '', '905-931-2026', '', '', 'Новосибирск', 0, 0, '', 4312, '', '', '', '41001202772918', '', 3, '', '', '', '', '', '', 'olxovec@yandex.ru');
INSERT INTO `ri_user` VALUES (609, '2009-01-19', 'vishy08@mail.ru', 'casablanca', '', '', '', '', '', '916-950-4510', '', '', 'Москва', 0, 0, '', 4370, '', '', '', '', '', 8, '', '', '', '', '', '', 'vishy08@mail.ru');
INSERT INTO `ri_user` VALUES (610, '2009-01-21', 'kropol@rambler.ru', '237673', '', 'kropol', '', '', '(3472)768410', ' 79174593868', '', '', 'Уфа', 0, 0, '', 4348, '', '', '', '', '', 0, '', '', '', '', '', '', 'kropol@rambler.ru');
INSERT INTO `ri_user` VALUES (611, '2009-01-22', 'irinak.78@mail.ru', 'cthjdf', '', 'irinakochan', '', '', '(8482)950974', '89277825981', '', '', 'Тольятти', 0, 0, '408-093-087', 0, '', '', '', '', '', 0, '', '', '', '', '', '', 'irinak.78@mail.ru');
INSERT INTO `ri_user` VALUES (612, '2009-01-22', 'linusha@pisem.net', 'xkiller', '', 'Linusha', '', '', '()', '89052184533', '', '', 'Санкт -Петербург', 0, 0, '165922765', 4390, '', '', '', '', '', 0, '', '', '', '', '', '', 'linusha@pisem.net');
INSERT INTO `ri_user` VALUES (613, '2009-01-22', 'sufianova@yandex.ru', 'ntkmvfy', '', 'sufianova', '', '', '(86137)44447', '928-8495806', '', '', 'Армавир', 0, 0, '', 4330, '', '', '', '', '', 0, '', '', '', '', '', '', 'sufianova@yandex.ru');
INSERT INTO `ri_user` VALUES (614, '2009-01-23', 'mari-krasnochtanova@yandex.ru', 'ralf', '', 'Михаил Мннокетьевич', '', '', '83956843477', '89140026735', '-', '-', 'г. Киренск', 0, 0, '', 4331, '', '', '', '', '', 0, '', '', '', '', '', '', 'mari-krasnochtanova@yandex.ru');
INSERT INTO `ri_user` VALUES (615, '2009-01-24', 'voronova_irin@mail.ru', '15021987', '', 'zlibnaya', '', '', '', '', '', '', 'Калининград', 0, 0, '', 4332, '', '', '', '41001142251085', '', 10, '', '', '', '', '', '', 'voronova_irin@mail.ru');
INSERT INTO `ri_user` VALUES (616, '2009-01-24', 'ivaninaa@mail.ru', 'anna315082', '', '', '', '', '(926)0120163', '', '', '', 'Щелково, МО', 0, 0, '', 4441, '', '', '', '41001355961953', '', 0, '', '', '', '', '', '', 'ivaninaa@mail.ru');
INSERT INTO `ri_user` VALUES (617, '2009-01-24', 'basantija@yandex.ru', '22011985', '', 'Юля', '', '', '-', '89603434635', '-', '', 'Саратов и др.', 0, 0, '', 4371, '', '', '', '41001299951133', '', 750, '', '', 'allbest.ru;', 'allbest.ru;', 'allbest.ru;5ballov.ru;bestreferat.ru;', '', 'basantija@yandex.ru');
INSERT INTO `ri_user` VALUES (618, '2009-01-24', 'sonja13@mail.ru', 'blacksea', '', 'sonja13', '', '', '', '9099192249', '', '', 'Москва', 0, 0, '', 4332, '', '', '', '', '', 1, '', '', 'ya.ru;', 'ya.ru;', 'ya.ru;', '', 'sonja13@mail.ru');
INSERT INTO `ri_user` VALUES (619, '2009-01-26', '4ur4ill@gmail.com', '525889', '', '', '', '', '', '', '', '', 'Воронеж', 0, 0, '', 4345, '', '', '', '41001328081415', '', 2, '', '', 'referats.info;', 'referats.info;', 'referats.info;', '', '4ur4ill@gmail.com');
INSERT INTO `ri_user` VALUES (620, '2009-01-26', 'denis-linkv@rambler.ru', '271007', '', 'Denis', '', '', '', '89102234256', '', '', 'Белгород', 0, 0, '348965174', 4425, '751062596814', '482887481922', '235996646607', '', '', 30, '', '', 'moyareklama.ru;', 'moyareklama.ru;', 'bankreferatov.ru;', '', 'denis-linkv@rambler.ru');
INSERT INTO `ri_user` VALUES (621, '2009-01-27', 'irinakorolkova@mail.ru', 'irinak', '', 'Ирина Александровна', '', '', '8-4912-76-18-47', '8-910-902-04-49', '', '', 'Рязань', 0, 0, '254934928', 4456, '363196579375', '', '', '41001163920988', '', 300, 'www.studentplus.narod.ru', '', '101student.ru;', 'bankreferatov.ru;', 'bankreferatov.ru;referat.ru;5-ka.ru;5ballov.ru;', '', 'irinakorolkova@mail.ru');
INSERT INTO `ri_user` VALUES (622, '2009-01-27', 'katya_kadruleva@list.ru', '2103', '', 'Zyzya', '', '', '(4242)724736', '89241812547', '(4242)467780', '891475522223', 'Южно-Сахалинск', 0, 0, '', 4387, '367494102256', '', '', '', '', 3, '', '', '', '', '', '', 'katya_kadruleva@list.ru');
INSERT INTO `ri_user` VALUES (623, '2009-01-27', 'jrcfyf2004@bk.ru', '29 ajd', '', 'jrcfyf29', '', '', '', '', '', '', 'иваново', 0, 0, '', 4417, '', '', '', '', '', 25, '', '', 'irr.ru;', 'irr.ru;', '5ballov.ru;', '', 'jrcfyf2004@bk.ru');
INSERT INTO `ri_user` VALUES (624, '2009-01-28', 'velstar2006@yandex.ru', '15091973', '', 'Валерия', '', '', '87937-72798', '+79283691435', '', '', 'Кисловодск', 0, 0, '', 4470, '336985267359', '', '', '', '', 20, '', '', '', '', '', '', 'velstar2006@yandex.ru');
INSERT INTO `ri_user` VALUES (625, '2009-01-30', 'kefir_86@mail.ru', '742051', '', 'KEFIRёнок', '', '', '88162742051', '89116231956', '', '', 'Великий Новгород', 0, 0, '390519542', 4367, '', '', '', '41001330430520', '', 30, '', '', 'referat.ru;bankreferatov.ru;allbest.ru;5ballov.ru;referatbank.ru;', 'referat.ru;bankreferatov.ru;allbest.ru;5ballov.ru;referatbank.ru;', 'referat.ru;bankreferatov.ru;allbest.ru;5ballov.ru;referatbank.ru;', '', 'kefir_86@mail.ru');
INSERT INTO `ri_user` VALUES (626, '2009-01-31', 'ARSELYA@MAIL.RU', '0313', '', 'ЭЛЬВИРА', '', '', '', '8-917-37-06-229', '', '', 'УФА', 0, 0, '402300157', 4343, '', '', '', '', '', 60, '', '2 МЕСЯЦА', '', '', '', '', 'ARSELYA@MAIL.RU');
INSERT INTO `ri_user` VALUES (627, '2009-01-31', 'evgeniyakuchinskaya@yandex.ru', '2403', '', 'Евгения', '', '', '(8351)2623511', '89227039552', '', '', 'Челябинск', 0, 0, '', 4344, '', '', '', '', '', 0, '', '', '', '', '', '', 'evgeniyakuchinskaya@yandex.ru');
INSERT INTO `ri_user` VALUES (628, '2009-02-01', '20081999.79@mail.ru', 'kochehka', '', 'Валентина', '', '', '', '', '', '', 'Красноярск', 0, 0, '', 4345, '', '', '', '41001287513754', '', 2, '', '', '', '', '', '', '20081999.79@mail.ru');
INSERT INTO `ri_user` VALUES (629, '2009-02-02', 'satana70@rambler.ru', 'VjdJdfEurrvQ', '', 'Науменко Николай', '', '', '', '', '', '', 'Нижневартовск', 0, 0, '244914694', 4421, '258281170195', '', '', '', '', 700, '', '', '', '', '', '', 'satana70@rambler.ru');
INSERT INTO `ri_user` VALUES (630, '2009-02-02', 'www.dvsergeevich@mail.ru', 'danchenko', '', 'dvsergeevich', '', '', '', '89135982725', '', '', 'Красноярск', 0, 0, '', 0, '', '', '', '41001332148342', '', 5, '', '', '', '', '', '', 'www.dvsergeevich@mail.ru');
INSERT INTO `ri_user` VALUES (631, '2009-02-03', 'alena-gerasimova@yandex.ru', '435222', '', 'Герасимова Алена Игоренва', '', '', '', '9050802048', '', '', 'барнаул', 0, 0, '', 0, '', '', '', '', '', 10, '', '', '', '', '', '', 'alena-gerasimova@yandex.ru');
INSERT INTO `ri_user` VALUES (632, '2009-02-03', 'exxxin@yandex.ru', '84exin25', '', 'exin', '', '', '', 'exxxin@yandex.ru', '', '', 'Витебск', 0, 0, '368654921', 4371, '109002986694', '209486136438', '', '41001275599937', '', 15, '', '', '', '', '', '', 'exxxin@yandex.ru');
INSERT INTO `ri_user` VALUES (633, '2009-02-04', 'nov-lana@yandex.ru', '1984', '', 'Петрова Светлана Владимировна', '', '', '', '89144709066', '', '', 'г.Чита', 0, 0, '', 4348, '', '', '', '4100183443944', '', 8, '', '', '', '', '', '', 'nov-lana@yandex.ru');
INSERT INTO `ri_user` VALUES (634, '2009-02-05', 'magrusl@yandex.ru', '7539510.', '', 'magrusl', '', '', '', '+79633725036', '', '', 'Избербаш', 0, 0, '350753949', 0, '', '', '', '41001220073408', '', 20, '', '', '', '', '', '', 'magrusl@yandex.ru');
INSERT INTO `ri_user` VALUES (635, '2009-02-05', 'magrusl@gmail.com', '7539510,', '', '', '', '', '', '+79633725036', '', '', 'Махачкала', 0, 0, '', 4349, 'R173762469364', 'Z289568525764', 'E129302952566', '41001220073408', '', 50, '', '', '', '', '', '', 'magrusl@gmail.com');
INSERT INTO `ri_user` VALUES (636, '2009-02-05', 'toktarev-aleksan@mail.ru', '191085', '', '', '', '', '()', '89274504816', '', '', 'набережные челны', 0, 0, '468832697', 4442, '', '', '', '41001334226207', '', 0, '', '', '', '', '', '', 'toktarev-aleksan@mail.ru');
INSERT INTO `ri_user` VALUES (637, '2009-02-08', '40in_2003@mail.ru', 'madegg', '', 'Ego', '', '', '', '+79115459425', '', '', 'Череповец', 0, 0, '', 4426, '', '', '', '41001335815646', '', 35, '', '', '', '', '', '', '40in_2003@mail.ru');
INSERT INTO `ri_user` VALUES (638, '2009-02-11', 'bk007@bk.ru', '9118903', '', 'bk', '', '', '', '', '', '', 'Ставрополь', 0, 0, '327510265', 4383, '', '', '', '41001251549567', '', 25, '', '', '', '', '', '', 'bk007@bk.ru');
INSERT INTO `ri_user` VALUES (639, '2009-02-13', 'silwa62@mail.ru', 'radyga', '', 'silwa', '', '', '(4912)41-13-10', '8-910-505-99-00', '', '', 'Рязань', 0, 0, '', 4360, '', '', '', '41001277135607', '', 500, '', '', 'diplom_gotovie,ru;readywork.ru;', 'yarmarka-ryazan.ru;', 'kyrsovik.oflameron.ru;referatbank.ru;sdadim.info;referats.net;', '', 'silwa62@mail.ru');
INSERT INTO `ri_user` VALUES (640, '2009-02-15', 'pavlikya@mail.ru', 'gfhjkm', '', 'Павлюченко Вадим', '', '', '+375163402019', '+375293353449', '', '+375297944133', 'Барановичи', 0, 0, '', 4405, '', '', '284210237560', '', '', 100, '', '', '', '', '', '', 'pavlikya@mail.ru');
INSERT INTO `ri_user` VALUES (641, '2009-02-15', 'Kamornikow@yandex.ru', 'gbhfvblf', '', 'komarik2015', '', '', '', '89224793390', '', '', 'Тюмень', 0, 0, '', 4470, '', '', '', '41001340028221', '', 40, '', '', '', '', '', '', 'Kamornikow@yandex.ru');
INSERT INTO `ri_user` VALUES (642, '2009-02-15', 'galchenok-bel@yandex.ru', '255707', '', 'Galina', '', '', '', '+79261846845', '', '', 'Ногинск', 0, 0, '439279116', 4435, '', '', '', '41001340188851', '', 5, '', '', '', '', '', '', 'galchenok-bel@yandex.ru');
INSERT INTO `ri_user` VALUES (643, '2009-02-18', 'skazka287@rambler.ru', '17032008', '', 'Аванесова Элина', '', '', '', '+79209749087', '', '', 'Шилово', 0, 0, '', 0, '', '', '', '', '', 3, '', '', '', '', '', '', 'skazka287@rambler.ru');
INSERT INTO `ri_user` VALUES (644, '2009-02-20', 'hmelevskayia.ru@list.ru', 'wap1812', '', 'Елена Яковлева', '', '', '', '', '', '', 'Санкт-Петербург', 0, 0, '', 4427, '', '', '', '41001161108104', '', 33, '', '', '', '', '', '', 'hmelevskayia.ru@list.ru');
INSERT INTO `ri_user` VALUES (645, '2009-02-20', 'Glamvipslava@yandex.ru', '14241983', '', '', '', '', '', '89146011672', '', '', 'г. Благовещенск', 0, 0, '', 4417, '', '', '', '41001343249622', '', 1, '', '', 'moscowdiplom.ru ;', 'resh.im;', 'bestreferats.chat.ru;', '', 'Glamvipslava@yandex.ru');
INSERT INTO `ri_user` VALUES (646, '2009-02-21', 'korios@bk.ru', '890098', '', 'Iosif', '', '', '', '', '', '', 'владикавказ', 0, 0, '', 4455, '', '', '', '', '', 250, '', '', '', '', '', '', 'korios@bk.ru');
INSERT INTO `ri_user` VALUES (647, '2009-02-22', 'kostanna1988@mail.ru', '1736', '', 'Anzza', '', '', '88172710696', '89052973959', '', '', 'Вологда', 0, 0, '407629193', 4383, '', '', '', '41001343709494', '', 10, '', '', 'allbest.ru;referat.ru;zakazdiplom.ru;sdadim.info;', 'sdadim.info;', 'allbest.ru;', '', 'kostanna1988@mail.ru');
INSERT INTO `ri_user` VALUES (648, '2009-02-24', 'eyarovikova@yandex.ru', '060662ll', '', 'dastoni', '', '', '8-34241-24334', '8-922-316-20-54', '', '', 'Чайковский', 0, 0, '392554553', 4383, '', '', '', '', '', 2, '', '1 год', '', '', '', '', 'eyarovikova@yandex.ru');
INSERT INTO `ri_user` VALUES (649, '2009-02-26', 'kudryashova-anna@yandex.ru', '210607', '', 'АннаЧП', '', '', '', '', '', '', 'Тюмень', 0, 0, '', 4456, '', '', '', '41001341457832', '', 50, '', '', '', '', '', '', 'kudryashova-anna@yandex.ru');
INSERT INTO `ri_user` VALUES (650, '2009-02-27', 'raushalove1987@rambler.ru', 'zcegth', '', 'raushalove', '', '', '', '', '', '', 'Волгоград', 0, 0, '384947557', 4471, '351388888834', '', '', '', '', 50, '', '', '', '', '', '', 'raushalove1987@rambler.ru');
INSERT INTO `ri_user` VALUES (651, '2009-02-28', 'busness2@rambler.ru', '227102', '', 'cik', '', '', '', '', '', '', 'Moldova', 0, 0, '', 4393, '', '', '327157211556', '', '', 150, '', '', '', '', '', '', 'busness2@rambler.ru');
INSERT INTO `ri_user` VALUES (652, '2009-02-28', 'bogatswo@mail.ru', 'ltymubntrenrjvythtrjq', '', '', '', '', '', '', '', '', 'Магнитогорск', 0, 0, '404722170', 4470, '341644139958', '303092703479', '153993248007', '', '', 18, '', '', 'referat.ru;forum.reborn.ru;open.ref.uz;annshavkunova.narod.ru ;univer.by;', 'referat.ru;referat.reborn.ru;forum.reborn.ru;studgorodok.ru;', '5ballov.ru;allbest.ru;kursoviki.spb.ru;referat.reborn.ru;', '', 'bogatswo@mail.ru');
INSERT INTO `ri_user` VALUES (653, '2009-03-01', 'solo-genij45@mail.ru', '555555', '', 'Genij45', '', '', '', '89033483314', '', '', 'Астрахань', 0, 0, '258220021', 4396, '249953202483', '', '', '', '', 500, '', '', '', '', '', '', 'solo-genij45@mail.ru');
INSERT INTO `ri_user` VALUES (654, '2009-03-02', 'referatik111@mail.ru', '120107', '', 'Марина', '', '', '', '', '', '', 'Уфа', 0, 0, '444802198', 4456, '', '', '', '41001346675732', '', 50, '', '', '7347.ru;irr.ru;', 'irr.ru;7347.ru;', 'allbest.ru;bankreferatov.ru;bestreferat.ru;', '', 'referatik111@mail.ru');
INSERT INTO `ri_user` VALUES (655, '2009-03-03', 'serz999@yandex.ru', 'ckfdf2007', '', 'Вячеслав', '', '', '', '+7-924-219-12-01', '', '', 'Биробиджан', 0, 0, '', 4401, '809982565960', '', '', '', '', 7, '', '', 'referat.ru;', 'referat.ru;', 'referat.ru;', '', 'serz999@yandex.ru');
INSERT INTO `ri_user` VALUES (656, '2009-03-03', 'oksana-otmakhova@yandex.ru', 'ctvbwdtnbr', '', 'oksana-otmakhova', '', '', '', '', '', '', 'красноярск', 0, 0, '490469967', 4407, '', '', '', '41001341672680', '', 2, '', '', '', '', '', '', 'oksana-otmakhova@yandex.ru');
INSERT INTO `ri_user` VALUES (657, '2009-03-06', 's_boiko@list.ru', '8071997', '', 'Бойко Сергей Николаевич', '', '', '', '890888541410', '', '', 'Нягань', 0, 0, '243611066', 4414, '330281449635', '615323442865', '', '41001312663140', '', 1, '', '', 'не знаю;', 'intellect-center.narod.ru;', '', '', 's_boiko@list.ru');
INSERT INTO `ri_user` VALUES (658, '2009-03-06', 'hobo2002@inbox.ru', '2222222222', '', 'Риша', '', '', '(8-385-2)43-21-85', '8-903-992-31-26', '', '', 'Барнаул', 0, 0, '278284517', 4414, '', '', '', '', '', 0, '', '', '', '', '', '', 'hobo2002@inbox.ru');
INSERT INTO `ri_user` VALUES (659, '2009-03-07', 'adrobina@mail.ru', '212121', '', 'adrobina@mail.ru', '', '', '()', '905 0820464', '', '', 'Новоалтайск', 0, 0, '', 4449, '', '', '', '41001293245792', '', 0, '', '', '', '', '', '', 'adrobina@mail.ru');
INSERT INTO `ri_user` VALUES (660, '2009-03-07', 'alex230984@yandex.ru', '258984', '', 'Alexandr Vorobyev', '', '', '', '89616302252', '', '', 'Балахна, Н.Новгород', 0, 0, '', 4417, '328685554226', '', '', '', '', 1, '', '', '', '', '', '', 'alex230984@yandex.ru');
INSERT INTO `ri_user` VALUES (661, '2009-03-09', 'osokina@nln.ru', '68914070', '', 'Юлия Осокина', '', '', '', '925-8478521', '', '', 'Москва', 0, 0, '', 0, '', '', '', '', '', 1, '', '', '', '', '', '', 'osokina@nln.ru');
INSERT INTO `ri_user` VALUES (662, '2009-03-10', 'podbor2000@yandex.ru', '459201', '', 'Людмила1', '', '', '', '', '', '', 'Саратов', 0, 0, '', 4419, '294573282236', '', '', '', '', 1, '', '', 'diplom.krsk.info;', 'socrat.info;', 'happy-student.ru;', '', 'podbor2000@yandex.ru');
INSERT INTO `ri_user` VALUES (663, '2009-03-12', 'milasha423@yandex.ru', 'romashka', '', '', '', '', '(3952)440915', '', '', '', 'Иркутск', 0, 0, '455542480', 4470, '', '', '', '41001355043007', '', 100, '', '', '', '', '', '', 'milasha423@yandex.ru');
INSERT INTO `ri_user` VALUES (664, '2009-03-13', 'dinochka000@gmail.com', '180484', '', 'madinasekova', '', '', '( 79882)939011', ' 7-928-500-34-61', '', '', 'Махачкала', 0, 0, '164-196-396', 4432, '', '', '', '', '', 0, '', '', '', '', '', '', 'dinochka000@gmail.com');
INSERT INTO `ri_user` VALUES (665, '2009-03-13', 'natusik_2004@list.ru', '6364551', '', 'Шагурина Наталья Анатольевна', '', '', '', '8-905-636-45-51', '', '', 'Москва', 0, 0, '463728178', 4432, '', '', '', '', '', 30, '', '', '', '', '', '', 'natusik_2004@list.ru');
INSERT INTO `ri_user` VALUES (666, '2009-03-13', 'sve2724@yandex.ru', 'svpavel', '', 'svetlo', '', '', '', '', '', '', 'Екатеринбург', 0, 0, '459053077', 0, '', '', '', '', '', 1, '', '', 'sachok.ru;diplomm.ru;diplomnie-raboti.ru;', 'sachok.ru;diplomm.ru;diplomnie-raboti.ru;', 'diplom-referat.ru;delo-plus.ru;kursoviki.spb.ru;', '', 'sve2724@yandex.ru');
INSERT INTO `ri_user` VALUES (667, '2009-03-13', 'kis10@mail.ru', '7172002', '', 'kis10', '', '', '()', '89062959944', '', '', 'Череповец', 0, 0, '367-758-450', 4441, '', '', '', '', '', 0, '', '', '', '', '', '', 'kis10@mail.ru');
INSERT INTO `ri_user` VALUES (668, '2009-03-14', 'zak-diploma@yandex.ru', '310387', '', 'Нестор Петрович', '', '', '', '', '', '', 'Москва', 0, 0, '', 4468, '413927148998', '', '', '', '', 300, '', '', '', '', '', '', 'zak-diploma@yandex.ru');
INSERT INTO `ri_user` VALUES (669, '2009-03-15', 'VecheGG@yandex.ru', '298419', '', 'VecheGG', '', '', '()', '89049384362', '', '', 'Магнитогорск', 0, 0, '494473118', 4454, '', '', '', '', '', 0, '', '', '', '', '', '', 'VecheGG@yandex.ru');
INSERT INTO `ri_user` VALUES (670, '2009-03-18', 'idmi@mail.ru', '121212', '', 'Plama', '', '', '()', '89166018205', '', '', 'Электросталь', 0, 0, '223237040', 4452, '', '', '', '', '', 0, '', '', '', '', '', '', 'idmi@mail.ru');
INSERT INTO `ri_user` VALUES (671, '2009-03-20', 'nadyusha-kubgu@mail.ru', 'cneltyn', '', 'Надежда Карпова', '', '', '', '89615032756', '', '8905475473', 'Краснодар', 0, 0, '411465667', 4471, '', '', '', '41001359997280', '', 8, '', '', 'vash-rinok.ru;do.chuvashiya.biz;tolku4ka.ru;adelon.ru;', 'vash-rinok.ru;do.chuvashiya.biz;tolku4ka.ru;adelon.ru;', 'ytchebnik.ru;', '', 'nadyusha-kubgu@mail.ru');
INSERT INTO `ri_user` VALUES (672, '2009-09-23', 'mail1@list.ru', 'serega', 'S_RAD_ORDER', 'Петрова Виктория Владимировна', '', '', '', '8-903-947-7971', '', '', 'Барнаул', 0, 0, '', 4471, '', '', '', '41001193157329', '', 2000, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (673, '2009-09-25', 'solnishko307@yandex.ru', '7777777', 'S_RAD_ORDER', '', '', '', '', '89634616707', '', '', 'Челябинск', 0, 0, '', 4471, '', '', '', '', '', 3, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (674, '2009-09-27', 'k2c.kamanzev@yandex.ru', '22081979-22082029', 'S_RAD_ORDER', 'k2c.kamanzev@yandex.ru', '', '', '', '89028517324', '', '', 'нижневартовск', 0, 0, '', 4471, '', '', '', '41001447890491', '', 7, '', '', 'diplom.krsk.info/sales_got.htm;', 'demia.ru;', 'newstudent.ru;', '', '');
INSERT INTO `ri_user` VALUES (675, '2009-09-28', 'BarS-Kovd@yandex.ru', 'Cnfc25071974', 'Submit', 'Станислав', '', '', '', '+79211656907', '', '', 'Мурманск', 0, 0, '', 4471, '', '', '', '4100138744844', '', 20, '', '1 год', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (676, '2009-09-29', 'diplomas@ngs.ru', '65years', 'S_RAD_ORDER', 'Коробов Николай Сергеевич', '', '', '', '8-960-788-24-38', '', '', 'Новосибирск', 0, 0, '', 4471, '', '', '', '41001176022771', '', 130, 'http://www.diplomas.moy.su/', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (677, '2011-06-02', 'omegos@mail.ru', 'history', '', 'omego_var', '', '', '', '', '', '', 'Торжок', 0, 0, '', 0, '', '', '', '', '', 200, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (678, '2011-06-02', 'oggy@mail.ru', 'history', '', 'Олежка', '', '', '', '', '', '', 'Орёл', 0, 0, '', 0, '', '', '', '', '', 1000, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (679, '2011-06-02', 'redis@ya.ru', 'history', '', 'Юлия', '', '', '', '', '', '', 'Югра', 0, 0, '', 0, '', '', '', '', '', 400, '', '2 месяца', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (680, '2011-06-02', 'usjust@mail.ru', 'history', '', 'Оленька', '', '', '', '', '', '', 'БОрисов', 0, 0, '', 0, '', '', '', '', '', 30, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (681, '2011-06-02', 'fillis@gmail.com', 'history', '', 'Филлип', '', '', '', '', '', '', 'Псков', 0, 0, '', 0, '', '', '', '', '', 30, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (683, '2011-06-02', 'hungaro@mail.com', 'history', '', 'Хьюгос', '', '', '', '', '', '', 'Хургада', 0, 0, '', 0, '', '', '', '', '', 5, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (684, '2011-06-02', 'olas@mail.ru', 'history', '', 'Ондрон', '', '', '', '', '', '', 'Орёл', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (685, '2011-06-02', 'xtras09@ya.ru', 'history', '', 'Александр', '', '', '', '', '', '', 'Харькив', 0, 0, '', 0, '', '', '', '', '', 60, '', '', '', '', '', '', '');
INSERT INTO `ri_user` VALUES (690, '2011-10-13', 'club_ii@mail.ru', '', '', 'club', '', '', '(81651)42-388', 'нет', '', '', ' Демянск', 0, 0, '', 0, '', '', '', '', '', 0, '', '', '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_workers`
-- 

CREATE TABLE `ri_workers` (
  `number` int(11) NOT NULL auto_increment,
  `name` char(30) NOT NULL default '',
  `family` char(30) NOT NULL default '',
  `futhers` char(30) NOT NULL default '',
  `email` char(30) NOT NULL default '',
  `email2` char(30) NOT NULL default '',
  `login` char(30) default NULL,
  `password` char(40) NOT NULL default '',
  `icq` int(11) NOT NULL default '0',
  `skype` char(30) NOT NULL default '',
  `city` char(40) NOT NULL default '',
  `status` char(10) default NULL,
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Сотрудники' AUTO_INCREMENT=2 ;

-- 
-- Дамп данных таблицы `ri_workers`
-- 

INSERT INTO `ri_workers` VALUES (1, 'Сергей', 'Клевцов', 'Владимирович', 'srgg67@gmail.com', 'srgg140201@yandex.ru', 'srgg', 'history', 29894257, 'eduservice', 'Таганрог', '0000-00-00');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_worx`
-- 

CREATE TABLE `ri_worx` (
  `number` int(11) NOT NULL auto_increment,
  `author_id` int(11) NOT NULL default '0',
  `work_name` char(100) NOT NULL default '',
  `work_type` char(25) NOT NULL default '',
  `work_area` char(40) NOT NULL default '',
  `work_price` int(11) NOT NULL default '0',
  `volume` char(10) NOT NULL default '',
  `datatime` datetime NOT NULL default '0000-00-00 00:00:00',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Загруженные авторами работы' AUTO_INCREMENT=41 ;

-- 
-- Дамп данных таблицы `ri_worx`
-- 

INSERT INTO `ri_worx` VALUES (4, 33, 'Стартап.doc', 'Дипломная работа', 'Религия', 3000, 'annotation', '2011-05-28 10:06:21');
INSERT INTO `ri_worx` VALUES (20, 33, '2.1.doc', 'Исследование', '0', 3500, 'annotation', '2011-10-19 10:54:20');
INSERT INTO `ri_worx` VALUES (13, 33, 'Счёт на оплату услуг.doc', 'Неизвестный', 'Страноведение', 300, 'annotation', '2011-06-13 15:22:20');
INSERT INTO `ri_worx` VALUES (35, 33, 'Глава 32 - Дарение.doc', 'Дипломная работа', 'АСТРОЛОГИЯ', 4200, 'annotation', '2011-11-08 12:30:22');
INSERT INTO `ri_worx` VALUES (21, 33, '2.1_заимствования.doc', 'Исследование', '0', 4375, 'annotation', '2011-10-19 10:54:20');
INSERT INTO `ri_worx` VALUES (37, 33, 'Исковое заявление.doc', 'Диссертация', 'вирусология', 6400, 'annotation', '2011-11-08 12:30:23');

-- --------------------------------------------------------

-- 
-- Структура таблицы `ri_znums_attaches`
-- 

CREATE TABLE `ri_znums_attaches` (
  `number` int(11) NOT NULL auto_increment,
  `diplom_zakaz_number` int(11) NOT NULL default '0',
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='id id заказов с письмами, содержащи' AUTO_INCREMENT=192 ;

-- 
-- Дамп данных таблицы `ri_znums_attaches`
-- 

INSERT INTO `ri_znums_attaches` VALUES (1, 6625);
INSERT INTO `ri_znums_attaches` VALUES (2, 6671);
INSERT INTO `ri_znums_attaches` VALUES (3, 6665);
INSERT INTO `ri_znums_attaches` VALUES (4, 6698);
INSERT INTO `ri_znums_attaches` VALUES (5, 6692);
INSERT INTO `ri_znums_attaches` VALUES (6, 6703);
INSERT INTO `ri_znums_attaches` VALUES (7, 6711);
INSERT INTO `ri_znums_attaches` VALUES (8, 6802);
INSERT INTO `ri_znums_attaches` VALUES (9, 6672);
INSERT INTO `ri_znums_attaches` VALUES (10, 6718);
INSERT INTO `ri_znums_attaches` VALUES (11, 6776);
INSERT INTO `ri_znums_attaches` VALUES (12, 6796);
INSERT INTO `ri_znums_attaches` VALUES (13, 6833);
INSERT INTO `ri_znums_attaches` VALUES (14, 6875);
INSERT INTO `ri_znums_attaches` VALUES (15, 6841);
INSERT INTO `ri_znums_attaches` VALUES (16, 6912);
INSERT INTO `ri_znums_attaches` VALUES (17, 6920);
INSERT INTO `ri_znums_attaches` VALUES (18, 6935);
INSERT INTO `ri_znums_attaches` VALUES (19, 6812);
INSERT INTO `ri_znums_attaches` VALUES (20, 6916);
INSERT INTO `ri_znums_attaches` VALUES (21, 6956);
INSERT INTO `ri_znums_attaches` VALUES (22, 6945);
INSERT INTO `ri_znums_attaches` VALUES (23, 6946);
INSERT INTO `ri_znums_attaches` VALUES (24, 6994);
INSERT INTO `ri_znums_attaches` VALUES (25, 6969);
INSERT INTO `ri_znums_attaches` VALUES (26, 6668);
INSERT INTO `ri_znums_attaches` VALUES (27, 6553);
INSERT INTO `ri_znums_attaches` VALUES (28, 6958);
INSERT INTO `ri_znums_attaches` VALUES (29, 6968);
INSERT INTO `ri_znums_attaches` VALUES (30, 7007);
INSERT INTO `ri_znums_attaches` VALUES (31, 6966);
INSERT INTO `ri_znums_attaches` VALUES (32, 6991);
INSERT INTO `ri_znums_attaches` VALUES (33, 7040);
INSERT INTO `ri_znums_attaches` VALUES (34, 6990);
INSERT INTO `ri_znums_attaches` VALUES (35, 7005);
INSERT INTO `ri_znums_attaches` VALUES (36, 7066);
INSERT INTO `ri_znums_attaches` VALUES (37, 7058);
INSERT INTO `ri_znums_attaches` VALUES (38, 7002);
INSERT INTO `ri_znums_attaches` VALUES (39, 7068);
INSERT INTO `ri_znums_attaches` VALUES (40, 7112);
INSERT INTO `ri_znums_attaches` VALUES (41, 7105);
INSERT INTO `ri_znums_attaches` VALUES (42, 7091);
INSERT INTO `ri_znums_attaches` VALUES (43, 7134);
INSERT INTO `ri_znums_attaches` VALUES (44, 7010);
INSERT INTO `ri_znums_attaches` VALUES (45, 7055);
INSERT INTO `ri_znums_attaches` VALUES (46, 7001);
INSERT INTO `ri_znums_attaches` VALUES (47, 7004);
INSERT INTO `ri_znums_attaches` VALUES (48, 7062);
INSERT INTO `ri_znums_attaches` VALUES (49, 7168);
INSERT INTO `ri_znums_attaches` VALUES (50, 7118);
INSERT INTO `ri_znums_attaches` VALUES (51, 7200);
INSERT INTO `ri_znums_attaches` VALUES (52, 6904);
INSERT INTO `ri_znums_attaches` VALUES (53, 7151);
INSERT INTO `ri_znums_attaches` VALUES (54, 7038);
INSERT INTO `ri_znums_attaches` VALUES (55, 7198);
INSERT INTO `ri_znums_attaches` VALUES (56, 6965);
INSERT INTO `ri_znums_attaches` VALUES (57, 7222);
INSERT INTO `ri_znums_attaches` VALUES (58, 5265);
INSERT INTO `ri_znums_attaches` VALUES (59, 7199);
INSERT INTO `ri_znums_attaches` VALUES (60, 7235);
INSERT INTO `ri_znums_attaches` VALUES (61, 6926);
INSERT INTO `ri_znums_attaches` VALUES (62, 7243);
INSERT INTO `ri_znums_attaches` VALUES (63, 7194);
INSERT INTO `ri_znums_attaches` VALUES (64, 7191);
INSERT INTO `ri_znums_attaches` VALUES (65, 7233);
INSERT INTO `ri_znums_attaches` VALUES (66, 7185);
INSERT INTO `ri_znums_attaches` VALUES (67, 7282);
INSERT INTO `ri_znums_attaches` VALUES (68, 7316);
INSERT INTO `ri_znums_attaches` VALUES (69, 7299);
INSERT INTO `ri_znums_attaches` VALUES (70, 7247);
INSERT INTO `ri_znums_attaches` VALUES (71, 7363);
INSERT INTO `ri_znums_attaches` VALUES (72, 7324);
INSERT INTO `ri_znums_attaches` VALUES (73, 7349);
INSERT INTO `ri_znums_attaches` VALUES (74, 7334);
INSERT INTO `ri_znums_attaches` VALUES (75, 7428);
INSERT INTO `ri_znums_attaches` VALUES (76, 7369);
INSERT INTO `ri_znums_attaches` VALUES (77, 7397);
INSERT INTO `ri_znums_attaches` VALUES (78, 7400);
INSERT INTO `ri_znums_attaches` VALUES (79, 7486);
INSERT INTO `ri_znums_attaches` VALUES (80, 7386);
INSERT INTO `ri_znums_attaches` VALUES (81, 7635);
INSERT INTO `ri_znums_attaches` VALUES (82, 7407);
INSERT INTO `ri_znums_attaches` VALUES (83, 7607);
INSERT INTO `ri_znums_attaches` VALUES (84, 7392);
INSERT INTO `ri_znums_attaches` VALUES (85, 7577);
INSERT INTO `ri_znums_attaches` VALUES (86, 7352);
INSERT INTO `ri_znums_attaches` VALUES (87, 7469);
INSERT INTO `ri_znums_attaches` VALUES (88, 7579);
INSERT INTO `ri_znums_attaches` VALUES (89, 5543);
INSERT INTO `ri_znums_attaches` VALUES (90, 7559);
INSERT INTO `ri_znums_attaches` VALUES (91, 7378);
INSERT INTO `ri_znums_attaches` VALUES (92, 7353);
INSERT INTO `ri_znums_attaches` VALUES (93, 7666);
INSERT INTO `ri_znums_attaches` VALUES (94, 7403);
INSERT INTO `ri_znums_attaches` VALUES (95, 7677);
INSERT INTO `ri_znums_attaches` VALUES (96, 7641);
INSERT INTO `ri_znums_attaches` VALUES (97, 7694);
INSERT INTO `ri_znums_attaches` VALUES (98, 7504);
INSERT INTO `ri_znums_attaches` VALUES (99, 7672);
INSERT INTO `ri_znums_attaches` VALUES (100, 7414);
INSERT INTO `ri_znums_attaches` VALUES (101, 7643);
INSERT INTO `ri_znums_attaches` VALUES (102, 7558);
INSERT INTO `ri_znums_attaches` VALUES (103, 7702);
INSERT INTO `ri_znums_attaches` VALUES (104, 7387);
INSERT INTO `ri_znums_attaches` VALUES (105, 7596);
INSERT INTO `ri_znums_attaches` VALUES (106, 7739);
INSERT INTO `ri_znums_attaches` VALUES (107, 7736);
INSERT INTO `ri_znums_attaches` VALUES (108, 7693);
INSERT INTO `ri_znums_attaches` VALUES (109, 7762);
INSERT INTO `ri_znums_attaches` VALUES (110, 7639);
INSERT INTO `ri_znums_attaches` VALUES (111, 7746);
INSERT INTO `ri_znums_attaches` VALUES (112, 7865);
INSERT INTO `ri_znums_attaches` VALUES (113, 7884);
INSERT INTO `ri_znums_attaches` VALUES (114, 7846);
INSERT INTO `ri_znums_attaches` VALUES (115, 7468);
INSERT INTO `ri_znums_attaches` VALUES (116, 7671);
INSERT INTO `ri_znums_attaches` VALUES (117, 7706);
INSERT INTO `ri_znums_attaches` VALUES (118, 7904);
INSERT INTO `ri_znums_attaches` VALUES (119, 7794);
INSERT INTO `ri_znums_attaches` VALUES (120, 7877);
INSERT INTO `ri_znums_attaches` VALUES (121, 7974);
INSERT INTO `ri_znums_attaches` VALUES (122, 7941);
INSERT INTO `ri_znums_attaches` VALUES (123, 7922);
INSERT INTO `ri_znums_attaches` VALUES (124, 7732);
INSERT INTO `ri_znums_attaches` VALUES (125, 7793);
INSERT INTO `ri_znums_attaches` VALUES (126, 7991);
INSERT INTO `ri_znums_attaches` VALUES (127, 7995);
INSERT INTO `ri_znums_attaches` VALUES (128, 7914);
INSERT INTO `ri_znums_attaches` VALUES (129, 8014);
INSERT INTO `ri_znums_attaches` VALUES (130, 7882);
INSERT INTO `ri_znums_attaches` VALUES (131, 8011);
INSERT INTO `ri_znums_attaches` VALUES (132, 8063);
INSERT INTO `ri_znums_attaches` VALUES (133, 8571);
INSERT INTO `ri_znums_attaches` VALUES (134, 8613);
INSERT INTO `ri_znums_attaches` VALUES (135, 8577);
INSERT INTO `ri_znums_attaches` VALUES (136, 8652);
INSERT INTO `ri_znums_attaches` VALUES (137, 8648);
INSERT INTO `ri_znums_attaches` VALUES (138, 8675);
INSERT INTO `ri_znums_attaches` VALUES (139, 8658);
INSERT INTO `ri_znums_attaches` VALUES (140, 9112);
INSERT INTO `ri_znums_attaches` VALUES (141, 9157);
INSERT INTO `ri_znums_attaches` VALUES (142, 9175);
INSERT INTO `ri_znums_attaches` VALUES (143, 9177);
INSERT INTO `ri_znums_attaches` VALUES (144, 9214);
INSERT INTO `ri_znums_attaches` VALUES (145, 9276);
INSERT INTO `ri_znums_attaches` VALUES (146, 9265);
INSERT INTO `ri_znums_attaches` VALUES (147, 9312);
INSERT INTO `ri_znums_attaches` VALUES (148, 9338);
INSERT INTO `ri_znums_attaches` VALUES (149, 9313);
INSERT INTO `ri_znums_attaches` VALUES (150, 9326);
INSERT INTO `ri_znums_attaches` VALUES (151, 9310);
INSERT INTO `ri_znums_attaches` VALUES (152, 9365);
INSERT INTO `ri_znums_attaches` VALUES (153, 9373);
INSERT INTO `ri_znums_attaches` VALUES (154, 9348);
INSERT INTO `ri_znums_attaches` VALUES (155, 9367);
INSERT INTO `ri_znums_attaches` VALUES (156, 9387);
INSERT INTO `ri_znums_attaches` VALUES (157, 9350);
INSERT INTO `ri_znums_attaches` VALUES (158, 9340);
INSERT INTO `ri_znums_attaches` VALUES (159, 9309);
INSERT INTO `ri_znums_attaches` VALUES (160, 9407);
INSERT INTO `ri_znums_attaches` VALUES (161, 9403);
INSERT INTO `ri_znums_attaches` VALUES (162, 9435);
INSERT INTO `ri_znums_attaches` VALUES (163, 9485);
INSERT INTO `ri_znums_attaches` VALUES (164, 9474);
INSERT INTO `ri_znums_attaches` VALUES (165, 9501);
INSERT INTO `ri_znums_attaches` VALUES (166, 9445);
INSERT INTO `ri_znums_attaches` VALUES (167, 9530);
INSERT INTO `ri_znums_attaches` VALUES (168, 9544);
INSERT INTO `ri_znums_attaches` VALUES (169, 9545);
INSERT INTO `ri_znums_attaches` VALUES (170, 9554);
INSERT INTO `ri_znums_attaches` VALUES (171, 9550);
INSERT INTO `ri_znums_attaches` VALUES (172, 9561);
INSERT INTO `ri_znums_attaches` VALUES (173, 9557);
INSERT INTO `ri_znums_attaches` VALUES (174, 9558);
INSERT INTO `ri_znums_attaches` VALUES (175, 9564);
INSERT INTO `ri_znums_attaches` VALUES (176, 9565);
INSERT INTO `ri_znums_attaches` VALUES (177, 9657);
INSERT INTO `ri_znums_attaches` VALUES (178, 9655);
INSERT INTO `ri_znums_attaches` VALUES (179, 9663);
INSERT INTO `ri_znums_attaches` VALUES (180, 9670);
INSERT INTO `ri_znums_attaches` VALUES (181, 9676);
INSERT INTO `ri_znums_attaches` VALUES (182, 9679);
INSERT INTO `ri_znums_attaches` VALUES (183, 9681);
INSERT INTO `ri_znums_attaches` VALUES (184, 9690);
INSERT INTO `ri_znums_attaches` VALUES (185, 9701);
INSERT INTO `ri_znums_attaches` VALUES (186, 9707);
INSERT INTO `ri_znums_attaches` VALUES (187, 9702);
INSERT INTO `ri_znums_attaches` VALUES (188, 9724);
INSERT INTO `ri_znums_attaches` VALUES (189, 9722);
INSERT INTO `ri_znums_attaches` VALUES (190, 9728);
INSERT INTO `ri_znums_attaches` VALUES (191, 9734);
